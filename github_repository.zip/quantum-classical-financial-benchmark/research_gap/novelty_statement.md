# Novelty Statement
**Target Journal:** The Journal of Computational Finance

This study establishes several critical dimensions of novelty at the intersection of computational finance, quantum information science, and financial econometrics:

1. **First End-to-End Walk-Forward Computational Benchmark:** 
   Unlike prior studies in quantum finance that rely on static, look-ahead-prone in-sample splits or unpurged cross-validation, this is the first comprehensive work to evaluate Quantum Kernel Machines (QSVM) and Variational Quantum Classifiers (VQC) using a strictly chronological, anchored walk-forward validation framework across multi-year liquid index data.

2. **Strict Parity in Input Feature Representations:**
   We systematically resolve the "apples-to-oranges" flaw of existing literature. Rather than providing classical models with uncompressed feature sets while feeding quantum circuits heavily distorted toy features (or vice versa), both quantum and classical architectures are evaluated on rigorously standardized, identical sets of orthogonalized technical and volatility indicators (RSI, MACD, Bollinger Band width, ATR, ROC, Momentum).

3. **Bridge Between Statistical Significance and Economic Reality:**
   This paper is the first to test whether quantum predictive edge translates into genuine financial performance under parametric transaction costs (0, 5, 10, 20 bps). We prove that statistical metrics (accuracy/AUC) can diverge drastically from realized economic metrics (Sharpe, Calmar, maximum drawdown, turnover), demonstrating why financial backtests are indispensable for evaluating quantum learning algorithms.

4. **Rigorous Statistical Auditing (Diebold–Mariano, Bootstrap, McNemar):**
   Rather than relying on point-estimate accuracy tables, we introduce formal econometric testing—incorporating the Diebold–Mariano test for predictive accuracy, stationary bootstrap confidence intervals, and McNemar's paired contingency tests—to definitively assess whether observed quantum performance differences exceed random sampling fluctuations.

5. **Exposing Simulation Complexity vs Hardware Reality:**
   We explicitly dissect the computational budget of quantum simulation, benchmarking statevector fidelity, shot-noise variance, gate depth, and wall-clock execution time against optimized classical routines. We provide an unvarnished computational accounting that dispels unwarranted claims of "NISQ quantum advantage" in daily financial forecasting while identifying the precise theoretical boundaries where quantum kernels might provide future algorithmic value.
