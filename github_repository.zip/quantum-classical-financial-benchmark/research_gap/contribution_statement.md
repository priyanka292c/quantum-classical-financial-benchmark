# Contribution Statement
**Target Journal:** The Journal of Computational Finance

The primary contributions of this paper to the quantitative finance and computational literature are:

1. **Methodological Contribution:** We formalize a rigorous benchmarking protocol for quantum machine learning in finance, enforcing temporal causality, walk-forward re-estimation, identical feature projections, and strict separation between quantum mathematical structure, classical circuit simulation, and physical quantum device execution.
2. **Empirical Contribution:** We deliver an exhaustive empirical comparison across multiple market regimes (including the COVID-19 liquidity shock, post-pandemic inflation surge, and high-rate monetary tightening cycles) using liquid ETF and equity market data (S&P 500 / SPY), contrasting QSVM and VQC against five classical baselines (Logistic Regression, SVM-RBF, Random Forest, XGBoost, and MLP).
3. **Econometric and Statistical Contribution:** We establish formal statistical evaluation standards for quantum finance papers, demonstrating that without Diebold–Mariano loss-differential tests and bootstrap confidence bounds, reported "quantum advantages" in literature are frequently attributable to statistical noise and data snooping.
4. **Economic and Risk Management Contribution:** We demonstrate the severe impact of transaction friction on high-turnover quantum classifiers, showing how gross statistical margins vanish under realistic 5–10 bps trading costs, thereby providing practical guidance for quantitative portfolio managers and risk officers.
5. **Computational Complexity Contribution:** We quantify the wall-clock and algorithmic scaling of quantum statevector simulation vs classical estimators, presenting explicit gate counts, circuit depths, and simulation scaling profiles.
6. **Open Science & Reproducibility Contribution:** We provide a fully automated, dual-language (Python/Qiskit and MATLAB) reproducible code repository and data ingestion pipeline that enables independent replication and extension by the computational finance community.
