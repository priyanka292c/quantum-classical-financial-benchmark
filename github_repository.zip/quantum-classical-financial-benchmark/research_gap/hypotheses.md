# Formal Research Hypotheses
**Target Journal:** The Journal of Computational Finance

Based on foundational theoretical principles in quantum information theory (e.g., Havlíček et al. 2019; Schuld and Killoran 2019; Huang et al. 2021; Cerezo et al. 2021) and empirical asset pricing / financial econometrics (e.g., Cont 2001; Gu, Kelly, and Xiu 2020; De Prado 2018), we formulate five testable hypotheses:

### Hypothesis 1: Directional Predictive Parity
- **$H_{0,1}$ (Null):** Out-of-sample directional prediction accuracy and area under the ROC curve (AUC) of quantum pipelines (QSVM, VQC) are equal to or lower than those of tuned classical baseline models (SVM-RBF, Random Forest, XGBoost).
  $$\mathbb{E}[\text{AUC}_{\text{Quantum}}] \le \mathbb{E}[\text{AUC}_{\text{Classical}}]$$
- **$H_{1,1}$ (Alternative):** Quantum kernel or variational classifiers achieve statistically superior directional accuracy and AUC on out-of-sample financial test sets.
  $$\mathbb{E}[\text{AUC}_{\text{Quantum}}] > \mathbb{E}[\text{AUC}_{\text{Classical}}]$$

### Hypothesis 2: Diebold–Mariano Predictive Significance
- **$H_{0,2}$ (Null):** The expected loss differential between quantum forecasts $\hat{y}_{t}^{\text{Q}}$ and classical benchmark forecasts $\hat{y}_{t}^{\text{C}}$ is zero under the Diebold–Mariano test:
  $$\mathbb{E}[d_t] = \mathbb{E}[\mathcal{L}(y_t, \hat{y}_{t}^{\text{C}}) - \mathcal{L}(y_t, \hat{y}_{t}^{\text{Q}})] = 0$$
- **$H_{1,2}$ (Alternative):** The loss differential is statistically significantly different from zero ($\mathbb{E}[d_t] \neq 0$).

### Hypothesis 3: Economic Profitability Post-Friction
- **$H_{0,3}$ (Null):** Net of transaction costs ($\ge 5$ basis points per turnover), trading strategies driven by quantum signals generate an annualized Sharpe ratio indistinguishable from or inferior to a passive buy-and-hold index benchmark or classical linear models:
  $$\text{SR}_{\text{Quantum}}^{\text{net}} \le \text{SR}_{\text{Benchmark}}^{\text{net}}$$
- **$H_{1,3}$ (Alternative):** Quantum trading strategies maintain positive alpha and higher risk-adjusted Sharpe ratios after realistic execution frictions.

### Hypothesis 4: Computational Disadvantage in Simulation
- **$H_{0,4}$ (Null):** Classical simulation wall-clock training and inference times for quantum pipelines scale comparably to classical kernel methods ($O(N^2)$ to $O(N^3)$ with manageable constants).
- **$H_{1,4}$ (Alternative):** Classical simulation of quantum kernel evaluation and variational gradient estimation incurs an exponential or high-degree polynomial constant overhead relative to classical estimators without yielding commensurate accuracy gains.

### Hypothesis 5: Kernel Concentration in Low SNR Environments
- **$H_{0,5}$ (Null):** Quantum kernel matrices constructed via second-order Pauli-$Z$ feature maps maintain diverse inter-sample distance representations in low signal-to-noise financial spaces.
- **$H_{1,5}$ (Alternative):** Quantum kernels suffer from exponential kernel concentration (exponential flattening towards orthogonality or identity), rendering them susceptible to high variance and overfitting on noisy market indicators.
