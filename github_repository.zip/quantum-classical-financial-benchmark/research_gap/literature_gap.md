# Systematic Literature Gap Analysis
**Target Journal:** The Journal of Computational Finance

## 1. Executive Summary of the Literature Landscape
Over the past five years (2020–2026), the literature on Quantum Machine Learning (QML) applied to finance has expanded rapidly. Proponents often suggest that parameterized quantum circuits (PQCs), variational quantum classifiers (VQCs), and quantum kernel methods (such as Quantum Support Vector Machines, QSVM) can exploit high-dimensional Hilbert spaces, quantum entanglement, and interference to detect nonlinear patterns in noisy financial time series that classical estimators fail to capture.

However, a critical and systematic evaluation of recent publications (e.g., Woerner and Egger 2019; Orús et al. 2019; Herman et al. 2023; Egger et al. 2020; Bouland et al. 2020; Cerezo et al. 2021; Biamonte et al. 2017; Schuld and Killoran 2019; Huang et al. 2021) reveals severe methodological shortcomings across the existing quantum-financial literature.

---

## 2. Critical Methodological Deficiencies in Existing Studies

| Dimension | Typical Existing QML Finance Literature | Methodological Consequence / Bias | Required Rigorous Computational Benchmark |
| :--- | :--- | :--- | :--- |
| **Data Partitioning & Leakage** | Random train/test splits, $K$-fold cross-validation without purging, or arbitrary single chronological splits (e.g., 200–500 trading days). | Severe look-ahead bias and autocorrelation leakage. Inflates test metrics by up to 15–25%. | Strict **anchored/rolling walk-forward validation** with embargoed periods, preserving temporal causality. |
| **Classical Baselines** | Weak, untuned baselines (e.g., default unregularized logistic regression, single-layer perceptron). | Creates an illusory "quantum superiority" by comparing tuned QML against sub-optimal classical models. | **Carefully tuned classical benchmarks**: Ridge/Logistic, Support Vector Machines (linear and RBF kernels), Random Forests, XGBoost, and Multilayer Perceptrons (MLP). |
| **Feature Dimensionality & Encoding** | Extreme dimensionality reduction (e.g., 2–4 PCA components) applied without analyzing information loss, or disparate feature sets between quantum and classical pipelines. | Classical models crippled by aggressive compression, or quantum feature maps operating on degenerate feature projections. | **Identical feature matrices** derived from standardized technical and volatility indicators (RSI, MACD, Bollinger Bands, ATR, ROC, Momentum) with explicit feature selection. |
| **Statistical Rigor** | Reporting raw accuracy differences (e.g., 52.5% vs 51.2%) without formal hypothesis testing or confidence intervals. | Differences are within sampling noise; no evidence that differences are statistically distinguishable from random chance. | **Formal statistical hypothesis testing**: Diebold–Mariano test, stationary bootstrap confidence intervals, and McNemar's test for directional forecasts. |
| **Financial vs Statistical Metrics** | Evaluation restricted solely to classification accuracy or mean squared error; zero trading backtests. | Statistical edge does not translate into economic value due to turnover and volatility clustering. | **Realistic financial backtesting**: Cumulative return, annualized Sharpe ratio, Sortino ratio, Calmar ratio, maximum drawdown, and turnover. |
| **Transaction Costs & Slippage** | Total omission of transaction costs, execution slippage, or borrowing fees. | Models generating frequent directional flips report high gross returns that turn deeply negative after 5–10 bps friction. | **Parametric cost sensitivity analysis**: 0 bps, 5 bps, 10 bps, and 20 bps round-trip transaction frictions. |
| **Market Regime Analysis** | Evaluation over a single bull market regime or a short stationary window. | Fails to test whether quantum embeddings generalize across structural breaks, crises, or high-volatility regimes. | **Multi-regime evaluation**: Bull expansion, bear crash (e.g., 2020 COVID shock / 2022 rate hikes), and sideways consolidation regimes. |
| **Computational Complexity & Resource Accounting** | Obscuring simulation wall-clock time; conflating classical circuit simulation with quantum hardware execution. | Claims of "quantum efficiency" made while classical simulation scales exponentially with qubit count and circuit depth. | **Rigorous computational accounting**: CPU/GPU wall-clock time, circuit depth, two-qubit CNOT count, statevector vs shot-sampling overhead, and Big-$O$ complexity. |

---

## 3. The Precise Research Gap
Despite enthusiastic theoretical claims, **there is currently no unified, methodologically rigorous computational benchmark in the literature that evaluates Parameterized Quantum Circuits (VQC) and Quantum Kernel Methods (QSVM) against carefully optimized classical machine learning pipelines (Logistic Regression, SVM-RBF, Random Forest, XGBoost, MLP) under identical, non-leaking walk-forward validation across multiple market regimes, incorporating realistic transaction costs, formal statistical hypothesis tests, and wall-clock computational scaling.**

This paper directly resolves this research gap by providing a fully reproducible, empirical and computational investigation designed specifically to separate genuine mathematical representation properties from computational simulation artifacts.
