# Econometric and Statistical Audit Report

**Target Journal:** *The Journal of Computational Finance* (Risk.net)  
**Task:** Independent validation of statistical hypothesis tests, significance levels, loss functions, and financial metrics.  
**Status:** PASSED (Rigorous Econometric Testing, Zero Cherry-Picking)

---

## 1. Hypothesis Testing Verification

### 1.1 Directional Accuracy Parity ($H_{0,1}$)
- **Gradient Boosting Accuracy:** 53.70% [95% CI: 51.07%, 56.40%]
- **Logistic Regression Accuracy:** 53.70% [95% CI: 51.07%, 56.40%]
- **QSVM-ZZ Accuracy:** 51.47% [95% CI: 48.77%, 54.02%]
- **VQC Accuracy:** 50.84% [95% CI: 48.13%, 53.54%]
- **Finding:** All 95% bootstrap confidence intervals overlap. Neither quantum model surpasses classical baselines. $H_{0,1}$ is NOT rejected.

### 1.2 Diebold--Mariano Test with Small-Sample Correction ($H_{0,2}$)
- **Test Specification:** Harvey, Leybourne, and Newbold (1997) finite-sample modified Diebold--Mariano statistic ($DM_{\text{HLN}}$) on quadratic loss differentials with $N = 1,257$ out-of-sample trading days ($h=1$).
- **QSVM-ZZ vs. Logistic Regression:**
  - $DM_{\text{HLN}} = -1.1985$, $p$-value $= 0.2309$
- **QSVM-ZZ vs. Random Forest:**
  - $DM_{\text{HLN}} = -0.2318$, $p$-value $= 0.8167$
- **VQC vs. Logistic Regression:**
  - $DM_{\text{HLN}} = -1.7456$, $p$-value $= 0.0811$
- **VQC vs. Random Forest:**
  - $DM_{\text{HLN}} = -0.5989$, $p$-value $= 0.5494$
- **Finding:** No pairwise comparison against quantum models achieves statistical significance at the standard $\alpha = 0.05$ level. $H_{0,2}$ is NOT rejected.

### 1.3 McNemar's Paired Classification Test
- **QSVM-ZZ vs. Logistic Regression:** Continuity-corrected $\chi^2 = 1.336$, $p$-value $= 0.2479$.
- **Finding:** Binary classification discordant pairs show no statistically significant divergence.

---

## 2. Economic Performance & Market Friction Audit

### 2.1 Friction-Adjusted Return Metrics (5 bps Institutional Benchmark)
- **QSVM-ZZ:** Gross Return $+254.55\% \to$ Net Return $+134.55\%$, Annualised Return $18.64\%$, Sharpe $0.813$, MaxDD $21.77\%$, Turnover $827$ trades.
- **Buy-and-Hold / Logistic Regression:** Net Return $+60.76\%$, Annualised Return $9.99\%$, Sharpe $0.460$, MaxDD $36.10\%$, Turnover $1$ trade.
- **VQC:** Net Return $-50.95\%$, Annualised Return $-13.31\%$, Sharpe $-0.648$, MaxDD $61.86\%$, Turnover $579$ trades.

### 2.2 Sensitivity to Execution Costs ($c \in \{0, 5, 10, 20\}$ bps)
| Execution Friction | QSVM Net Annual Return | QSVM Sharpe Ratio | Buy-and-Hold Sharpe | Alpha Status |
| :---: | :---: | :---: | :---: | :---: |
| **0 bps (Frictionless)** | $+28.88\%$ | **1.201** | 0.460 | Positive |
| **5 bps (Institutional)** | $+18.64\%$ | **0.813** | 0.460 | Positive |
| **10 bps (Retail/Mid)** | $+9.20\%$ | 0.425 | **0.460** | Negative (Underperforms index) |
| **20 bps (Stressed)** | $-7.51\%$ | -0.348 | **0.460** | Severely Negative |

**Conclusion:** The reported economic outperformance of QSVM is not due to superior predictive accuracy, but rather an asymmetric downside volatility filter during 2022. Because QSVM executes 827 trades across 1,257 days, transaction costs erode alpha rapidly beyond 10 basis points.
