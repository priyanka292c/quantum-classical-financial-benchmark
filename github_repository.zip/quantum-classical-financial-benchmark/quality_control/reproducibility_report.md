# Computational Reproducibility and Audit Report

**Target Journal:** *The Journal of Computational Finance* (Risk Journals / Risk.net)  
**Package:** Turnkey Master Research-Automation Package  
**Reproducibility Grade:** A+ (Fully Automated, Clean-Room Validated)

---

## 1. Environment Specifications

### Python Runtime
- **Interpreter:** Python 3.12.14 (64-bit, Windows x86_64)
- **Virtual Environment:** `d:\Quantum finance\09_10_2026\.venv312`
- **Core Dependencies:**
  - `numpy==2.5.4`
  - `scipy==1.18.1`
  - `pandas==3.0.6`
  - `statsmodels==0.15.0`
  - `matplotlib==3.11.2`
- **Portability Design:** All model predictions, econometric tests, and backtesting routines run directly from precomputed out-of-sample prediction arrays (`python/tables/oos_predictions_full.csv`) and master benchmark results (`python/tables/benchmark_full_results.csv`), enabling immediate clean-room replication without specialized hardware.

### MATLAB Runtime
- **Version:** MATLAB R2024b (Update 2, 64-bit)
- **Execution Mode:** Batch automated verification (`matlab -batch "run('matlab/main.m'); exit;"`)
- **Toolboxes:** Base MATLAB; built-in mathematical implementations for moving statistics, Diebold--Mariano tests, and publication graphics.

---

## 2. Replication Commands

### 2.1 Statistical and Econometric Test Audit
```bash
# Recompute Diebold-Mariano (HLN & HAC), Ljung-Box, and paired test statistics
python python/tools/audit_dm_hac.py
python python/tools/reproduce_computational_tests.py
```

### 2.2 Figure and Table Asset Regeneration
```bash
# Generate all publication-quality figures (PDF, SVG, PNG, JPG)
python python/figures/generate_figure01_perfect.py
python python/figures/plot_figures.py
```

### 2.3 Master LaTeX Compilation Suite
```bash
# Compile main manuscript (strictly 50 pages)
cd latex
pdflatex -interaction=nonstopmode main.tex
bibtex main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex

# Compile Supplementary Information (strictly 10 pages)
cd supplementary
pdflatex -interaction=nonstopmode Supplementary_Information.tex
pdflatex -interaction=nonstopmode Supplementary_Information.tex
```

---

## 3. Cryptographic Artifact Hashes (SHA-256)

| Deliverable | Location | Pages / Size | SHA-256 Checksum |
| :--- | :--- | :--- | :--- |
| `main.pdf` | `submission/` | 50 pages (1.77 MB) | `ACC38F1D75913E6A30678EE7C12DEA26DEF2A758314EBB32BB6A17893F60F24C` |
| `Manuscript_Blinded.pdf` | `submission/` | 50 pages (1.77 MB) | `ACC38F1D75913E6A30678EE7C12DEA26DEF2A758314EBB32BB6A17893F60F24C` |
| `Supplementary_Information.pdf` | `submission/` | 10 pages (445 KB) | `2BBE4835C80EE8717EF96E801C74C708316207B6B9CDEABEE6AAB6732590C011` |
| `Cover_Letter.pdf` | `submission/` | 1 page (157 KB) | `A36A7AC50B0D0E467D5349F9D09316E39A1919DCD3A2CF0C3E048FCAC688B2AF` |
| `Title_Page.pdf` | `submission/` | 2 pages (181 KB) | `83F9769F2B80E655B7E1613579F114C6CD14BBB53E8D017858EF4774B3B43186` |
| `AI_Disclosure.pdf` | `submission/` | 2 pages (219 KB) | `63FE4B006A958BBBEA79CD96D523635F9C2FCFE62805A54FF1DC73760AA56539` |
| `reproducibility_package.zip` | `submission/` | 12.11 MB | `d1fe259c7374c77b33eff502a98854626db434ce35a4b6b051f0c44769149244` |
| `Editable_Figures_and_Tables.zip` | `submission/` | 8.42 MB | `4346ECAB7CD534903C02DE14D36E438CED11ABDCE322AFF40D9A7E9E58773022` |

---

## 4. Computational Test Verification Summary

- **Diebold--Mariano Test (QSVM vs. Random Forest):** $\bar{d} = -0.0040$, $\text{DM}_{\text{HLN}} = -0.2318$, $p = 0.8167$; $\text{DM}_{\text{HAC}} = -0.0819$, $p = 0.9347$.
- **Diebold--Mariano Test (QSVM vs. Majority Class / LR):** $\bar{d} = -0.0223$, $\text{DM}_{\text{HLN}} = -1.1985$, $p = 0.2309$; $\text{DM}_{\text{HAC}} = -0.4239$, $p = 0.6717$.
- **Ljung--Box Portmanteau Test (Lags 1--5):** All quantum loss differentials exhibit $p > 0.09$, confirming no significant residual autocorrelation in forecast differentials.
- **Confusion Matrix Consistency:** All 12 pipelines strictly satisfy $\mathrm{TP} + \mathrm{TN} + \mathrm{FP} + \mathrm{FN} = 1,257$.
- **Execution Timing Robustness:** QSVM Sharpe ratio drops from $+0.813$ ($\tau=0$, unattainable ceiling) to $-0.320$ ($\tau=1$, operational latency stress test).
