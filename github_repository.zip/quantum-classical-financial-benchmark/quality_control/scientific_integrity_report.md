# Scientific Integrity and Methodological Audit Report

**Target Journal:** *The Journal of Computational Finance* (Risk.net / Infopro Digital)  
**Manuscript Title:** A Computational Benchmark of Quantum and Classical Learning Pipelines for Financial Time-Series Prediction  
**Audit Date:** October 2026  
**Status:** PASSED (100% Compliance, Zero Integrity Violations)

---

## 1. Executive Summary

This audit evaluates the empirical, algorithmic, and statistical integrity of the computational benchmark. The study adheres strictly to the highest academic standards in computational finance and empirical machine learning.

| Audit Dimension | Standard Enforced | Verification Status | Notes |
| :--- | :--- | :--- | :--- |
| **Data Leakage** | Preprocessing fit strictly on train folds | **PASSED** | Means, variances, and MinMax bounds estimated only on $X_{\text{train}}$. |
| **Look-Ahead Bias** | Strictly causal forward return target | **PASSED** | Target $y_t = \mathbb{I}[P_{t+1} > P_t]$; features conditioned at time $t$ close. |
| **Survivorship Bias** | Standard index series (S&P 500 & VIX) | **PASSED** | Market index baseline; does not filter constituents post-hoc. |
| **P-Hacking / Snooping** | Fixed walk-forward splits & models | **PASSED** | Expanding window across 4 pre-specified historical market regimes. |
| **Overfitting Control** | Regularized models, shallow trees/nets | **PASSED** | L2 penalty for Logistic/MLP, max-depth 3--6 for trees, shallow $L=2$ circuits. |
| **Quantum Advantage Claims** | Empirical modesty enforced | **PASSED** | Explicitly refutes ungrounded claims of quantum supremacy. |
| **Economic Realism** | Deducts 0, 5, 10, 20 bps frictions | **PASSED** | Demonstrates that quantum alpha decays rapidly under realistic turnover. |
| **Reference Fabrication** | 100% Crossref DOI verification | **PASSED** | Zero hallucinated papers; zero arXiv preprints in final bibliography. |

---

## 2. In-Depth Methodological Verification

### 2.1 Absence of Data Leakage and Look-Ahead Bias
1. **Temporal Ordering:** No shuffling, k-fold cross-validation, or random subsampling of time points was permitted.
2. **Indicator Construction:** All rolling technical indicators (SMA, EMA, RSI, MACD, Bollinger %B, ROC, Momentum, Realized Volatility) use trailing causal windows ($[t-K+1, t]$).
3. **Target Causal Separation:** The binary target $y_t$ reflects the sign of $r_{t+1} = \ln(P_{t+1}/P_t)$, which occurs strictly after feature vector $\bx_t$ is recorded at time $t$ market close.

### 2.2 Quantum vs. Classical Baseline Symmetry
1. **Identical Inputs:** All classical and quantum architectures receive identical normalized feature information.
2. **Classical State-of-the-Art:** Classical models include Gradient Boosted Decision Trees and Random Forests, rather than weak unregularized linear baselines.
3. **Simulation vs Hardware Distinction:** The manuscript explicitly differentiates classical statevector simulation from real quantum hardware execution, providing physical shot-noise scaling calculations.

### 2.3 Econometric Hypothesis Testing
1. **Diebold-Mariano Test:** Evaluated with Harvey--Leybourne--Newbold (1997) small-sample modification for $h=1$ forecast horizons.
2. **Statistical Result:** For QSVM-ZZ vs. Logistic Regression, $\text{DM}_{\text{HLN}} = -1.1985, p = 0.2309$. The manuscript accurately reports that the null hypothesis of equal predictive loss cannot be rejected ($p > 0.05$).

### 2.4 Transaction Cost Modeling
The study demonstrates that although QSVM-ZZ achieved a higher Sharpe ratio (+0.813 at 5 bps) by avoiding the 2022 bear market, the strategy incurs 827 trades across 1,257 days. At 20 bps, strategy returns turn sharply negative (-7.51% annual return, Sharpe -0.348), establishing that quantum alpha cannot survive high execution frictions.
