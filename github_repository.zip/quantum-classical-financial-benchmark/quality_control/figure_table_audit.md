# Figure and Table Discussion Audit Report

**Target Journal:** *The Journal of Computational Finance* (Risk.net)  
**Requirement:** Every figure and table must be generated computationally, exported in multiple formats, explicitly referenced, introduced, and discussed in the manuscript text.  
**Status:** PASSED (100% In-Text Discussion, Zero Orphan Items)

---

## 1. Figure Audit Matrix

| Figure | Title / Description | Vector PDF | Vector SVG | 300 DPI PNG | In-Text Callout | Discussed in Text? |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: |
| **Fig. 1** | Research Workflow Architecture | Yes | Yes | Yes | `\ref{fig:workflow}` | Yes (Section 1) |
| **Fig. 2** | S&P 500 Price Path & VIX Dynamics across Regimes | Yes | Yes | Yes | `\ref{fig:regimes}` | Yes (Section 3) |
| **Fig. 3** | Technical Indicator Correlation Heatmap | Yes | Yes | Yes | `\ref{fig:correlations}` | Yes (Section 3) |
| **Fig. 4** | Quantum Circuit Architectures (ZZ & VQC Ansatz) | Yes | Yes | Yes | `\ref{fig:circuits}` | Yes (Section 4) |
| **Fig. 5** | Out-of-Sample Accuracy & AUC with 95% Bootstrap CIs | Yes | Yes | Yes | `\ref{fig:accuracy_auc}` | Yes (Section 6) |
| **Fig. 6** | Out-of-Sample ROC Curves Across Models | Yes | Yes | Yes | `\ref{fig:roc_curves}` | Yes (Section 6) |
| **Fig. 7** | Cumulative Net Equity Curves (5 bps Frictions) | Yes | Yes | Yes | `\ref{fig:equity_curves}` | Yes (Section 6) |
| **Fig. 8** | Peak-to-Trough Drawdown Profiles Over Time | Yes | Yes | Yes | `\ref{fig:drawdown_curves}` | Yes (Section 6) |
| **Fig. 9** | Transaction Cost Sensitivity Sweep (0-20 bps) | Yes | Yes | Yes | `\ref{fig:cost_sensitivity}` | Yes (Section 8) |
| **Fig. 10** | Computational Complexity & Runtime Scaling | Yes | Yes | Yes | `\ref{fig:runtime_scaling}` | Yes (Section 7) |
| **Fig. 11** | Multi-Regime Economic Performance Breakdown | Yes | Yes | Yes | `\ref{fig:regime_performance}` | Yes (Section 8) |
| **Fig. 12** | Ablation Analysis of Circuit Depth & Qubit Scaling | Yes | Yes | Yes | `\ref{fig:ablation_scaling}` | Yes (Section 8) |

---

## 2. Table Audit Matrix

| Table | Title / Subject | LaTeX File | In-Text Callout | Discussed in Text? |
| :---: | :--- | :--- | :---: | :---: |
| **Tab. 1** | Dataset Summary & Walk-Forward Regime Partitions | `tables/table01_dataset_summary.tex` | `\ref{tab:dataset_summary}` | Yes (Section 3) |
| **Tab. 2** | Mathematical Definitions of Technical Indicators | `tables/table02_technical_indicators.tex` | `\ref{tab:technical_indicators}` | Yes (Section 3) |
| **Tab. 3** | Model Architectures & Hyperparameter Specifications | `tables/table03_model_hyperparameters.tex` | `\ref{tab:model_hyperparameters}` | Yes (Section 4) |
| **Tab. 4** | Consolidated Predictive & Economic Results (N=1,257) | `tables/table04_benchmark_predictive_economic.tex` | `\ref{tab:benchmark_predictive_economic}` | Yes (Section 6) |
| **Tab. 5** | Econometric Hypothesis Tests (Diebold-Mariano & McNemar) | `tables/table05_statistical_tests.tex` | `\ref{tab:statistical_tests}` | Yes (Section 6) |
| **Tab. 6** | Computational Complexity & Quantum Circuit Resources | `tables/table06_computational_complexity.tex` | `\ref{tab:computational_complexity}` | Yes (Section 7) |
| **Tab. 7** | Multi-Regime Walk-Forward Performance Breakdown | `tables/table07_walk_forward_regimes.tex` | `\ref{tab:walk_forward_regimes}` | Yes (Section 8) |
| **Tab. 8** | Transaction Cost Sensitivity Grid (0 to 20 bps) | `tables/table08_transaction_cost_sensitivity.tex` | `\ref{tab:transaction_cost_sensitivity}` | Yes (Section 8) |

**Audit Result:** Zero orphan figures. Zero orphan tables. Every item is introduced, described, and interpreted in the prose.
