# MATLAB Computational and Econometric Suite

This directory contains the complete, self-contained MATLAB automation suite for the empirical benchmark published in *The Journal of Computational Finance* (Risk.net).

## Directory Structure

```
matlab/
├── main.m                      # Master orchestration and test runner
├── data_processing.m           # Technical indicator and financial series preprocessor
├── statistical_analysis.m      # Diebold-Mariano (HLN 1997) and McNemar hypothesis testing
├── plotting/
│   └── plot_figures_matlab.m   # Native vector and high-resolution figure generator
├── export_figures/             # Target directory for exported vector PDFs and 300 DPI PNGs
├── results/                    # Saved MAT-files and textual execution diaries
└── README.md                   # This documentation file
```

## Prerequisites

- **MATLAB Version**: R2020b or later (tested on MATLAB R2024b).
- **Toolboxes**: Base MATLAB with Statistics and Machine Learning Toolbox (optional; fallback functions included for standard statistical distributions).

## Execution Instructions

### Option 1: Headless / Batch Mode (Automated Pipeline)
From the project root directory, run:
```bash
matlab -batch "run('matlab/main.m'); exit;"
```

### Option 2: Interactive MATLAB Session
1. Open MATLAB.
2. In the Current Folder browser, navigate to the project directory: `d:/Quantum finance/09_10_2026/` (or the relative path where this repository resides).
3. Type `run('matlab/main.m')` in the Command Window and press Enter.

## Verification & Outputs

- **Log File**: Generated automatically at `matlab/results/matlab_execution_log.txt`.
- **Data File**: Saved workspace variables at `matlab/results/matlab_statistical_results.mat`.
- **Figures**: Exported vector PDF and 300 DPI PNG plots saved in `matlab/export_figures/`.
