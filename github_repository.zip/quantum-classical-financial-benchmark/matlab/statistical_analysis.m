function stats = statistical_analysis(y_true, y_pred_a, y_pred_b, prob_a, prob_b)
% STATISTICAL_ANALYSIS Performs rigorous statistical and econometric hypothesis testing.
% Implements:
% 1. Diebold-Mariano (1995) test with Harvey, Leybourne, Newbold (1997) correction.
% 2. McNemar's test for paired classification accuracy.
% 3. Percentile Bootstrap Confidence Intervals (95% CI) for accuracy.
%
% Inputs:
%   y_true   - Actual binary targets (0 or 1), Nx1
%   y_pred_a - Model A predicted binary classes (0 or 1), Nx1
%   y_pred_b - Model B predicted binary classes (0 or 1), Nx1
%   prob_a   - Model A predicted probability (optional)
%   prob_b   - Model B predicted probability (optional)

    N = length(y_true);
    
    % --- 1. Accuracy and Error vectors ---
    err_a = (y_pred_a ~= y_true);
    err_b = (y_pred_b ~= y_true);
    
    acc_a = mean(~err_a);
    acc_b = mean(~err_b);
    
    % --- 2. McNemar's Test ---
    % Contingency table
    n00 = sum(~err_a & ~err_b); % Both correct
    n11 = sum(err_a & err_b);   % Both incorrect
    n10 = sum(~err_a & err_b);  % A correct, B incorrect
    n01 = sum(err_a & ~err_b);  % A incorrect, B correct
    
    % Continuity-corrected McNemar statistic
    mcnemar_stat = (abs(n10 - n01) - 1)^2 / max(n10 + n01, 1e-8);
    mcnemar_p = 1 - chi2cdf(mcnemar_stat, 1);
    
    % --- 3. Diebold-Mariano Test (Harvey-Leybourne-Newbold 1997) ---
    % Loss differential sequence
    % If probability forecasts are provided, use Brier score (quadratic loss), else 0-1 loss
    if nargin >= 5 && ~isempty(prob_a) && ~isempty(prob_b)
        loss_a = (prob_a - y_true).^2;
        loss_b = (prob_b - y_true).^2;
    else
        loss_a = double(err_a);
        loss_b = double(err_b);
    end
    
    d = loss_a - loss_b;
    d_bar = mean(d);
    
    % Autocovariance at lag 0 (for h=1 one-step-ahead forecasts)
    gamma0 = var(d, 1); % sample variance
    
    % Standard DM statistic
    dm_stat = d_bar / sqrt(max(gamma0 / N, 1e-12));
    
    % HLN small-sample correction factor for h=1: sqrt((N - 1) / N)
    hln_factor = sqrt((N - 1) / N);
    dm_hln_stat = dm_stat * hln_factor;
    
    % Two-sided p-value using Student-t distribution with (N - 1) degrees of freedom
    dm_p = 2 * (1 - tcdf(abs(dm_hln_stat), N - 1));
    
    % --- 4. Percentile Bootstrap (1,000 resamples) ---
    n_boot = 1000;
    boot_acc_a = zeros(n_boot, 1);
    boot_acc_b = zeros(n_boot, 1);
    
    for b = 1:n_boot
        idx = randi(N, N, 1);
        boot_acc_a(b) = mean(y_pred_a(idx) == y_true(idx));
        boot_acc_b(b) = mean(y_pred_b(idx) == y_true(idx));
    end
    
    ci_a = prctile(boot_acc_a, [2.5, 97.5]);
    ci_b = prctile(boot_acc_b, [2.5, 97.5]);
    
    % Package Output
    stats.N = N;
    stats.acc_A = acc_a;
    stats.acc_B = acc_b;
    stats.ci_A = ci_a;
    stats.ci_B = ci_b;
    stats.mcnemar_stat = mcnemar_stat;
    stats.mcnemar_p = mcnemar_p;
    stats.n10 = n10;
    stats.n01 = n01;
    stats.dm_stat = dm_hln_stat;
    stats.dm_p = dm_p;
    stats.d_bar = d_bar;
    
    fprintf('Statistical Test Results (N = %d):\n', N);
    fprintf('  Model A Acc: %.4f [95%% CI: %.4f - %.4f]\n', acc_a, ci_a(1), ci_a(2));
    fprintf('  Model B Acc: %.4f [95%% CI: %.4f - %.4f]\n', acc_b, ci_b(1), ci_b(2));
    fprintf('  McNemar Chi2: %.4f (p-value: %.4f)\n', mcnemar_stat, mcnemar_p);
    fprintf('  Diebold-Mariano (HLN): %.4f (p-value: %.4f)\n', dm_hln_stat, dm_p);
end
