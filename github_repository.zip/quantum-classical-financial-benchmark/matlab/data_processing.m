function data_out = data_processing(sp500_file, vix_file)
% DATA_PROCESSING Ingests and processes financial time-series for JCF benchmark.
% Computes 10 technical indicators, log returns, and direction target.
% Strictly avoids look-ahead bias and data leakage.
%
% Usage:
%   data_out = data_processing('python/data/sp500_fred_daily.csv', 'python/data/vix_fred_daily.csv');

    fprintf('--- Executing Data Processing Pipeline in MATLAB ---\n');

    % Read S&P 500 data
    opts = detectImportOptions(sp500_file);
    opts.VariableNamingRule = 'preserve';
    opts.DataLines = [2 Inf];
    t_sp = readtable(sp500_file, opts);
    
    % Read VIX data
    opts_v = detectImportOptions(vix_file);
    opts_v.VariableNamingRule = 'preserve';
    opts_v.DataLines = [2 Inf];
    t_vix = readtable(vix_file, opts_v);

    % Filter non-numeric strings / missing values
    col_date_sp = t_sp{:, 1};
    col_val_sp = t_sp{:, 2};
    if iscell(col_val_sp)
        valid_sp = ~cellfun(@isempty, col_val_sp) & ~strcmp(col_val_sp, '.');
        col_date_sp = col_date_sp(valid_sp);
        col_val_sp = str2double(col_val_sp(valid_sp));
    end

    col_date_vix = t_vix{:, 1};
    col_val_vix = t_vix{:, 2};
    if iscell(col_val_vix)
        valid_vix = ~cellfun(@isempty, col_val_vix) & ~strcmp(col_val_vix, '.');
        col_date_vix = col_date_vix(valid_vix);
        col_val_vix = str2double(col_val_vix(valid_vix));
    end

    % Inner join by date
    [common_dates, ia, ib] = intersect(col_date_sp, col_date_vix, 'stable');
    prices = col_val_sp(ia);
    vix = col_val_vix(ib);
    N = length(prices);

    fprintf('Successfully matched %d trading days across S&P 500 and VIX.\n', N);

    % Compute Log Returns
    log_returns = [0; diff(log(prices))];

    % 1. SMA (10-day) ratio
    sma10 = movmean(prices, [9 0]);
    f_sma = (prices - sma10) ./ sma10;

    % 2. EMA (10-day) ratio
    alpha = 2 / (10 + 1);
    ema10 = filter(alpha, [1 -(1 - alpha)], prices);
    f_ema = (prices - ema10) ./ ema10;

    % 3. RSI (14-day)
    delta = [0; diff(prices)];
    gain = max(delta, 0);
    loss = max(-delta, 0);
    avg_gain = movmean(gain, [13 0]);
    avg_loss = movmean(loss, [13 0]);
    rs = avg_gain ./ max(avg_loss, 1e-10);
    f_rsi = 100 - (100 ./ (1 + rs));

    % 4. MACD Line (12 vs 26)
    alpha12 = 2 / (12 + 1);
    alpha26 = 2 / (26 + 1);
    ema12 = filter(alpha12, [1 -(1 - alpha12)], prices);
    ema26 = filter(alpha26, [1 -(1 - alpha26)], prices);
    f_macd = (ema12 - ema26) ./ prices;

    % 5. Bollinger %B (20-day, 2 std)
    sma20 = movmean(prices, [19 0]);
    std20 = movstd(prices, [19 0]);
    upper_b = sma20 + 2 * std20;
    lower_b = sma20 - 2 * std20;
    f_bb = (prices - lower_b) ./ max(upper_b - lower_b, 1e-6);

    % 6. Rate of Change (10-day)
    f_roc = zeros(N, 1);
    f_roc(11:end) = (prices(11:end) - prices(1:end-10)) ./ prices(1:end-10);

    % 7. Momentum (5-day return)
    f_mom = zeros(N, 1);
    f_mom(6:end) = (prices(6:end) - prices(1:end-5)) ./ prices(1:end-5);

    % 8. Realized Volatility (20-day annualised)
    f_vol = movstd(log_returns, [19 0]) * sqrt(252);

    % 9. VIX Level / 100
    f_vix = vix / 100;

    % 10. VIX 5-day delta
    f_vix_diff = zeros(N, 1);
    f_vix_diff(6:end) = (vix(6:end) - vix(1:end-5)) / 100;

    % Assemble Feature Matrix
    X_raw = [f_sma, f_ema, f_rsi, f_macd, f_bb, f_roc, f_mom, f_vol, f_vix, f_vix_diff];

    % Causal Forward Target: y_t = 1 if price(t+1) > price(t), else 0
    y_raw = zeros(N, 1);
    y_raw(1:end-1) = double(prices(2:end) > prices(1:end-1));

    % Truncate initial warmup window (35 days)
    warmup = 35;
    data_out.dates = common_dates(warmup:end-1);
    data_out.prices = prices(warmup:end-1);
    data_out.log_returns = log_returns(warmup:end-1);
    data_out.X = X_raw(warmup:end-1, :);
    data_out.y = y_raw(warmup:end-1);
    data_out.forward_returns = (prices(warmup+1:end) - prices(warmup:end-1)) ./ prices(warmup:end-1);
    data_out.feature_names = {'SMA10_Ratio', 'EMA10_Ratio', 'RSI14', 'MACD', 'Bollinger_B', ...
                              'ROC10', 'Mom5', 'RealVol20', 'VIX_Level', 'VIX_Change5'};

    fprintf('Processed %d usable samples with %d technical features.\n', length(data_out.y), size(data_out.X, 2));
end
