# Institutional Affiliations and Contact Registry

### Primary Author Affiliation
- **Author**: Priyanshu Sharma, Ph.D.
- **Department**: Department of Computational Finance and Economics
- **Institution**: Indian Institute of Technology Delhi
- **Address**: Hauz Khas
- **City/Postal Code**: New Delhi 110016
- **Country**: India
- **Email**: `priyanshu.sharma@alumni.iitd.ac.in`
- **ORCID**: `0009-0004-8921-7842`

### Co-Author Affiliation
- **Author**: Marcus Vance, Ph.D.
- **Department**: Center for Quantum Information and Machine Learning
- **Institution**: Imperial College London
- **Address**: Exhibition Road, South Kensington
- **City/Postal Code**: London SW7 2AZ
- **Country**: United Kingdom
- **Email**: `m.vance@imperial.ac.uk`
- **ORCID**: `0000-0002-4819-2041`

### Corresponding Author
- **Name**: Priyanshu Sharma, Ph.D.
- **Email**: `priyanshu.sharma@alumni.iitd.ac.in`
- **ORCID**: `0009-0004-8921-7842`
- **Phone**: `+91 11 2659 1000`
