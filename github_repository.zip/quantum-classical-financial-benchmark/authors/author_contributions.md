# Author Contributions Statement

This study adheres to the CRediT (Contributor Roles Taxonomy) standards. Author contributions are allocated as follows:

- **Dr. Priyanshu Sharma**: Conceptualization, Data curation, Formal analysis, Investigation, Methodology, Software (Python/Qiskit and MATLAB benchmark pipelines), Validation, Visualization, Writing – original draft, Project administration.
- **Dr. Marcus Vance**: Supervision, Resources, Validation, Methodology audit, Writing – review & editing.

All authors have critically reviewed and approved the final manuscript for submission to *The Journal of Computational Finance*.
