# Quantum and Classical Learning Pipelines: A Computational Benchmark for Financial Time-Series Prediction

[![Target Journal](https://img.shields.io/badge/Target%20Journal-Journal%20of%20Computational%20Finance-blue.svg)](https://www.risk.net/journal-of-computational-finance)
[![Publisher](https://img.shields.io/badge/Publisher-Risk.net%20%2F%20Infopro%20Digital-darkblue.svg)](https://www.risk.net/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python: 3.12](https://img.shields.io/badge/Python-3.12-green.svg)](https://www.python.org/)
[![Qiskit: 1.0+](https://img.shields.io/badge/Qiskit-1.0+-purple.svg)](https://qiskit.org/)
[![MATLAB: R2024b](https://img.shields.io/badge/MATLAB-R2024b-orange.svg)](https://www.mathworks.com/products/matlab.html)

This repository contains the complete, fully reproducible computational research package supporting the paper:

> **"A Computational Benchmark of Quantum and Classical Learning Pipelines for Financial Time-Series Prediction"**  
> *Targeted for submission to The Journal of Computational Finance (Risk.net / Infopro Digital).*

---

## 1. Executive Scientific Summary

Does quantum machine learning offer a genuine statistical or computational advantage over tuned classical models in empirical financial forecasting? 

This benchmark evaluates **Quantum Support Vector Machines (QSVM)** with second-order Pauli-$Z$ ($ZZ$) feature maps and **Variational Quantum Classifiers (VQC)** against five established classical learning baselines:
1. **Regularized Logistic Regression** (L2-penalized L-BFGS)
2. **Support Vector Machines with RBF Kernels** (SVC-RBF)
3. **Random Forests** (Breiman 2001)
4. **Gradient Boosted Decision Trees** (Friedman 2001 / XGBoost style)
5. **Multi-Layer Perceptrons** (ReLU feedforward neural network)

### Core Empirical Findings ($N = 1,257$ Out-of-Sample Trading Days, 2020–2024):
- **No Statistical Predictive Quantum Advantage ($H_{0,1}$ not rejected):** Directional forecasting accuracy for quantum models (QSVM-ZZ: 51.47\%; VQC: 50.84\%) is statistically indistinguishable from, or lower than, classical Gradient Boosting (53.70\%) and Logistic Regression (53.70\%).
- **Econometric Test Parity ($H_{0,2}$ not rejected):** The Diebold--Mariano test with Harvey--Leybourne--Newbold (HLN 1997) finite-sample correction yields $DM = -1.1985, p = 0.2309$ against Logistic Regression, and $DM = -0.2318, p = 0.8167$ against Random Forest. McNemar's paired classification test confirms no significant difference ($p = 0.2479$).
- **Execution Latency Fragility:** Under realistic 1-day operational execution delay, the QSVM Sharpe ratio plunges to $-0.320$ (annualised return $-6.94\%$, MaxDD $49.18\%$), while classical Polynomial SVM maintains robust risk-adjusted profitability (Sharpe $+0.519$, annualised return $+11.39\%$). An optimistic zero-latency benchmark produces an apparent Sharpe of $+0.813$ via implicit volatility filtering, but this collapses under operational delay or transaction costs ($827$ trades).
- **Variational Classifier Trainability Failure:** VQC suffered severe economic degradation (cumulative net return $-50.95\%$, annualised return $-13.31\%$, Sharpe $-0.648$ under zero latency; annualised return $-1.04\%$, Sharpe $-0.034$ under 1-day lag) consistent with, but not sufficient to establish, barren-plateau behaviour in noisy financial data.
- **Computational Overhead & Measurement Constraints:** QSVM classical simulation runtime scaled $85.7\times$ from $n=2$ (0.15s) to $n=6$ (12.85s). On physical NISQ quantum hardware under full-kernel assumptions (10,000 shots, 10 kHz repetition rate), raw execution would require approximately 17.2 days of single-device measurement time per daily retrain.

---

## 2. Repository Directory Structure

```
.
├── CITATION.cff                      # Machine-readable citation metadata
├── LICENSE                           # MIT Open-Source License
├── README.md                         # This master documentation
├── requirements.txt                  # Python pip dependencies
├── environment.yml                   # Conda virtual environment
├── authors/                          # Central author & affiliation metadata
│   ├── author_list.yaml
│   ├── author_list.csv
│   └── author_contributions.md
├── figures/                          # 12 Publication figure directories
│   ├── figure01/ ... figure12/       # PDF, SVG, 300-DPI PNG, JPG + .py/.m sources
├── journal_requirements/             # Verified JCF/Risk journal author guidelines
├── latex/                            # Modular LaTeX manuscript project
│   ├── main.tex                      # Master LaTeX document (Blinded)
│   ├── references.bib                # 112 verified references with active DOIs
│   ├── preamble/                     # Packages, styling, natbib config
│   ├── macros/                       # Mathematical quantum/finance notation
│   ├── sections/                     # 11 Modular manuscript sections
│   ├── tables/                       # 8 LaTeX booktabs table sources
│   ├── figures/                      # Vector PDF and high-res raster figures
│   └── supplementary/                # Supplementary Information document
├── matlab/                           # Complete MATLAB R2024b automation suite
│   ├── main.m                        # Master test runner
│   ├── data_processing.m             # Technical indicators & financial series
│   ├── statistical_analysis.m        # Diebold-Mariano (HLN) & McNemar testing
│   ├── plotting/                     # Native MATLAB figure routines
│   └── export_figures/               # MATLAB exported PDF, PNG graphics
├── python/                           # Complete Python/Qiskit benchmark suite
│   ├── main.py                       # Master execution script
│   ├── data/                         # Pristine daily S&P 500 and VIX CSV data
│   ├── preprocessing/                # Technical feature engineering
│   ├── classical_models/             # Pure NumPy/SciPy classical ML algorithms
│   ├── quantum_models/               # Qiskit statevector QSVM & VQC pipelines
│   ├── figures/                      # plot_figures.py (12 figures generator)
│   └── tables/                       # Full benchmark result CSVs and JSONs
├── quality_control/                  # 5 Scientific integrity & audit reports
├── research_gap/                     # Formal literature gap and hypotheses
├── submission/                       # Submission-ready artifacts
│   ├── Title_Page.pdf & .docx        # Unblinded Title Page with author metadata
│   ├── Manuscript_Blinded.pdf & .tex # Blinded main manuscript for peer review
│   ├── Manuscript.docx               # Full Word manuscript
│   ├── Title_Page.pdf & .docx        # Complete author identities and metadata
│   ├── Cover_Letter.pdf & .docx      # Formally addressed cover letter
│   ├── AI_Disclosure.pdf & .docx     # Transparent AI assistance disclosure statement
│   └── Supplementary_Information.pdf # 10-page mathematical & tabular supplement
└── FINAL_SUBMISSION/                 # Consolidated submission package
```

---

## 3. Quick Start & Replication Instructions

### Replication from Submission Package / Source Code

1. **Extract and create virtual environment:**
```bash
# From extracted submission directory:
python -m venv venv
# On Windows:
.\venv\Scripts\activate
# On Linux/macOS:
source venv/bin/activate
pip install -r requirements.txt
```

2. **Instant Independent Numerical Reproduction (1-Step Audit):**
```bash
python python/tools/reproduce_computational_tests.py
```
This standalone script recalculates all reported metrics directly from `oos_predictions_full.csv` in under 5 seconds:
- Verifies ground-truth class alignment ($675$ positive vs $582$ negative days)
- Verifies continuous probability score distributions for Logistic Regression and MLP
- Recalculates confusion matrices, directional Accuracy, and Precision (Supplementary Table S4)
- Recalculates Diebold-Mariano (HLN 1997) and Newey-West HAC ($q=7$) econometric test statistics (Manuscript Table 5)
- Confirms zero serial dependence in forecast loss differentials via Ljung-Box diagnostics

3. **Run full out-of-sample benchmark (end-to-end retrain):**
```bash
python python/main.py
```
This executes data ingestion from FRED, builds 10 technical indicators, conducts chronological walk-forward cross-validation across 4 regimes, runs econometric tests, and exports full metric tables to `python/tables/`.

4. **Generate all 12 publication-quality figures:**
```bash
python python/figures/plot_figures.py
```
Exports vector PDF, SVG, 300 DPI PNG, and JPG graphics into `figures/figure01/` through `figures/figure12/`.

### Option B: MATLAB R2024b Pipeline

From the project root directory, run in batch/headless mode:
```bash
matlab -batch "run('matlab/main.m'); exit;"
```
Or launch MATLAB interactively and run `matlab/main.m`.

### Option C: LaTeX Manuscript Compilation

```bash
cd latex
pdflatex -interaction=nonstopmode main.tex
bibtex main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
```

---

## 4. Citation

```bibtex
@article{QuantumFinanceBenchmark2026,
  title     = {A Computational Benchmark of Quantum and Classical Learning Pipelines for Financial Time-Series Prediction},
  author    = {Authors Omitted for Double-Blind Peer Review},
  journal   = {The Journal of Computational Finance},
  year      = {2026},
  publisher = {Risk.net / Infopro Digital Services Limited},
  url       = {https://github.com/quantum-classical-benchmarks/quantum-classical-financial-benchmark}
}
```

---

## 5. License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
