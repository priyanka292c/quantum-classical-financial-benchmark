# JCF Figure and Table Requirements
**Target Journal:** The Journal of Computational Finance (Risk.net)

### 1. Figure Requirements
- **Integration:** All figures must be referenced in the main text, embedded in the PDF draft at or near first appearance, and also supplied as separate editable files.
- **Legends & Captions:** Each figure must feature a clearly marked heading and a concise, informative one-sentence caption explaining the display.
- **Allowed Formats:**
  - **Vector Graphics (Preferred):** SVG (specifically supported via MATLAB SVG or Python SVG), PDF (generated from matplotlib/Illustrator), EPS.
  - **Raster Graphics:** Only acceptable where photographic or dense heatmap data necessitates it. Minimum resolution: **300 DPI**. JPG/PNG/TIF must not be used for line plots or schematic diagrams where vector formats can be edited.
- **Color Palettes:** Figures appear in full color online. Use accessible, high-contrast palettes (e.g., Viridis, Seaborn deep, colorblind-friendly blue/orange tones). Avoid unreadable pastel shades or saturated rainbows.
- **Naming Convention:** Clearly labeled by sequential figure number: `figure01.pdf`, `figure01.svg`, `figure01.png`, etc.
- **Source Scripts:** Reproducibility dictates that each figure folder contains both Python (`.py`) and/or MATLAB (`.m`) generation scripts.

---

### 2. Table Requirements
- **Integration:** All tables must be numbered sequentially, introduced prior to or immediately following appearance, and accompanied by a concise explanatory caption.
- **Formatting Standards:**
  - Professional booktabs style (top rule, mid rule, bottom rule; no vertical lines).
  - Clear column headings with units or statistical metrics clearly indicated (e.g., annualized returns, Sharpe ratio, $p$-value).
  - Numbers formatted to appropriate significant figures (typically 2 to 4 decimal places).
- **Deliverables:**
  - Embedded directly in LaTeX (`.tex`) and Word (`.docx`).
  - Separately exported as machine-readable `.csv` and standalone `.tex` snippets in `/tables/`.

---

### 3. Figure/Table - Text Consistency Mandate
- **Zero Orphan Displays:** No figure or table may appear without direct reference and interpretation in the prose text.
- **Audit Requirement:** The automated build system must verify that:
  $$\text{Audit}(\text{Figure}_k) = \text{Referenced in text} \land \text{Discussed in text}$$
  $$\text{Audit}(\text{Table}_m) = \text{Referenced in text} \land \text{Discussed in text}$$
