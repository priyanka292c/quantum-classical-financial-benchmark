# JCF Reference and Citation Style Guide
**Target Journal:** The Journal of Computational Finance (Risk.net)

### 1. In-Text Citation Style: The Chicago Manual of Style (Author-Date)
In-text citations must follow the author-date system:
- **Single author:** `(Cont 2001)` or `Cont (2001) argues that...`
- **Two authors:** `(Baker and Wurgler 2006)` or `Baker and Wurgler (2006)`
- **Three or more authors:** `(Havens et al. 2021)` or `Havens et al. (2021)`
- **Multiple citations in one parenthesis:** Ordered chronologically or alphabetically, separated by semicolons: `(Cont 2001; Baker and Wurgler 2006; Reisinger and Wissmann 2020)`.

*Strict Journal Rule:* Avoid citation dumping. Citations must be placed directly at the specific claim or equation they support.

---

### 2. Bibliography List Style: APA Style with DOIs
The reference list must be formatted in **APA style**:
- Arranged in **alphabetical order** by the first author's surname.
- Works by the identical author(s) arranged in **chronological order** (earliest first).
- Author format: Surname followed by initials (e.g., `Baker, M., and Wurgler, J.`).
- Journal titles set in italics, followed by volume (in italics), issue in parentheses, and page range.
- Mandatory inclusion of digital object identifiers (DOIs) formatted as `https://doi.org/...`.

#### Official Example from Risk Guidelines:
> Baker, M., and Wurgler, J. (2006). Investor sentiment and the cross-section of stock returns. *Journal of Finance* 61(4), 1654–1680. https://doi.org/10.1111/j.1540-6261.2006.00885.x

#### Book Example:
> Goodfellow, I., Bengio, Y., and Courville, A. (2016). *Deep Learning*. MIT Press, Cambridge, MA.

#### Edited Volume / Book Chapter Example:
> Nielsen, M. A., and Chuang, I. L. (2010). *Quantum Computation and Quantum Information* (10th anniversary ed.). Cambridge University Press, Cambridge. https://doi.org/10.1017/CBO9780511976667

---

### 3. Strict Pre-Publication Requirements
1. **Preprint Restrictions:** No arXiv-only references are permitted in the final submitted bibliography. Any preprint referenced during research must be traced to its formally published peer-reviewed journal or conference edition.
2. **DOI Verification:** Every entry with an assigned DOI must be resolved against Crossref to confirm exact author list, article title, journal name, year, and volume.
3. **Completeness:** Every bibliography item must be cited at least once in the main text. Zero orphan references.
