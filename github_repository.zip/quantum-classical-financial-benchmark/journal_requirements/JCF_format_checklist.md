# JCF Format Checklist
**Target Journal:** The Journal of Computational Finance (Risk.net / Infopro Digital)

| Item | Requirement | Status / Verification Method |
| :--- | :--- | :--- |
| **Document Structure** | Title Page (separate), Legends, Abstract, Keywords, Key Messages, Title, Main Text (Intro, Lit Review, Data, Methodology, Results, Discussion, Conclusion), Declarations of Interest, Acknowledgements, References | Pre-checked against guidelines |
| **Title Page Document** | Separate file: Full author names, affiliations, emails, postal addresses, corresponding author contact, short running header (<=50 char), word count, figure/table counts | `Title_Page.docx` / `Title_Page.pdf` |
| **Blinded Main File** | No author names, institutions, emails, or self-identifying statements in PDF text or document metadata | `Manuscript_Blinded.pdf` / `.tex` |
| **Running Header** | Maximum 50 characters including spaces | Verified on title page |
| **Abstract Length** | Strictly 150 – 200 words, single paragraph, self-contained, no citation tags | Word count audit scripted |
| **Keywords** | Exactly 4 to 6 specific, non-obscure keywords | 5 keywords configured |
| **Key Messages** | 3 to 4 bullet points, **each strictly <= 85 characters** | Character length audit scripted |
| **Word Count** | <= 10,000 words for main research paper (excluding supplementary materials) | Automated word counter |
| **In-Text Citations** | Author-date (Chicago Manual of Style), e.g., `(Author Year)` or `Author (Year)` | Scripted bidirectional audit |
| **Bibliography Style** | APA style, alphabetical by author, chronological for identical authors, initials only | Scripted BibTeX / APA formatter |
| **DOI Inclusion** | Valid, resolvable DOI for every journal/conference publication | Automated Crossref resolver |
| **Figures** | Vector format (SVG / PDF / EPS), >= 300 DPI if raster, numbered sequentially, separate files | Exported to `/figures/` |
| **Tables** | Embedded in document + separate editable files (LaTeX/CSV/Word), numbered sequentially | Exported to `/tables/` |
| **Declarations** | Mandatory section "Declarations of Interest": explicit conflict statement | Embedded before references |
| **AI Disclosure** | Mandatory explicit disclosure detailing AI tools and scope of use | Embedded in declarations / SI |
| **Supplementary Info** | Derivations, extended benchmarks, algorithmic pseudocode, data dictionary | Packaged as `Supplementary_Information.pdf` |
