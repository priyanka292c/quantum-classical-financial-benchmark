# The Journal of Computational Finance (Risk.net / Infopro Digital)
## Current Official Journal Requirements (Verified Live)

- **Journal Name:** The Journal of Computational Finance (JCF)
- **Publisher:** Risk.net / Infopro Digital Services Limited, London, UK
- **ISSN:** 1755-2850 (online)
- **Editor-in-Chief:** Christoph Reisinger (University of Oxford)
- **First Published:** September 1997
- **Official URLs:**
  - Journal Homepage: `https://www.risk.net/journal-of-computational-finance`
  - Author Guidelines: `https://www.risk.net/static/risk-journals-submission-guidelines`
- **Indexing & Abstracting:** Scopus, Web of Science (SSCI), MathSciNet, EconLit, EconBiz, Cabell's Directory.

---

### 1. Aims and Scope
The Journal of Computational Finance is an international peer-reviewed journal dedicated to advancing knowledge in the area of financial mathematics. The journal focuses on:
- Measurement, management, and analysis of financial risk.
- Numerical and computational techniques in pricing, hedging, and risk management of financial instruments.
- Simulation approaches in pricing and risk management (advances in Monte Carlo, quasi-Monte Carlo, market-factor simulation).
- Optimization techniques in hedging and risk management.
- Fundamental numerical analysis relevant to finance (discretization, stability, time-series analysis).
- High-performance, quantum, and machine learning computational paradigms evaluated with numerical rigor.

---

### 2. Peer Review and Anonymization Requirements
- **Review Model:** External, independent, single-blinded peer review.
- **Anonymization:** 
  - The main manuscript PDF must **NOT** contain author names, affiliations, email addresses, or self-identifying acknowledgements.
  - Author identities are supplied **strictly via a separate Title Page document**.

---

### 3. Submission Documents & File Structure
Authors must submit:
1. **Separate Title Page (`Title_Page.docx` / `Title_Page.pdf`)** containing:
   - Full article title.
   - Full names, institutional affiliations, postal addresses, and email addresses of all authors.
   - Designated corresponding author with full contact details.
   - Running header / short title (maximum 50 characters).
   - Exact manuscript word count.
   - Number of figures and number of tables.
2. **Blinded Main Manuscript (`Manuscript_Blinded.pdf` / `Manuscript_Blinded.tex` / `Manuscript_Blinded.docx`)**:
   - Title (concise and descriptive).
   - Abstract (150–200 words, strictly one paragraph, self-contained, no citations).
   - Keywords (4–6 specific keywords).
   - Key messages (3–4 bullet points, **each bullet strictly <= 85 characters**).
   - Figure and Table legends with one-sentence captions.
   - Main text sections: Introduction, Literature Review, Data, Methodology, Results, Discussion, Conclusion.
   - Declarations of Interest.
   - Acknowledgements (blinded during review).
   - References (Chicago/APA author-date style, with DOIs).
3. **Separate Editable Figure Files**:
   - Vector formats preferred: MATLAB SVG/PDF, Illustrator EPS/PDF.
   - Minimum 300 DPI if raster format is required.
   - Named clearly by figure number (e.g., `figure01.pdf`, `figure01.svg`).
4. **Tables**:
   - Included in main document and submitted as separate editable files (LaTeX/Word/Excel/CSV).
5. **Supplementary Information**:
   - Published online freely, linked to paper (proofs, code, extra experiments, data schema).

---

### 4. Word Count Limits
- **Research Papers:** Maximum 10,000 words (excluding title page and standalone supplementary material).
- **Forum Papers:** Maximum 7,000 words.
- *Strict Rule:* Conciseness and mathematical/computational rigor are prioritized over artificial inflation.

---

### 5. Abstract, Keywords, and Key Messages
- **Abstract:** Exactly 150 to 200 words in a single paragraph. States purpose, methodology, principal numerical results, and major conclusions. Standalone, no citations.
- **Keywords:** 4 to 6 specific keywords.
- **Key Messages:** 3 to 4 bullet points highlighting core empirical/computational findings. **Constraint: Maximum 85 characters per bullet point.**

---

### 6. Reference Style and DOI Requirements
- **In-Text Citation:** Author-date format following *The Chicago Manual of Style* (e.g., Baker and Wurgler 2006; Reisinger and Wissmann 2020).
- **Reference List Format:** Formatted in APA style, alphabetical order by primary author's surname, chronological order for multiple publications by the same author.
- **Author Names:** Surname followed by initials.
- **DOI Requirement:** Mandatory inclusion of active, valid DOIs for all indexed literature.
- **ArXiv Policy:** Only formally published journal/book/conference versions are acceptable; no raw arXiv-only preprints in final bibliography.

---

### 7. Artificial Intelligence Disclosure Policy
Risk Journals require explicit acknowledgement of qualifying AI usage:
- GenAI is permitted only for:
  1. Extracting and organizing data;
  2. Conducting background research (as a search engine);
  3. Editing and language polishing (e.g., Grammarly).
- AI tools and their precise functional roles must be stated in a dedicated "Use of Artificial Intelligence" section.
- AI cannot be listed as an author. Authors maintain full responsibility for scientific accuracy, references, and results.

---

### 8. Declarations and Editorial Statements
- **Declarations of Interest:** Mandatory heading. Standard declaration when no competing financial interest exists:
  *"The authors report no conflicts of interest. The authors alone are responsible for the content and writing of the paper."*
- **Proofs:** 48-hour turnaround window upon acceptance.
