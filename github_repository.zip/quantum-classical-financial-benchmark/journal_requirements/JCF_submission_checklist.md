# JCF Submission Checklist
**Journal:** The Journal of Computational Finance (Risk.net)
**Publisher:** Infopro Digital Services Limited, London

### Phase 1: Pre-Submission Preparation
- [x] Scope verification: Manuscript addresses computational finance, quantitative risk modeling, financial time-series, or numerical optimization.
- [x] Editorial policies review: All co-authors agree to terms and copyright policies.
- [x] Originality: Manuscript has not been published or submitted simultaneously elsewhere.
- [x] Word count validation: Main text does not exceed 10,000 words.
- [x] Supplementary information: Extended derivations, proof matrices, and hyperparameter tables separated into online SI.

### Phase 2: Document Artifacts to Generate
- [x] `Title_Page.docx` / `Title_Page.pdf`:
  - Full article title.
  - Author details (full names, affiliations, full postal addresses, emails).
  - Corresponding author marked with email and telephone.
  - Short running header (<= 50 characters).
  - Explicit word count, figure count, table count.
- [x] `Manuscript_Blinded.pdf` / `Manuscript_Blinded.tex`:
  - Completely anonymized (no names, acknowledgements blinded, institutional identifiers omitted).
  - Abstract (150–200 words).
  - Keywords (4–6).
  - Key messages (3–4 bullets, max 85 characters each).
  - Introduction, Literature Review, Data, Methodology, Results, Discussion, Conclusion.
  - Declarations of Interest.
  - References list (APA style, Chicago author-date citations).
- [x] `Cover_Letter.docx` / `Cover_Letter.pdf`:
  - Addressed to Editor-in-Chief (Prof. Christoph Reisinger).
  - Outlining novelty, computational significance, and empirical rigor.
  - Confirming no simultaneous submission.
- [x] `Supplementary_Information.pdf`:
  - Supplementary derivations, circuit designs, extended statistical tables, reproducibility guidelines.

### Phase 3: Technical & Figure Requirements
- [x] Editable vector figure formats: PDF and SVG for every figure.
- [x] Separate figure files in `/figures/` numbered sequentially (`figure01.pdf`, `figure01.svg`, etc.).
- [x] Figure source scripts included (`.py` and `.m`).
- [x] Tables exported in editable formats (LaTeX `.tex`, `.csv`, `.docx`).
- [x] Verification of zero unreferenced or orphan figures/tables.

### Phase 4: Reference & Integrity Verification
- [x] Minimum 80 verified scholarly references.
- [x] 100% active, resolved DOIs verified against Crossref / official registries.
- [x] Elimination of raw arXiv-only preprints (all cited literature matched to published peer-reviewed versions).
- [x] Bidirectional citation check: Every citation in text appears in bibliography; every bibliography entry is cited in text.
- [x] No data leakage, look-ahead bias, or cherry-picked backtest claims.
- [x] Nuanced, evidence-based claims regarding quantum computational simulation vs classical benchmarks.
