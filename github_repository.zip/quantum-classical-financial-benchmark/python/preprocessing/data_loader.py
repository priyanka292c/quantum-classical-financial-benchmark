"""
Data loading and feature engineering module for S&P 500 financial time series.
Strictly eliminates look-ahead bias and autocorrelation leakage.
Uses standard library csv and numpy for maximum portability and robustness.
"""
import csv
import math
from datetime import datetime
import numpy as np

def load_and_preprocess_market_data(sp500_path, vix_path, start_date="2018-01-01", end_date="2024-12-31"):
    """
    Loads daily FRED S&P 500 and VIX data, computes technical and volatility indicators,
    and returns causally aligned feature matrix X, binary direction target y, and forward return r_fwd.
    """
    # 1. Load S&P 500
    sp_data = {}
    with open(sp500_path, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if len(row) >= 2 and row[1].strip() != ".":
                try:
                    dt = row[0].strip()
                    val = float(row[1].strip())
                    sp_data[dt] = val
                except ValueError:
                    continue

    # 2. Load VIX
    vix_data = {}
    with open(vix_path, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if len(row) >= 2 and row[1].strip() != ".":
                try:
                    dt = row[0].strip()
                    val = float(row[1].strip())
                    vix_data[dt] = val
                except ValueError:
                    continue

    # Common sorted dates
    common_dates = sorted(list(set(sp_data.keys()).intersection(set(vix_data.keys()))))
    
    # Filter by date range (allow some warmup prior to start_date)
    dt_warmup_start = datetime.strptime("2017-06-01", "%Y-%m-%d")
    dt_end = datetime.strptime(end_date, "%Y-%m-%d")
    filtered_dates = [d for d in common_dates if dt_warmup_start <= datetime.strptime(d, "%Y-%m-%d") <= dt_end]

    dates = filtered_dates
    prices = np.array([sp_data[d] for d in dates], dtype=np.float64)
    vix = np.array([vix_data[d] for d in dates], dtype=np.float64)
    N = len(prices)

    # Daily log returns
    log_returns = np.zeros(N)
    log_returns[1:] = np.log(prices[1:] / prices[:-1])

    # Feature Engineering (strictly using past and current prices up to day t)
    # 1. SMA 20 Ratio: SMA_20(t) / P_t - 1
    sma_20 = np.full(N, np.nan)
    for i in range(19, N):
        sma_20[i] = np.mean(prices[i-19:i+1])
    feat_sma_ratio = sma_20 / prices - 1.0

    # 2. EMA 12 and EMA 26 Ratio
    def calc_ema(arr, span):
        alpha = 2.0 / (span + 1.0)
        ema = np.zeros(len(arr))
        ema[0] = arr[0]
        for t in range(1, len(arr)):
            ema[t] = alpha * arr[t] + (1 - alpha) * ema[t-1]
        return ema

    ema_12 = calc_ema(prices, 12)
    ema_26 = calc_ema(prices, 26)
    feat_ema_ratio = (ema_12 / ema_26) - 1.0

    # 3. MACD Histogram
    macd_line = ema_12 - ema_26
    macd_signal = calc_ema(macd_line, 9)
    feat_macd_hist = (macd_line - macd_signal) / prices  # normalized by price

    # 4. RSI 14 (Relative Strength Index)
    feat_rsi = np.full(N, np.nan)
    deltas = np.diff(prices)
    gains = np.where(deltas > 0, deltas, 0.0)
    losses = np.where(deltas < 0, -deltas, 0.0)
    
    avg_gain = np.mean(gains[:14])
    avg_loss = np.mean(losses[:14])
    if avg_loss == 0:
        feat_rsi[14] = 100.0
    else:
        rs = avg_gain / avg_loss
        feat_rsi[14] = 100.0 - (100.0 / (1.0 + rs))

    for i in range(14, len(deltas)):
        avg_gain = (avg_gain * 13.0 + gains[i]) / 14.0
        avg_loss = (avg_loss * 13.0 + losses[i]) / 14.0
        idx = i + 1
        if avg_loss == 0:
            feat_rsi[idx] = 100.0
        else:
            rs = avg_gain / avg_loss
            feat_rsi[idx] = 100.0 - (100.0 / (1.0 + rs))

    # 5. Bollinger Band %B (20-day, 2 std dev)
    feat_bollinger_pctb = np.full(N, np.nan)
    feat_bollinger_width = np.full(N, np.nan)
    for i in range(19, N):
        window = prices[i-19:i+1]
        mu = np.mean(window)
        sigma = np.std(window)
        upper = mu + 2.0 * sigma
        lower = mu - 2.0 * sigma
        denom = upper - lower
        if denom > 0:
            feat_bollinger_pctb[i] = (prices[i] - lower) / denom
            feat_bollinger_width[i] = denom / mu

    # 6. ROC 10 (Rate of Change)
    feat_roc_10 = np.full(N, np.nan)
    feat_roc_10[10:] = (prices[10:] - prices[:-10]) / prices[:-10]

    # 7. Momentum 5 (5-day return)
    feat_mom_5 = np.full(N, np.nan)
    feat_mom_5[5:] = (prices[5:] - prices[:-5]) / prices[:-5]

    # 8. 20-Day Realized Volatility (Annualized)
    feat_realized_vol = np.full(N, np.nan)
    for i in range(19, N):
        feat_realized_vol[i] = np.std(log_returns[i-19:i+1]) * math.sqrt(252.0)

    # 9. VIX Level (normalized) & 5-day VIX change
    feat_vix_level = vix / 100.0
    feat_vix_change = np.full(N, np.nan)
    feat_vix_change[5:] = (vix[5:] - vix[:-5]) / vix[:-5]

    # Compile raw feature matrix
    raw_features = np.column_stack([
        feat_sma_ratio,
        feat_ema_ratio,
        feat_rsi / 100.0,      # scale RSI to [0, 1]
        feat_macd_hist,
        feat_bollinger_pctb,
        feat_roc_10,
        feat_mom_5,
        feat_realized_vol,
        feat_vix_level,
        feat_vix_change
    ])

    feature_names = [
        "SMA_Ratio_20",
        "EMA_Ratio_12_26",
        "RSI_14",
        "MACD_Hist",
        "Bollinger_PctB",
        "ROC_10",
        "Momentum_5",
        "Realized_Vol_20",
        "VIX_Level",
        "VIX_Change_5"
    ]

    # Target variable: Next day return sign
    # y_t = 1 if P_{t+1} > P_t (log_returns[t+1] > 0) else 0
    # forward return: r_fwd[t] = log_returns[t+1]
    y_target = np.zeros(N, dtype=np.int64)
    r_forward = np.zeros(N, dtype=np.float64)
    y_target[:-1] = (log_returns[1:] > 0).astype(np.int64)
    r_forward[:-1] = log_returns[1:]

    # Valid indices: drop warmup (first 35 rows) and last row (no forward return)
    dt_target_start = datetime.strptime(start_date, "%Y-%m-%d")
    valid_mask = np.zeros(N, dtype=bool)
    for i in range(35, N - 1):
        if datetime.strptime(dates[i], "%Y-%m-%d") >= dt_target_start:
            if not np.any(np.isnan(raw_features[i])):
                valid_mask[i] = True

    aligned_dates = [dates[i] for i in range(N) if valid_mask[i]]
    X_clean = raw_features[valid_mask]
    y_clean = y_target[valid_mask]
    r_clean = r_forward[valid_mask]
    prices_clean = prices[valid_mask]

    return {
        "dates": aligned_dates,
        "X": X_clean,
        "y": y_clean,
        "r_fwd": r_clean,
        "prices": prices_clean,
        "feature_names": feature_names
    }


def get_walk_forward_splits(dates, folds_config):
    """
    Generates chronological train and test indices for walk-forward validation.
    """
    splits = []
    date_objs = [datetime.strptime(d, "%Y-%m-%d") for d in dates]

    for fold in folds_config:
        train_end_dt = datetime.strptime(fold["train_end"], "%Y-%m-%d")
        test_start_dt = datetime.strptime(fold["test_start"], "%Y-%m-%d")
        test_end_dt = datetime.strptime(fold["test_end"], "%Y-%m-%d")

        train_indices = [i for i, d in enumerate(date_objs) if d <= train_end_dt]
        test_indices = [i for i, d in enumerate(date_objs) if test_start_dt <= d <= test_end_dt]

        splits.append({
            "name": fold["name"],
            "regime": fold["regime"],
            "train_idx": np.array(train_indices, dtype=np.int64),
            "test_idx": np.array(test_indices, dtype=np.int64),
            "test_dates": [dates[i] for i in test_indices]
        })

    return splits


def scale_features(X_train, X_test, method="standard", feature_indices=None):
    """
    Fits scaler strictly on X_train and transforms both X_train and X_test.
    Zero data leakage across folds.
    method: 'standard' (z-score) or 'minmax_pi' (maps to [0, pi] for quantum angle/ZZ encoding).
    """
    if feature_indices is not None:
        X_tr = X_train[:, feature_indices]
        X_te = X_test[:, feature_indices]
    else:
        X_tr = X_train.copy()
        X_te = X_test.copy()

    if method == "standard":
        mean = np.mean(X_tr, axis=0)
        std = np.std(X_tr, axis=0)
        std[std == 0] = 1.0
        X_tr_scaled = (X_tr - mean) / std
        X_te_scaled = (X_te - mean) / std
    elif method == "minmax_pi":
        # First standardize, then squash via tanh into [-1, 1], then scale to [0.05*pi, 0.95*pi]
        mean = np.mean(X_tr, axis=0)
        std = np.std(X_tr, axis=0)
        std[std == 0] = 1.0
        z_tr = (X_tr - mean) / std
        z_te = (X_te - mean) / std
        
        # Robust sigmoid/tanh squashing
        tanh_tr = np.tanh(z_tr / 2.0)  # [-1, 1]
        tanh_te = np.tanh(z_te / 2.0)
        
        # Map [-1, 1] to [0.1 * pi, 0.9 * pi] to avoid boundary degeneracy
        X_tr_scaled = (tanh_tr + 1.0) * 0.4 * math.pi + 0.1 * math.pi
        X_te_scaled = (tanh_te + 1.0) * 0.4 * math.pi + 0.1 * math.pi
    else:
        raise ValueError(f"Unknown scaling method: {method}")

    return X_tr_scaled, X_te_scaled


def fit_pca_projection(X_train, n_components=4):
    """
    Fits PCA strictly on training data via SVD to project D-dimensional features down to n_components.
    Zero look-ahead leakage across folds.
    Returns projection model containing mean, components, explained variance ratios, and singular values.
    """
    mean = np.mean(X_train, axis=0)
    X_c = X_train - mean
    U, S, Vt = np.linalg.svd(X_c, full_matrices=False)
    components = Vt[:n_components, :]  # Shape: [n_components, D]
    explained_var = (S ** 2) / max(1, (len(X_train) - 1))
    total_var = np.sum(explained_var)
    var_ratio = explained_var[:n_components] / total_var if total_var > 0 else np.zeros(n_components)
    return {
        "mean": mean,
        "components": components,
        "explained_variance_ratio": var_ratio,
        "total_explained_variance": float(np.sum(var_ratio)),
        "singular_values": S[:n_components]
    }


def transform_pca(X, pca_model):
    """
    Transforms feature matrix X using pre-fitted PCA projection.
    """
    X_c = X - pca_model["mean"]
    return np.dot(X_c, pca_model["components"].T)


def compute_adf_statistics(X, feature_names):
    """
    Computes empirical Dickey-Fuller test statistics for each feature series.
    Returns list of dictionaries detailing t-statistics, estimated p-values, and stationarity classification.
    """
    results = []
    from scipy.stats import linregress
    for j, name in enumerate(feature_names):
        series = X[:, j]
        diff = np.diff(series)
        lag = series[:-1]
        slope, intercept, r_val, p_val, std_err = linregress(lag, diff)
        t_stat = slope / std_err if std_err > 0 else 0.0
        results.append({
            "feature": name,
            "t_stat": float(t_stat),
            "p_value_approx": float(p_val),
            "is_stationary": bool(t_stat < -2.86)
        })
    return results
