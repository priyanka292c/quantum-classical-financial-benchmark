"""
Pixel-Perfect Figure 1 Generator
Reproduces the reference design with 1-to-1 coordinate fidelity, elegant serif typography,
and reconciled degree 2, 3 search space.
"""
import os
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch, Rectangle

# Styling parameters
plt.rcParams.update({
    "font.size": 11,
    "axes.labelsize": 11,
    "axes.titlesize": 12,
    "mathtext.fontset": "stix",
    "font.family": "serif",
    "font.serif": ["Times New Roman", "DejaVu Serif", "STIXGeneral", "serif"],
    "figure.dpi": 300,
    "savefig.dpi": 300
})

def draw_card(ax, x, y, w, h, h_head, title, items, border_color, head_bg, head_text_color, body_bg="#ffffff", title_size=12.2, item_size=10.4, lw=1.6):
    """
    Renders an academic card with:
      - Rounded outer boundary (FancyBboxPatch)
      - Solid colored header banner with rounded top corners clipped to outer box
      - Crisp dividing line between header and body
      - Bullet items with exact positioning and hanging indent
    """
    # 1. Outer rounded box
    outer_box = FancyBboxPatch((x, y), w, h,
                               boxstyle="round,pad=0.0,rounding_size=10.0",
                               facecolor=body_bg, edgecolor=border_color,
                               lw=lw, zorder=2)
    ax.add_patch(outer_box)

    # 2. Header banner clipped to outer box
    header_rect = Rectangle((x - 1.0, y + h - h_head), w + 2.0, h_head + 1.0,
                            facecolor=head_bg, edgecolor="none", zorder=3)
    header_rect.set_clip_path(outer_box)
    ax.add_patch(header_rect)

    # 3. Dividing line between header and body
    ax.plot([x, x + w], [y + h - h_head, y + h - h_head],
            color=border_color, lw=lw, zorder=4)

    # 4. Header title text (bold serif, centered)
    ax.text(x + w / 2.0, y + h - h_head / 2.0, title,
            ha="center", va="center", color=head_text_color,
            weight="bold", fontsize=title_size, zorder=5)

    # 5. Bullet items inside body
    n_items = len(items)
    if n_items > 0:
        y_top = y + h - h_head - 15.0
        y_bot = y + 16.0
        dy = (y_top - y_bot) / max(n_items - 1, 1) if n_items > 1 else 0
        left_pad = x + 15.0

        for i, item in enumerate(items):
            cur_y = y_top - i * dy if n_items > 1 else (y_top + y_bot) / 2.0
            if isinstance(item, tuple):
                line1, line2 = item
                ax.text(left_pad, cur_y + 5.5, f"•   {line1}",
                        ha="left", va="center", color="#000000",
                        fontsize=item_size, zorder=5)
                ax.text(left_pad + 18.0, cur_y - 6.5, line2,
                        ha="left", va="center", color="#000000",
                        fontsize=item_size, zorder=5)
            else:
                ax.text(left_pad, cur_y, f"•   {item}",
                        ha="left", va="center", color="#000000",
                        fontsize=item_size, zorder=5)

def create_figure_01():
    # 1024 x 512 canvas coordinate space (2:1 aspect ratio)
    fig, ax = plt.subplots(figsize=(13.65, 6.825))
    ax.set_xlim(0, 1024)
    ax.set_ylim(0, 512)
    ax.axis("off")

    arrow_color = "#000000"
    arrow_lw = 1.6

    # =========================================================================
    # ROW 1 (y_mpl = 344, h = 160, h_head = 36)
    # =========================================================================
    y_r1 = 344
    h_r1 = 160
    h_head1 = 36

    # Card 1: Data Ingestion (FRED)
    c1_bullets = [
        "S&P 500 daily data (2016–2024)",
        "CBOE VIX volatility index",
        "2,228 clean trading days after warm-up",
        ("S&P 500 price-return index", "(dividends excluded)")
    ]
    draw_card(ax, x=18, y=y_r1, w=330, h=h_r1, h_head=h_head1,
              title="1. Data Ingestion (FRED)",
              items=c1_bullets,
              border_color="#0b5cb0",
              head_bg="#c5dbf5",
              head_text_color="#063162",
              body_bg="#f4f8fd",
              title_size=12.2, item_size=10.5)

    # Card 2: Feature Engineering
    c2_bullets = [
        "10 stationary technical indicators",
        ("SMA, EMA, RSI, MACD,", "realized volatility"),
        ("ROC, momentum, realized volatility,", "VIX"),
        r"Causal alignment ($t \to t + 1$)"
    ]
    draw_card(ax, x=380, y=y_r1, w=300, h=h_r1, h_head=h_head1,
              title="2. Feature Engineering",
              items=c2_bullets,
              border_color="#1e7e34",
              head_bg="#c9e6d3",
              head_text_color="#0f4a1f",
              body_bg="#f4faf6",
              title_size=12.2, item_size=10.5)

    # Card 3: Walk-Forward Protocol
    c3_bullets = [
        "4 historical market regimes",
        "Fold 1: COVID shock (2020)",
        "Fold 2: stimulus bull (2021)",
        "Fold 3: rate-hike bear (2022)",
        "Fold 4: tech bull (2023–2024)"
    ]
    draw_card(ax, x=714, y=y_r1, w=294, h=h_r1, h_head=h_head1,
              title="3. Walk-Forward Protocol",
              items=c3_bullets,
              border_color="#d96b07",
              head_bg="#fbddbf",
              head_text_color="#7a3700",
              body_bg="#fdf8f3",
              title_size=12.2, item_size=10.5)

    # Horizontal Arrows in Row 1 (y_mpl = 424)
    y_arr_r1 = 424
    ax.annotate("", xy=(380, y_arr_r1), xytext=(348, y_arr_r1),
                arrowprops=dict(arrowstyle="-|>", lw=arrow_lw, color=arrow_color, mutation_scale=15))
    ax.annotate("", xy=(714, y_arr_r1), xytext=(680, y_arr_r1),
                arrowprops=dict(arrowstyle="-|>", lw=arrow_lw, color=arrow_color, mutation_scale=15))

    # =========================================================================
    # ROW 2 (y_mpl = 157, h = 159, h_head = 36)
    # =========================================================================
    y_r2 = 157
    h_r2 = 159
    h_head2 = 36

    # Card 4A: Classical Learning Pipelines
    c4a_bullets = [
        "SVC: linear, polynomial (degree 2, 3), RBF",
        "Random Forest (50–500 trees, depth tuned)",
        "Gradient Boosting (50–150 trees, learning rate/depth tuned)",
        "Logistic Regression (L2 regularized)",
        "Multi-Layer Perceptron (MLP)"
    ]
    draw_card(ax, x=48, y=y_r2, w=468, h=h_r2, h_head=h_head2,
              title="4A. Classical Learning Pipelines",
              items=c4a_bullets,
              border_color="#7a288a",
              head_bg="#e8c8f7",
              head_text_color="#430852",
              body_bg="#faf5fd",
              title_size=12.2, item_size=10.5)

    # Card 4B: Quantum Learning Pipelines
    c4b_bullets = [
        r"Havlíček ZZ-feature map ($N = 4$ qubits)",
        "Quantum Kernel SVM (Gram matrix)",
        "Parameterized VQC (2 layers)",
        "4-qubit amplitude embedding",
        "Qiskit Aer statevector simulation"
    ]
    draw_card(ax, x=540, y=y_r2, w=438, h=h_r2, h_head=h_head2,
              title="4B. Quantum Learning Pipelines",
              items=c4b_bullets,
              border_color="#b52626",
              head_bg="#f7c8c8",
              head_text_color="#6e0d0d",
              body_bg="#fdf6f6",
              title_size=12.2, item_size=10.5)

    # =========================================================================
    # CONNECTOR: ROW 1 TO ROW 2 (Orthogonal Bus Routing)
    # =========================================================================
    cx_4a = 48 + 468 / 2.0   # 282.0
    cx_4b = 540 + 438 / 2.0  # 759.0
    x_drop = 714 + 294 * 0.52 # ~867.0
    y_bus = 330

    # Line dropping down from Card 3 bottom
    ax.plot([x_drop, x_drop], [y_r1, y_bus], color=arrow_color, lw=arrow_lw, zorder=3)
    # Horizontal bus spanning left from x_drop to cx_4a
    ax.plot([cx_4a, x_drop], [y_bus, y_bus], color=arrow_color, lw=arrow_lw, zorder=3)

    # Downward arrow into Card 4B
    ax.annotate("", xy=(cx_4b, y_r2 + h_r2), xytext=(cx_4b, y_bus),
                arrowprops=dict(arrowstyle="-|>", lw=arrow_lw, color=arrow_color, mutation_scale=15))

    # Downward arrow into Card 4A
    ax.annotate("", xy=(cx_4a, y_r2 + h_r2), xytext=(cx_4a, y_bus),
                arrowprops=dict(arrowstyle="-|>", lw=arrow_lw, color=arrow_color, mutation_scale=15))

    # =========================================================================
    # ROW 3: CARD 5 (y_mpl = 8, h = 119, h_head = 33)
    # =========================================================================
    y_r3 = 8
    h_r3 = 119
    h_head3 = 33

    c5_bullets = [
        r"Out-of-sample predictive metrics: directional accuracy, ROC-AUC, Brier score, MCC ($N = 1,257$ days)",
        r"Forecast comparison: Diebold–Mariano test (HAC / Newey–West correction), McNemar test, 1,000-replication block bootstrap CIs",
        r"Transaction-cost backtest: realistic frictions at 5, 10, 20 bps; Sharpe, Sortino, maximum drawdown, turnover",
        r"Computational analysis: scaling, wall-clock benchmarks, parameter accounting, qubit-depth scaling analysis"
    ]
    draw_card(ax, x=18, y=y_r3, w=990, h=h_r3, h_head=h_head3,
              title="5. Evaluation, Statistical Testing & Friction Backtest",
              items=c5_bullets,
              border_color="#3f5161",
              head_bg="#d5dce2",
              head_text_color="#1e2832",
              body_bg="#f7f9fa",
              title_size=12.2, item_size=10.2)

    # Vertical downward arrows from Row 2 into Card 5
    ax.annotate("", xy=(cx_4a, y_r3 + h_r3), xytext=(cx_4a, y_r2),
                arrowprops=dict(arrowstyle="-|>", lw=arrow_lw, color=arrow_color, mutation_scale=15))
    ax.annotate("", xy=(cx_4b, y_r3 + h_r3), xytext=(cx_4b, y_r2),
                arrowprops=dict(arrowstyle="-|>", lw=arrow_lw, color=arrow_color, mutation_scale=15))

    fig.subplots_adjust(left=0.005, right=0.995, top=0.995, bottom=0.005)
    return fig

def export_all():
    print("Generating Figure 01 pixel-perfect flowchart...", flush=True)
    fig = create_figure_01()

    output_dirs = [
        os.path.join("figures", "figure01"),
        os.path.join("latex", "figures"),
        os.path.join("matlab", "export_figures"),
        os.path.join("FINAL_SUBMISSION", "figures"),
        os.path.join("submission", "figures")
    ]

    for d in output_dirs:
        os.makedirs(d, exist_ok=True)
        for ext in [".pdf", ".svg", ".png", ".jpg"]:
            target_path = os.path.join(d, f"figure01{ext}")
            fig.savefig(target_path, bbox_inches="tight", pad_inches=0.03, dpi=300)
            print(f"Saved: {target_path}", flush=True)

    preview_path = r"C:\Users\priya\.gemini\antigravity-ide\brain\0d106b5b-100e-4e61-8bd1-4711e300a920\figure01_perfect.png"
    fig.savefig(preview_path, bbox_inches="tight", pad_inches=0.03, dpi=300)
    print(f"Saved preview: {preview_path}", flush=True)

    plt.close(fig)
    print("Export complete!", flush=True)

if __name__ == "__main__":
    export_all()
