"""
Figure 04: Quantum Circuit Architectures and QSVM Kernel Pipeline
Conforming to Qiskit v2.5 Specifications (https://www.ibm.com/quantum/qiskit)
Publication Quality for The Journal of Computational Finance (Risk.net).

Layout:
  (a) Havlicek et al. (2019) ZZ-Feature Map Circuit Architecture (n = 4 Qubits, r = 2 Repetitions)
  (b) Parameterized Variational Quantum Classifier (RealAmplitudes Ansatz, L = 2 Layers, 12 Parameters)
  (c) End-to-End QSVM Gram-Matrix Computation Pipeline (Statevector Simulation to Dual Kernel Solver)

Key Fixes:
  1. Segmented Wire Drawing: Wires are drawn exclusively in the spaces between gate boxes.
     No wire lines pass inside, across, or behind gate boxes or text.
  2. Non-overlapping Gate Geometry: Exact mathematical positioning with generous clearance
     between all single-qubit gates, two-qubit ZZ entanglers, barriers, and pipeline cards.
  3. Perfect Round CNOT Targets: Using marker='o' in screen-space so CNOT controls and targets
     are always perfectly circular, never distorted by data aspect ratios.
  4. Flawless Typography: Escaped LaTeX mathtext throughout to eliminate any Unicode artifacts.
"""
import os
import sys
import shutil
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

# Matplotlib publication styling
plt.rcParams.update({
    "font.size": 9.5,
    "axes.labelsize": 10,
    "axes.titlesize": 11,
    "mathtext.fontset": "cm",
    "font.family": "serif",
    "font.serif": ["DejaVu Serif", "Times New Roman", "Computer Modern Roman"],
    "figure.dpi": 300,
    "savefig.dpi": 300
})

def create_figure_04():
    fig = plt.figure(figsize=(15.5, 11.4))
    gs = fig.add_gridspec(3, 1, height_ratios=[1.18, 1.18, 0.92], hspace=0.34)

    ax1 = fig.add_subplot(gs[0])
    ax2 = fig.add_subplot(gs[1])
    ax3 = fig.add_subplot(gs[2])

    for ax in [ax1, ax2, ax3]:
        ax.set_xlim(0, 100)
        ax.set_ylim(-0.65, 4.45)
        ax.axis("off")

    wire_color = "#2c3e50"
    wire_lw = 1.4

    # 4 qubit wire y-coordinates
    qubit_ys = [3.3, 2.3, 1.3, 0.3]
    qubit_labels_a = [r"$|0\rangle_{q_0}$", r"$|0\rangle_{q_1}$", r"$|0\rangle_{q_2}$", r"$|0\rangle_{q_3}$"]
    qubit_labels_b = [r"$q_0$", r"$q_1$", r"$q_2$", r"$q_3$"]

    def draw_wire(ax, x0, x1, y):
        """Draws a clean wire segment with strict zorder=1."""
        if x1 > x0:
            ax.plot([x0, x1], [y, y], color=wire_color, lw=wire_lw, zorder=1, solid_capstyle="butt")

    def draw_gate(ax, cx, cy, w, h, text, fc, ec, text_color="black", fontsize=8.5, subtext=None, subtext_size=6.8):
        """Draws an opaque gate box with strict z-ordering."""
        box = FancyBboxPatch((cx - w/2.0, cy - h/2.0), w, h,
                             boxstyle="round,pad=0.06,rounding_size=0.10",
                             facecolor=fc, edgecolor=ec, lw=1.3,
                             zorder=3, clip_on=False)
        ax.add_patch(box)
        if subtext:
            ax.text(cx, cy + 0.12, text, ha="center", va="center",
                    color=text_color, weight="bold", fontsize=fontsize, zorder=5)
            ax.text(cx, cy - 0.16, subtext, ha="center", va="center",
                    color=text_color, fontsize=subtext_size, zorder=5)
        else:
            ax.text(cx, cy, text, ha="center", va="center",
                    color=text_color, weight="bold", fontsize=fontsize, zorder=5)

    def draw_barrier(ax, x, y_min, y_max, label=None):
        ax.plot([x, x], [y_min, y_max], color="#95a5a6", lw=1.2, linestyle="--", zorder=2)
        if label:
            ax.text(x, y_max + 0.08, label, ha="center", va="bottom",
                    fontsize=7.2, color="#5d6d7e", style="italic", zorder=5)

    # =========================================================================
    # PANEL (a): ZZ-Feature Map (n = 4, r = 2 Repetitions)
    # =========================================================================
    ax1.text(0.0, 4.25,
             r"$\mathbf{(a)\; Havl\acute{\imath}\check{c}ek\; et\; al.\; (2019)\; ZZ\text{-Feature Map Circuit Architecture}\; (n = 4\; \text{Qubits},\; r = 2\; \text{Repetitions})\; [Qiskit\; ZZFeatureMap]}$",
             fontsize=11.5, weight="bold", color="#111827", va="bottom")

    # Left qubit state labels
    for q, y in enumerate(qubit_ys):
        ax1.text(1.8, y, qubit_labels_a[q], fontsize=10.0, weight="bold", color="#1a252f",
                 ha="center", va="center", zorder=5)

    # Gate geometric parameters for Panel (a)
    w_h = 4.2
    w_rz = 6.0
    w_zz = 7.4
    h_single = 0.58
    h_zz = 1.60

    # Repetition 1 centers
    cx_h1 = 8.0
    cx_rz1 = 15.0
    barrier_sub1 = 20.0
    cx_zz1_01 = 25.5
    cx_zz1_12 = 34.0
    cx_zz1_23 = 42.5
    barrier_rep = 48.5

    # Repetition 2 centers (shifted by +44.0)
    cx_h2 = 52.0
    cx_rz2 = 59.0
    barrier_sub2 = 64.0
    cx_zz2_01 = 69.5
    cx_zz2_12 = 78.0
    cx_zz2_23 = 86.5
    cx_out = 95.8
    w_out = 6.6

    # Draw Repetition Headers
    rep1_tag = FancyBboxPatch((5.5, 3.82), 41.5, 0.40,
                              boxstyle="round,pad=0.04,rounding_size=0.08",
                              facecolor="#f8f9fa", edgecolor="#bdc3c7", lw=1.0, zorder=2)
    ax1.add_patch(rep1_tag)
    ax1.text(26.25, 4.02, r"$\mathbf{Repetition\; 1:\; Superposition\; H^{\otimes 4}\; +\; First\; Entangled\; Phase\; U_{\Phi}(\mathbf{x})}$",
             ha="center", va="center", fontsize=8.2, color="#2c3e50", zorder=5)

    rep2_tag = FancyBboxPatch((49.5, 3.82), 41.5, 0.40,
                              boxstyle="round,pad=0.04,rounding_size=0.08",
                              facecolor="#f8f9fa", edgecolor="#bdc3c7", lw=1.0, zorder=2)
    ax1.add_patch(rep2_tag)
    ax1.text(70.25, 4.02, r"$\mathbf{Repetition\; 2:\; Superposition\; H^{\otimes 4}\; +\; Second\; Entangled\; Phase\; U_{\Phi}(\mathbf{x})}$",
             ha="center", va="center", fontsize=8.2, color="#2c3e50", zorder=5)

    # --- SEGMENTED WIRES PANEL (a) ---
    # Leading wires into H1
    for y in qubit_ys:
        draw_wire(ax1, 3.2, cx_h1 - w_h/2.0, y)

    # Wires between H1 and Rz1
    for y in qubit_ys:
        draw_wire(ax1, cx_h1 + w_h/2.0, cx_rz1 - w_rz/2.0, y)

    # Wires from Rz1 into ZZ entanglers / Rep 1
    # q0 enters ZZ(0,1) at cx_zz1_01 - w_zz/2.0, leaves at cx_zz1_01 + w_zz/2.0, then runs to H2
    draw_wire(ax1, cx_rz1 + w_rz/2.0, cx_zz1_01 - w_zz/2.0, qubit_ys[0])
    draw_wire(ax1, cx_zz1_01 + w_zz/2.0, cx_h2 - w_h/2.0, qubit_ys[0])

    # q1 enters ZZ(0,1) at cx_zz1_01 - w_zz/2.0, leaves at cx_zz1_01 + w_zz/2.0,
    # enters ZZ(1,2) at cx_zz1_12 - w_zz/2.0, leaves at cx_zz1_12 + w_zz/2.0, then runs to H2
    draw_wire(ax1, cx_rz1 + w_rz/2.0, cx_zz1_01 - w_zz/2.0, qubit_ys[1])
    draw_wire(ax1, cx_zz1_01 + w_zz/2.0, cx_zz1_12 - w_zz/2.0, qubit_ys[1])
    draw_wire(ax1, cx_zz1_12 + w_zz/2.0, cx_h2 - w_h/2.0, qubit_ys[1])

    # q2 runs past ZZ(0,1), enters ZZ(1,2) at cx_zz1_12 - w_zz/2.0, leaves at cx_zz1_12 + w_zz/2.0,
    # enters ZZ(2,3) at cx_zz1_23 - w_zz/2.0, leaves at cx_zz1_23 + w_zz/2.0, then runs to H2
    draw_wire(ax1, cx_rz1 + w_rz/2.0, cx_zz1_12 - w_zz/2.0, qubit_ys[2])
    draw_wire(ax1, cx_zz1_12 + w_zz/2.0, cx_zz1_23 - w_zz/2.0, qubit_ys[2])
    draw_wire(ax1, cx_zz1_23 + w_zz/2.0, cx_h2 - w_h/2.0, qubit_ys[2])

    # q3 runs past ZZ(0,1) and ZZ(1,2), enters ZZ(2,3) at cx_zz1_23 - w_zz/2.0, leaves at cx_zz1_23 + w_zz/2.0, then runs to H2
    draw_wire(ax1, cx_rz1 + w_rz/2.0, cx_zz1_23 - w_zz/2.0, qubit_ys[3])
    draw_wire(ax1, cx_zz1_23 + w_zz/2.0, cx_h2 - w_h/2.0, qubit_ys[3])

    # Wires between H2 and Rz2
    for y in qubit_ys:
        draw_wire(ax1, cx_h2 + w_h/2.0, cx_rz2 - w_rz/2.0, y)

    # Wires from Rz2 into ZZ entanglers / Rep 2
    # q0
    draw_wire(ax1, cx_rz2 + w_rz/2.0, cx_zz2_01 - w_zz/2.0, qubit_ys[0])
    draw_wire(ax1, cx_zz2_01 + w_zz/2.0, cx_out - w_out/2.0, qubit_ys[0])

    # q1
    draw_wire(ax1, cx_rz2 + w_rz/2.0, cx_zz2_01 - w_zz/2.0, qubit_ys[1])
    draw_wire(ax1, cx_zz2_01 + w_zz/2.0, cx_zz2_12 - w_zz/2.0, qubit_ys[1])
    draw_wire(ax1, cx_zz2_12 + w_zz/2.0, cx_out - w_out/2.0, qubit_ys[1])

    # q2
    draw_wire(ax1, cx_rz2 + w_rz/2.0, cx_zz2_12 - w_zz/2.0, qubit_ys[2])
    draw_wire(ax1, cx_zz2_12 + w_zz/2.0, cx_zz2_23 - w_zz/2.0, qubit_ys[2])
    draw_wire(ax1, cx_zz2_23 + w_zz/2.0, cx_out - w_out/2.0, qubit_ys[2])

    # q3
    draw_wire(ax1, cx_rz2 + w_rz/2.0, cx_zz2_23 - w_zz/2.0, qubit_ys[3])
    draw_wire(ax1, cx_zz2_23 + w_zz/2.0, cx_out - w_out/2.0, qubit_ys[3])

    # --- DRAW GATES PANEL (a) ---
    # Repetition 1 Gates:
    for q, y in enumerate(qubit_ys):
        draw_gate(ax1, cx_h1, y, w_h, h_single, "H", "#e1f0fe", "#1a73e8", text_color="#0d47a1", fontsize=9.2)
        draw_gate(ax1, cx_rz1, y, w_rz, h_single, rf"$R_z(2x_{q})$", "#fef3e8", "#e67e22", text_color="#934100", fontsize=7.8)

    draw_barrier(ax1, barrier_sub1, 0.0, 3.65, label=r"$ZZ\text{ entanglers}$")

    # Repetition 1 ZZ Gates:
    draw_gate(ax1, cx_zz1_01, 2.8, w_zz, h_zz, r"$ZZ(2\phi_{0,1})$", "#f3e8fd", "#8e44ad", text_color="#511b75", fontsize=8.2,
              subtext=r"$\phi_{0,1}=2(\pi{-}x_0)(\pi{-}x_1)$", subtext_size=6.6)
    draw_gate(ax1, cx_zz1_12, 1.8, w_zz, h_zz, r"$ZZ(2\phi_{1,2})$", "#f3e8fd", "#8e44ad", text_color="#511b75", fontsize=8.2,
              subtext=r"$\phi_{1,2}=2(\pi{-}x_1)(\pi{-}x_2)$", subtext_size=6.6)
    draw_gate(ax1, cx_zz1_23, 0.8, w_zz, h_zz, r"$ZZ(2\phi_{2,3})$", "#f3e8fd", "#8e44ad", text_color="#511b75", fontsize=8.2,
              subtext=r"$\phi_{2,3}=2(\pi{-}x_2)(\pi{-}x_3)$", subtext_size=6.6)

    # Central Barrier
    draw_barrier(ax1, barrier_rep, -0.15, 3.75, label=r"$\mathbf{Barrier}$")

    # Repetition 2 Gates:
    for q, y in enumerate(qubit_ys):
        draw_gate(ax1, cx_h2, y, w_h, h_single, "H", "#e1f0fe", "#1a73e8", text_color="#0d47a1", fontsize=9.2)
        draw_gate(ax1, cx_rz2, y, w_rz, h_single, rf"$R_z(2x_{q})$", "#fef3e8", "#e67e22", text_color="#934100", fontsize=7.8)

    draw_barrier(ax1, barrier_sub2, 0.0, 3.65, label=r"$ZZ\text{ entanglers}$")

    # Repetition 2 ZZ Gates:
    draw_gate(ax1, cx_zz2_01, 2.8, w_zz, h_zz, r"$ZZ(2\phi_{0,1})$", "#f3e8fd", "#8e44ad", text_color="#511b75", fontsize=8.2,
              subtext=r"$\phi_{0,1}=2(\pi{-}x_0)(\pi{-}x_1)$", subtext_size=6.6)
    draw_gate(ax1, cx_zz2_12, 1.8, w_zz, h_zz, r"$ZZ(2\phi_{1,2})$", "#f3e8fd", "#8e44ad", text_color="#511b75", fontsize=8.2,
              subtext=r"$\phi_{1,2}=2(\pi{-}x_1)(\pi{-}x_2)$", subtext_size=6.6)
    draw_gate(ax1, cx_zz2_23, 0.8, w_zz, h_zz, r"$ZZ(2\phi_{2,3})$", "#f3e8fd", "#8e44ad", text_color="#511b75", fontsize=8.2,
              subtext=r"$\phi_{2,3}=2(\pi{-}x_2)(\pi{-}x_3)$", subtext_size=6.6)

    # Output State Box
    out_box = FancyBboxPatch((cx_out - w_out/2.0, 0.0), w_out, 3.6,
                             boxstyle="round,pad=0.06,rounding_size=0.12",
                             facecolor="#fbfcfd", edgecolor="#2c3e50", lw=1.5, zorder=3)
    ax1.add_patch(out_box)
    ax1.text(cx_out, 2.85, r"$\mathbf{Quantum}$", ha="center", va="center", fontsize=8.5, color="#1b4f72", weight="bold", zorder=5)
    ax1.text(cx_out, 2.45, r"$\mathbf{State}$", ha="center", va="center", fontsize=8.5, color="#1b4f72", weight="bold", zorder=5)
    ax1.text(cx_out, 1.80, r"$|\Phi(\mathbf{x})\rangle$", ha="center", va="center", fontsize=10.5, color="#8e44ad", weight="bold", zorder=5)
    ax1.text(cx_out, 1.05, r"$K_{ij}^Q = |\langle \Phi_i | \Phi_j \rangle|^2$", ha="center", va="center", fontsize=7.5, color="#2c3e50", zorder=5)
    ax1.text(cx_out, 0.50, r"$\mathcal{U}_{\Phi}(\mathbf{x})|0\rangle^{\otimes 4}$", ha="center", va="center", fontsize=7.2, color="#566573", zorder=5)


    # =========================================================================
    # PANEL (b): RealAmplitudes VQC Ansatz (n = 4, L = 2 Layers, 12 Parameters)
    # =========================================================================
    ax2.text(0.0, 4.25,
             r"$\mathbf{(b)\; Parameterized\; Variational\; Quantum\; Classifier\; (VQC)\; [RealAmplitudes\; Ansatz,\; L = 2\; Layers,\; p = 12\; Parameters]}$",
             fontsize=11.5, weight="bold", color="#111827", va="bottom")

    for q, y in enumerate(qubit_ys):
        ax2.text(1.8, y, qubit_labels_b[q], fontsize=10.0, weight="bold", color="#1a252f",
                 ha="center", va="center", zorder=5)

    def draw_cnot_circular(ax, cx, y_ctrl, y_tgt):
        """Draws perfectly circular CNOT gates using screen-space markers."""
        # Connecting vertical line
        ax.plot([cx, cx], [y_ctrl, y_tgt], color="#c0392b", lw=1.8, zorder=3)
        # Control dot: solid dark red dot
        ax.plot([cx], [y_ctrl], marker="o", markersize=6.5, color="#c0392b", zorder=5)
        # Target circle: outer circle + plus symbol
        ax.plot([cx], [y_tgt], marker="o", markersize=13.0, markerfacecolor="#fcedeb",
                markeredgecolor="#c0392b", markeredgewidth=1.6, zorder=4)
        ax.text(cx, y_tgt, "+", ha="center", va="center", color="#c0392b",
                weight="bold", fontsize=10.5, zorder=5)

    # Geometric parameters for Panel (b)
    w_ry = 6.2
    cx_ry0 = 9.0
    barrier_b1 = 14.8
    cx_cnot1_01 = 19.5
    cx_cnot1_12 = 25.0
    cx_cnot1_23 = 30.5
    barrier_b2 = 35.5
    cx_ry1 = 41.5
    barrier_b3 = 47.5
    cx_cnot2_01 = 52.0
    cx_cnot2_12 = 57.5
    cx_cnot2_23 = 63.0
    barrier_b4 = 68.0
    cx_ry2 = 73.5
    barrier_b5 = 78.5
    cx_meas = 89.2
    w_meas = 19.6

    # Headers for VQC sublayers
    ax2.text(cx_ry0, 4.02, r"$\mathbf{Rotation\; Layer\; 0}$", ha="center", va="center", fontsize=8.0, color="#1e8449", zorder=5)
    ax2.text((cx_cnot1_01 + cx_cnot1_23)/2.0, 4.02, r"$\mathbf{Entanglement\; Layer\; 1\; (Linear\; CNOT)}$", ha="center", va="center", fontsize=8.0, color="#922b21", zorder=5)
    ax2.text(cx_ry1, 4.02, r"$\mathbf{Rotation\; Layer\; 1}$", ha="center", va="center", fontsize=8.0, color="#1e8449", zorder=5)
    ax2.text((cx_cnot2_01 + cx_cnot2_23)/2.0, 4.02, r"$\mathbf{Entanglement\; Layer\; 2\; (Linear\; CNOT)}$", ha="center", va="center", fontsize=8.0, color="#922b21", zorder=5)
    ax2.text(cx_ry2, 4.02, r"$\mathbf{Rotation\; Layer\; 2}$", ha="center", va="center", fontsize=8.0, color="#1e8449", zorder=5)

    # --- SEGMENTED WIRES PANEL (b) ---
    # Leading wires into Ry0
    for y in qubit_ys:
        draw_wire(ax2, 3.2, cx_ry0 - w_ry/2.0, y)

    # Wires from Ry0 across CNOT L1 into Ry1
    for y in qubit_ys:
        draw_wire(ax2, cx_ry0 + w_ry/2.0, cx_ry1 - w_ry/2.0, y)

    # Wires from Ry1 across CNOT L2 into Ry2
    for y in qubit_ys:
        draw_wire(ax2, cx_ry1 + w_ry/2.0, cx_ry2 - w_ry/2.0, y)

    # Wires from Ry2 leading strictly to the left edge of the Measurement Box
    meas_left_edge = cx_meas - w_meas/2.0
    for y in qubit_ys:
        draw_wire(ax2, cx_ry2 + w_ry/2.0, meas_left_edge, y)

    # --- DRAW GATES PANEL (b) ---
    # Rotation Layer 0
    for q, y in enumerate(qubit_ys):
        draw_gate(ax2, cx_ry0, y, w_ry, h_single, rf"$R_y(\theta_{{{q},0}})$", "#eafaf1", "#27ae60", text_color="#145a32", fontsize=8.0)

    draw_barrier(ax2, barrier_b1, 0.0, 3.65)

    # Entanglement Layer 1
    draw_cnot_circular(ax2, cx_cnot1_01, qubit_ys[0], qubit_ys[1])
    draw_cnot_circular(ax2, cx_cnot1_12, qubit_ys[1], qubit_ys[2])
    draw_cnot_circular(ax2, cx_cnot1_23, qubit_ys[2], qubit_ys[3])

    draw_barrier(ax2, barrier_b2, 0.0, 3.65)

    # Rotation Layer 1
    for q, y in enumerate(qubit_ys):
        draw_gate(ax2, cx_ry1, y, w_ry, h_single, rf"$R_y(\theta_{{{q},1}})$", "#eafaf1", "#27ae60", text_color="#145a32", fontsize=8.0)

    draw_barrier(ax2, barrier_b3, 0.0, 3.65)

    # Entanglement Layer 2
    draw_cnot_circular(ax2, cx_cnot2_01, qubit_ys[0], qubit_ys[1])
    draw_cnot_circular(ax2, cx_cnot2_12, qubit_ys[1], qubit_ys[2])
    draw_cnot_circular(ax2, cx_cnot2_23, qubit_ys[2], qubit_ys[3])

    draw_barrier(ax2, barrier_b4, 0.0, 3.65)

    # Rotation Layer 2
    for q, y in enumerate(qubit_ys):
        draw_gate(ax2, cx_ry2, y, w_ry, h_single, rf"$R_y(\theta_{{{q},2}})$", "#eafaf1", "#27ae60", text_color="#145a32", fontsize=8.0)

    draw_barrier(ax2, barrier_b5, 0.0, 3.65)

    # Measurement Box (completely clean, zero wires inside)
    meas_box = FancyBboxPatch((cx_meas - w_meas/2.0, 0.0), w_meas, 3.6,
                              boxstyle="round,pad=0.08,rounding_size=0.15",
                              facecolor="#f8f9fa", edgecolor="#2c3e50", lw=1.6, zorder=3)
    ax2.add_patch(meas_box)

    ax2.text(cx_meas, 3.15, r"$\mathbf{Parity\; Observable\; Measurement}$", ha="center", va="center",
             fontsize=8.8, color="#1b2631", weight="bold", zorder=5)
    ax2.text(cx_meas, 2.50, r"$\hat{M} = Z_0 \otimes Z_1 \otimes Z_2 \otimes Z_3$", ha="center", va="center",
             fontsize=9.2, color="#7d3c98", weight="bold", zorder=5)
    ax2.text(cx_meas, 1.85, r"$\langle \hat{M} \rangle(\mathbf{x};\boldsymbol{\theta}) = \langle \psi | \hat{M} | \psi \rangle \in [-1, +1]$", ha="center", va="center",
             fontsize=7.8, color="#2c3e50", zorder=5)
    ax2.text(cx_meas, 1.20, r"$P(y_t = 1 \mid \mathbf{x}_t;\boldsymbol{\theta}) = \frac{\langle \hat{M} \rangle + 1}{2}$", ha="center", va="center",
             fontsize=8.8, color="#1b4f72", weight="bold", zorder=5)
    ax2.text(cx_meas, 0.55, r"$\text{Loss: Brier Score MSE} \to \text{COBYLA (80 iters)}$", ha="center", va="center",
             fontsize=7.5, color="#566573", zorder=5)

    # Summary pill
    vqc_summary = FancyBboxPatch((16.0, -0.58), 52.0, 0.40,
                                 boxstyle="round,pad=0.04,rounding_size=0.08",
                                 facecolor="#fefde8", edgecolor="#f1c40f", lw=1.1, zorder=2)
    ax2.add_patch(vqc_summary)
    ax2.text(42.0, -0.38,
             r"$\mathbf{Ansatz\; Parameter\; Count:\;} p = n(L+1) = 4 \times (2+1) = 12\; \text{trainable parameters}\; \boldsymbol{\theta} \in [-\pi, \pi]^{12}$",
             ha="center", va="center", fontsize=8.2, color="#7d6608", zorder=5)


    # =========================================================================
    # PANEL (c): QSVM Gram-Matrix Kernel Pipeline
    # =========================================================================
    ax3.text(0.0, 4.25,
             r"$\mathbf{(c)\; End\text{-}to\text{-}End\; QSVM\; Gram\text{-}Matrix\; Kernel\; Pipeline\; [Qiskit\; StatevectorSimulator\; \to\; Classical\; Dual\; Solver]}$",
             fontsize=11.5, weight="bold", color="#111827", va="bottom")

    pipeline_cards = [
        {
            "step": "Step 1",
            "title": "Feature Scaling",
            "subtitle": "MinMax Normalization",
            "math": r"$\mathbf{x}_t \in [0, \pi]^4$",
            "detail": "Strict non-leaking fit\non training fold only",
            "fc": "#ebf5fb", "ec": "#2980b9", "tc": "#1b4f72"
        },
        {
            "step": "Step 2",
            "title": "Quantum Embedding",
            "subtitle": "ZZFeatureMap (r=2)",
            "math": r"$|\Phi(\mathbf{x})\rangle = \mathcal{U}_{\Phi}(\mathbf{x})|0\rangle^{\otimes 4}$",
            "detail": "2 reps, linear CNOT\nentanglement topology",
            "fc": "#f5eef8", "ec": "#8e44ad", "tc": "#511b75"
        },
        {
            "step": "Step 3",
            "title": "Statevector Sim",
            "subtitle": "Quantum Kernel Entry",
            "math": r"$K_{ij}^Q = |\langle \Phi(\mathbf{x}_i) | \Phi(\mathbf{x}_j) \rangle|^2$",
            "detail": "Pure statevector fidelity\nvia Qiskit v2.5",
            "fc": "#e8f8f5", "ec": "#16a085", "tc": "#0e6251"
        },
        {
            "step": "Step 4",
            "title": "Gram Matrix Assembly",
            "subtitle": "Full Kernel Matrix",
            "math": r"$\mathbf{K}^Q \in \mathbb{R}^{N \times N}$",
            "detail": r"$N_{\text{total}} = 2{,}228$" + "\nHermitian positive semidefinite",
            "fc": "#fef5e7", "ec": "#d35400", "tc": "#7e3200"
        },
        {
            "step": "Step 5",
            "title": "Dual SVM Solver",
            "subtitle": "Ridge Kernel System",
            "math": r"$\boldsymbol{\alpha} = (\mathbf{K}^Q + \lambda \mathbf{I})^{-1}\mathbf{y}$",
            "detail": r"$\lambda = 1.0$" + "\nStrict 1-day execution lag",
            "fc": "#eafaf1", "ec": "#27ae60", "tc": "#145a32"
        }
    ]

    card_w = 14.2
    card_h = 3.3
    y_card_center = 1.95
    card_centers = [9.0, 26.2, 43.4, 60.6, 77.8]

    for i, c in enumerate(pipeline_cards):
        cx = card_centers[i]
        box = FancyBboxPatch((cx - card_w/2.0, y_card_center - card_h/2.0), card_w, card_h,
                             boxstyle="round,pad=0.08,rounding_size=0.14",
                             facecolor=c["fc"], edgecolor=c["ec"], lw=1.5, zorder=3)
        ax3.add_patch(box)

        # Step tag
        step_box = FancyBboxPatch((cx - 3.0, y_card_center + card_h/2.0 - 0.40), 6.0, 0.36,
                                  boxstyle="round,pad=0.03,rounding_size=0.06",
                                  facecolor=c["ec"], edgecolor="none", zorder=4)
        ax3.add_patch(step_box)
        ax3.text(cx, y_card_center + card_h/2.0 - 0.22, c["step"],
                 ha="center", va="center", color="white", weight="bold", fontsize=7.5, zorder=5)

        # Title and details
        ax3.text(cx, y_card_center + 0.85, c["title"], ha="center", va="center",
                 fontsize=8.2, weight="bold", color=c["tc"], zorder=5)
        ax3.text(cx, y_card_center + 0.48, c["subtitle"], ha="center", va="center",
                 fontsize=7.0, color="#566573", style="italic", zorder=5)
        ax3.text(cx, y_card_center - 0.05, c["math"], ha="center", va="center",
                 fontsize=8.2, weight="bold", color=c["tc"], zorder=5)

        # Multiline detail
        lines = c["detail"].split("\n")
        if len(lines) == 2:
            ax3.text(cx, y_card_center - 0.65, lines[0], ha="center", va="center",
                     fontsize=6.8, color="#566573", zorder=5)
            ax3.text(cx, y_card_center - 1.05, lines[1], ha="center", va="center",
                     fontsize=6.8, color="#566573", zorder=5)
        else:
            ax3.text(cx, y_card_center - 0.85, c["detail"], ha="center", va="center",
                     fontsize=6.8, color="#566573", zorder=5)

        # Connecting Arrow (in gap between cards, strictly separated)
        if i < 4:
            arrow_x_start = cx + card_w/2.0 + 0.35
            arrow_x_end = card_centers[i+1] - card_w/2.0 - 0.35
            arrow = FancyArrowPatch((arrow_x_start, y_card_center), (arrow_x_end, y_card_center),
                                    arrowstyle="-|>", mutation_scale=13,
                                    color="#34495e", lw=1.7, zorder=4)
            ax3.add_patch(arrow)

    # Complexity Summary Card on the right
    cx_comp = 93.4
    w_comp = 10.8
    summary_box = FancyBboxPatch((cx_comp - w_comp/2.0, y_card_center - card_h/2.0), w_comp, card_h,
                                 boxstyle="round,pad=0.08,rounding_size=0.12",
                                 facecolor="#fbfcfc", edgecolor="#7f8c8d", lw=1.2, linestyle=":", zorder=3)
    ax3.add_patch(summary_box)
    ax3.text(cx_comp, y_card_center + 1.15, r"$\mathbf{Computational}$", ha="center", va="center",
             fontsize=7.8, weight="bold", color="#2c3e50", zorder=5)
    ax3.text(cx_comp, y_card_center + 0.82, r"$\mathbf{Complexity}$", ha="center", va="center",
             fontsize=7.8, weight="bold", color="#2c3e50", zorder=5)
    ax3.text(cx_comp, y_card_center + 0.35, r"$\mathcal{O}(N^2)\; \text{Pairs}$", ha="center", va="center",
             fontsize=7.6, color="#7d3c98", weight="bold", zorder=5)
    ax3.text(cx_comp, y_card_center - 0.15, r"$2{,}483{,}096$", ha="center", va="center",
             fontsize=7.5, color="#2c3e50", weight="bold", zorder=5)
    ax3.text(cx_comp, y_card_center - 0.55, "Kernel Evals", ha="center", va="center",
             fontsize=7.0, color="#566573", zorder=5)
    ax3.text(cx_comp, y_card_center - 1.05, "Exact Statevector", ha="center", va="center",
             fontsize=6.8, color="#27ae60", style="italic", zorder=5)

    # Arrow from Card 5 to Complexity Summary
    arrow_to_comp = FancyArrowPatch((card_centers[4] + card_w/2.0 + 0.35, y_card_center),
                                    (cx_comp - w_comp/2.0 - 0.35, y_card_center),
                                    arrowstyle="-|>", mutation_scale=13,
                                    color="#7f8c8d", lw=1.4, linestyle="--", zorder=4)
    ax3.add_patch(arrow_to_comp)

    # Footer attribution
    ax3.text(50.0, -0.45,
             r"$\text{Source: IBM Quantum / Qiskit v2.5 Canonical Implementations (ZZFeatureMap + RealAmplitudes + StatevectorSimulation) | https://www.ibm.com/quantum/qiskit}$",
             ha="center", va="center", fontsize=7.2, color="#7f8c8d", style="italic", zorder=5)

    return fig

def export_all():
    print("Generating publication-ready Figure 04 with segmented wires and clean geometry...", flush=True)
    fig = create_figure_04()

    output_dirs = [
        os.path.join("figures", "figure04"),
        os.path.join("latex", "figures"),
        os.path.join("matlab", "export_figures"),
        os.path.join("FINAL_SUBMISSION", "figures"),
        os.path.join("submission", "figures")
    ]

    for d in output_dirs:
        os.makedirs(d, exist_ok=True)
        for ext in [".pdf", ".svg", ".png", ".jpg"]:
            target_path = os.path.join(d, f"figure04{ext}")
            fig.savefig(target_path, bbox_inches="tight", dpi=300)
            print(f"Saved: {target_path}", flush=True)

    # Save to artifact directory for agent/user inspection
    artifact_preview = r"C:\Users\priya\.gemini\antigravity-ide\brain\0d106b5b-100e-4e61-8bd1-4711e300a920\figure04_corrected.png"
    fig.savefig(artifact_preview, bbox_inches="tight", dpi=300)
    print(f"Saved preview artifact: {artifact_preview}", flush=True)

    plt.close(fig)
    print("Figure 04 export completed successfully!", flush=True)

if __name__ == "__main__":
    export_all()
