"""
Robust Classical Machine Learning Pipelines for Financial Time-Series Forecasting.
Implemented in pure NumPy and SciPy to ensure 100% portability, high numerical efficiency,
and complete immunity to binary DLL loading restrictions.
Models:
1. Logistic Regression (L-BFGS-B with L2 regularization)
2. Support Vector / Kernel Classifier (RBF kernel with dual regularization)
3. Random Forest (Bootstrap ensemble of decision trees with Gini splits)
4. Gradient Boosted Trees (Sequential tree ensemble with Bernoulli deviance)
5. Multilayer Perceptron (2-layer feedforward network with ReLU and Adam/L-BFGS)
"""
import time
import math
import numpy as np
from scipy.optimize import minimize
from scipy.linalg import solve

class LogisticRegressionModel:
    def __init__(self, C=1.0, random_state=42):
        self.C = C
        self.random_state = random_state
        self.w = None
        self.b = 0.0
        self.train_time = 0.0
        self.inference_time_per_sample_ms = 0.0
        self.n_parameters = 0

    def fit(self, X, y):
        t0 = time.perf_counter()
        N, D = X.shape
        self.n_parameters = D + 1
        l2_reg = 1.0 / (self.C * float(N))

        def obj_and_grad(params):
            w = params[:D]
            b = params[D]
            z = np.dot(X, w) + b
            p = 1.0 / (1.0 + np.exp(-np.clip(z, -30.0, 30.0)))
            loss = -np.mean(y * np.log(p + 1e-15) + (1.0 - y) * np.log(1.0 - p + 1e-15)) + 0.5 * l2_reg * np.sum(w ** 2)
            grad_w = np.dot(X.T, (p - y)) / float(N) + l2_reg * w
            grad_b = np.mean(p - y)
            grad = np.append(grad_w, grad_b)
            return loss, grad

        init_params = np.zeros(D + 1)
        res = minimize(obj_and_grad, init_params, jac=True, method="L-BFGS-B", options={"maxiter": 300, "ftol": 1e-7})
        self.w = res.x[:D]
        self.b = float(res.x[D])
        self.train_time = time.perf_counter() - t0
        return self

    def predict_proba(self, X):
        z = np.dot(X, self.w) + self.b
        return 1.0 / (1.0 + np.exp(-np.clip(z, -30.0, 30.0)))

    def predict(self, X):
        t0 = time.perf_counter()
        probs = self.predict_proba(X)
        preds = (probs >= 0.5).astype(np.int64)
        elapsed = time.perf_counter() - t0
        self.inference_time_per_sample_ms = (elapsed / max(1, len(X))) * 1000.0
        return preds


class KernelClassifierModel:
    def __init__(self, kernel="rbf", gamma="scale", C=1.0, degree=2, coef0=1.0, random_state=42):
        self.kernel = kernel
        self.gamma_mode = gamma
        self.gamma = 1.0
        self.C = C
        self.degree = degree
        self.coef0 = coef0
        self.random_state = random_state
        self.X_train = None
        self.alpha = None
        self.train_time = 0.0
        self.inference_time_per_sample_ms = 0.0
        self.n_parameters = 0

    def _compute_kernel(self, X1, X2):
        if self.kernel == "rbf":
            # ||x1 - x2||^2 = ||x1||^2 + ||x2||^2 - 2 x1 x2^T
            x1_sq = np.sum(X1 ** 2, axis=1, keepdims=True)
            x2_sq = np.sum(X2 ** 2, axis=1, keepdims=True)
            dists = x1_sq + x2_sq.T - 2.0 * np.dot(X1, X2.T)
            return np.exp(-self.gamma * np.maximum(dists, 0.0))
        elif self.kernel == "linear":
            return np.dot(X1, X2.T)
        elif self.kernel == "poly":
            dists = np.dot(X1, X2.T)
            return (self.gamma * dists + self.coef0) ** self.degree
        else:
            raise ValueError(f"Unknown kernel: {self.kernel}")

    def fit(self, X, y):
        t0 = time.perf_counter()
        self.X_train = X.copy()
        N, D = X.shape
        if self.gamma_mode == "scale":
            var_x = np.var(X)
            self.gamma = 1.0 / (float(D) * var_x) if var_x > 0 else 1.0 / float(D)
        else:
            self.gamma = float(self.gamma_mode)

        K = self._compute_kernel(X, X)
        # Solve dual regularized problem: (K + lambda I) alpha = y_tilde where y_tilde in {-1, +1}
        y_tilde = np.where(y == 1, 1.0, -1.0)
        reg = 1.0 / (self.C * float(N))
        K_reg = K + reg * np.eye(N)
        self.alpha = solve(K_reg, y_tilde, assume_a="pos")
        self.n_parameters = N
        self.train_time = time.perf_counter() - t0
        return self

    def predict_proba(self, X):
        K_test = self._compute_kernel(X, self.X_train)
        f_scores = np.dot(K_test, self.alpha)
        # Sigmoid calibration
        return 1.0 / (1.0 + np.exp(-np.clip(f_scores, -30.0, 30.0)))

    def predict(self, X):
        t0 = time.perf_counter()
        probs = self.predict_proba(X)
        preds = (probs >= 0.5).astype(np.int64)
        elapsed = time.perf_counter() - t0
        self.inference_time_per_sample_ms = (elapsed / max(1, len(X))) * 1000.0
        return preds


class SimpleDecisionTree:
    def __init__(self, max_depth=5, min_samples_split=5):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.tree = None
        self.node_count = 0

    def fit(self, X, y, max_features=None, rng=None):
        self.node_count = 0
        self.tree = self._build_tree(X, y, depth=0, max_features=max_features, rng=rng)
        return self

    def _gini(self, y):
        if len(y) == 0:
            return 0.0
        p = np.mean(y)
        return 2.0 * p * (1.0 - p)

    def _build_tree(self, X, y, depth, max_features, rng):
        self.node_count += 1
        N, D = X.shape
        num_class_1 = np.sum(y == 1)
        prob = num_class_1 / float(N) if N > 0 else 0.5

        if depth >= self.max_depth or N < self.min_samples_split or self._gini(y) == 0:
            return {"leaf": True, "prob": prob, "pred": 1 if prob >= 0.5 else 0}

        # Select feature subset
        feats = range(D)
        if max_features and max_features < D and rng:
            feats = rng.choice(D, max_features, replace=False)

        best_gini = self._gini(y)
        best_split = None

        for f in feats:
            vals = np.unique(X[:, f])
            if len(vals) > 10:
                percentiles = np.linspace(10, 90, 8)
                thresholds = np.percentile(vals, percentiles)
            else:
                thresholds = vals[:-1]

            for thr in thresholds:
                left_mask = X[:, f] <= thr
                right_mask = ~left_mask
                if np.sum(left_mask) == 0 or np.sum(right_mask) == 0:
                    continue
                gini_left = self._gini(y[left_mask])
                gini_right = self._gini(y[right_mask])
                gini_split = (np.sum(left_mask) * gini_left + np.sum(right_mask) * gini_right) / float(N)
                if gini_split < best_gini:
                    best_gini = gini_split
                    best_split = (f, thr, left_mask, right_mask)

        if best_split is None:
            return {"leaf": True, "prob": prob, "pred": 1 if prob >= 0.5 else 0}

        f, thr, left_mask, right_mask = best_split
        left_sub = self._build_tree(X[left_mask], y[left_mask], depth + 1, max_features, rng)
        right_sub = self._build_tree(X[right_mask], y[right_mask], depth + 1, max_features, rng)

        return {"leaf": False, "feature": f, "threshold": thr, "left": left_sub, "right": right_sub, "prob": prob}

    def _predict_row(self, node, x):
        if node["leaf"]:
            return node["prob"]
        if x[node["feature"]] <= node["threshold"]:
            return self._predict_row(node["left"], x)
        else:
            return self._predict_row(node["right"], x)

    def predict_proba(self, X):
        return np.array([self._predict_row(self.tree, row) for row in X])


class RandomForestModel:
    def __init__(self, n_estimators=100, max_depth=5, min_samples_split=5, random_state=42):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.random_state = random_state
        self.trees = []
        self.train_time = 0.0
        self.inference_time_per_sample_ms = 0.0
        self.n_parameters = 0

    def fit(self, X, y):
        t0 = time.perf_counter()
        rng = np.random.RandomState(self.random_state)
        N, D = X.shape
        max_feats = max(1, int(math.sqrt(D)))
        self.trees = []
        total_nodes = 0

        for _ in range(self.n_estimators):
            boot_idx = rng.choice(N, N, replace=True)
            tree = SimpleDecisionTree(max_depth=self.max_depth, min_samples_split=self.min_samples_split)
            tree.fit(X[boot_idx], y[boot_idx], max_features=max_feats, rng=rng)
            self.trees.append(tree)
            total_nodes += tree.node_count

        self.n_parameters = total_nodes
        self.train_time = time.perf_counter() - t0
        return self

    def predict_proba(self, X):
        all_probs = np.array([tree.predict_proba(X) for tree in self.trees])
        return np.mean(all_probs, axis=0)

    def predict(self, X):
        t0 = time.perf_counter()
        probs = self.predict_proba(X)
        preds = (probs >= 0.5).astype(np.int64)
        elapsed = time.perf_counter() - t0
        self.inference_time_per_sample_ms = (elapsed / max(1, len(X))) * 1000.0
        return preds


class GradientBoostingModel:
    def __init__(self, n_estimators=100, learning_rate=0.05, max_depth=3, random_state=42):
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        self.max_depth = max_depth
        self.random_state = random_state
        self.trees = []
        self.init_log_odds = 0.0
        self.train_time = 0.0
        self.inference_time_per_sample_ms = 0.0
        self.n_parameters = 0

    def fit(self, X, y):
        t0 = time.perf_counter()
        rng = np.random.RandomState(self.random_state)
        N, D = X.shape
        p0 = np.mean(y)
        self.init_log_odds = float(np.log(p0 / (1.0 - p0 + 1e-12)))
        cur_f = np.full(N, self.init_log_odds)
        self.trees = []
        total_nodes = 0

        for _ in range(self.n_estimators):
            prob = 1.0 / (1.0 + np.exp(-cur_f))
            residual = y - prob
            tree = SimpleDecisionTree(max_depth=self.max_depth, min_samples_split=5)
            # Pseudo-target: pseudo residuals scaled to binary indicator for tree partition
            tree.fit(X, (residual > 0).astype(int), rng=rng)
            self.trees.append(tree)
            total_nodes += tree.node_count
            update = (tree.predict_proba(X) - 0.5) * 2.0
            cur_f += self.learning_rate * update

        self.n_parameters = total_nodes
        self.train_time = time.perf_counter() - t0
        return self

    def predict_proba(self, X):
        cur_f = np.full(len(X), self.init_log_odds)
        for tree in self.trees:
            update = (tree.predict_proba(X) - 0.5) * 2.0
            cur_f += self.learning_rate * update
        return 1.0 / (1.0 + np.exp(-cur_f))

    def predict(self, X):
        t0 = time.perf_counter()
        probs = self.predict_proba(X)
        preds = (probs >= 0.5).astype(np.int64)
        elapsed = time.perf_counter() - t0
        self.inference_time_per_sample_ms = (elapsed / max(1, len(X))) * 1000.0
        return preds


class MLPModel:
    def __init__(self, hidden_sizes=(16, 8), l2_reg=0.01, random_state=42):
        self.hidden_sizes = hidden_sizes
        self.l2_reg = l2_reg
        self.random_state = random_state
        self.weights = []
        self.biases = []
        self.train_time = 0.0
        self.inference_time_per_sample_ms = 0.0
        self.n_parameters = 0

    def fit(self, X, y):
        t0 = time.perf_counter()
        rng = np.random.RandomState(self.random_state)
        N, D = X.shape
        layers = [D] + list(self.hidden_sizes) + [1]
        
        # Calculate parameter slices
        param_counts = []
        for i in range(len(layers) - 1):
            param_counts.append((layers[i] * layers[i+1], layers[i+1]))
        total_p = sum(w + b for w, b in param_counts)
        self.n_parameters = total_p

        def unpack(params):
            idx = 0
            ws, bs = [], []
            for i in range(len(layers) - 1):
                in_d, out_d = layers[i], layers[i+1]
                w = params[idx:idx + in_d * out_d].reshape(in_d, out_d)
                idx += in_d * out_d
                b = params[idx:idx + out_d]
                idx += out_d
                ws.append(w)
                bs.append(b)
            return ws, bs

        def forward(ws, bs, X_in):
            h = X_in
            for i in range(len(ws) - 1):
                h = np.maximum(0, np.dot(h, ws[i]) + bs[i]) # ReLU
            z_out = np.dot(h, ws[-1]) + bs[-1]
            p = 1.0 / (1.0 + np.exp(-np.clip(z_out.flatten(), -30.0, 30.0)))
            return p

        def loss_fn(params):
            ws, bs = unpack(params)
            p = forward(ws, bs, X)
            bce = -np.mean(y * np.log(p + 1e-15) + (1.0 - y) * np.log(1.0 - p + 1e-15))
            reg = 0.5 * self.l2_reg * sum(np.sum(w ** 2) for w in ws)
            return bce + reg

        # Xavier initialization
        init_p = []
        for i in range(len(layers) - 1):
            scale = math.sqrt(2.0 / (layers[i] + layers[i+1]))
            init_w = rng.randn(layers[i] * layers[i+1]) * scale
            init_b = np.zeros(layers[i+1])
            init_p.extend(init_w)
            init_p.extend(init_b)

        res = minimize(loss_fn, np.array(init_p), method="L-BFGS-B", options={"maxiter": 200, "ftol": 1e-6})
        self.weights, self.biases = unpack(res.x)
        self.train_time = time.perf_counter() - t0
        return self

    def predict_proba(self, X):
        h = X
        for i in range(len(self.weights) - 1):
            h = np.maximum(0, np.dot(h, self.weights[i]) + self.biases[i])
        z_out = np.dot(h, self.weights[-1]) + self.biases[-1]
        return 1.0 / (1.0 + np.exp(-np.clip(z_out.flatten(), -30.0, 30.0)))

    def predict(self, X):
        t0 = time.perf_counter()
        probs = self.predict_proba(X)
        preds = (probs >= 0.5).astype(np.int64)
        elapsed = time.perf_counter() - t0
        self.inference_time_per_sample_ms = (elapsed / max(1, len(X))) * 1000.0
        return preds


class MajorityClassModel:
    def __init__(self, random_state=42):
        self.random_state = random_state
        self.prior_p = 0.5
        self.train_time = 0.0
        self.inference_time_per_sample_ms = 0.0
        self.n_parameters = 1

    def fit(self, X, y):
        t0 = time.perf_counter()
        self.prior_p = float(np.mean(y == 1))
        self.train_time = time.perf_counter() - t0
        return self

    def predict_proba(self, X):
        return np.full(len(X), self.prior_p)

    def predict(self, X):
        return np.ones(len(X), dtype=np.int64) if self.prior_p >= 0.5 else np.zeros(len(X), dtype=np.int64)


class VolatilityFilterModel:
    def __init__(self, threshold_quantile=0.75, random_state=42):
        self.threshold_quantile = threshold_quantile
        self.random_state = random_state
        self.threshold = 0.20
        self.train_time = 0.0
        self.inference_time_per_sample_ms = 0.0
        self.n_parameters = 1

    def fit(self, X, y):
        t0 = time.perf_counter()
        # Use column 7 (realized vol) or -2 (VIX level) depending on feature shape
        col = -2 if X.shape[1] >= 8 else -1
        vix_vals = X[:, col]
        self.threshold = float(np.percentile(vix_vals, self.threshold_quantile * 100.0))
        self.train_time = time.perf_counter() - t0
        return self

    def predict_proba(self, X):
        col = -2 if X.shape[1] >= 8 else -1
        vix_vals = X[:, col]
        return np.where(vix_vals < self.threshold, 0.85, 0.15)

    def predict(self, X):
        col = -2 if X.shape[1] >= 8 else -1
        vix_vals = X[:, col]
        return (vix_vals < self.threshold).astype(np.int64)


class ClassicalPipelineWrapper:
    def __init__(self, model_type, config=None, random_state=42):
        self.model_type = model_type
        self.random_state = random_state
        self.config = config or {}
        self.model = self._build_model()
        self.train_time = 0.0
        self.inference_time_per_sample_ms = 0.0
        self.n_parameters = 0

    def _build_model(self):
        if self.model_type == "majority_class":
            return MajorityClassModel(random_state=self.random_state)
        elif self.model_type == "volatility_filter":
            return VolatilityFilterModel(threshold_quantile=self.config.get("threshold_quantile", 0.75), random_state=self.random_state)
        elif self.model_type == "logistic_regression":
            return LogisticRegressionModel(C=self.config.get("C", 1.0), random_state=self.random_state)
        elif self.model_type == "svc_rbf":
            return KernelClassifierModel(kernel="rbf", gamma=self.config.get("gamma", "scale"), C=self.config.get("C", 1.0), random_state=self.random_state)
        elif self.model_type == "svc_linear":
            return KernelClassifierModel(kernel="linear", C=self.config.get("C", 1.0), random_state=self.random_state)
        elif self.model_type == "svc_poly":
            return KernelClassifierModel(kernel="poly", degree=self.config.get("degree", 2), C=self.config.get("C", 1.0), random_state=self.random_state)
        elif self.model_type == "random_forest":
            return RandomForestModel(n_estimators=self.config.get("n_estimators", 100), max_depth=self.config.get("max_depth", 5), random_state=self.random_state)
        elif self.model_type == "gradient_boosting":
            return GradientBoostingModel(n_estimators=self.config.get("n_estimators", 100), learning_rate=self.config.get("learning_rate", 0.05), max_depth=self.config.get("max_depth", 3), random_state=self.random_state)
        elif self.model_type == "mlp":
            return MLPModel(hidden_sizes=tuple(self.config.get("hidden_layer_sizes", [16, 8])), random_state=self.random_state)
        else:
            raise ValueError(f"Unknown classical model: {self.model_type}")

    def fit(self, X, y):
        self.model.fit(X, y)
        self.train_time = self.model.train_time
        self.n_parameters = self.model.n_parameters
        return self

    def predict(self, X):
        preds = self.model.predict(X)
        self.inference_time_per_sample_ms = self.model.inference_time_per_sample_ms
        return preds

    def predict_proba(self, X):
        return self.model.predict_proba(X)


def tune_classical_hyperparameters(model_type, X_train, y_train, random_state=42):
    """
    Performs chronological inner-loop walk-forward validation (70% inner train, 30% inner validation).
    Evaluates candidate hyperparameter grid strictly on inner train and validation splits.
    Zero out-of-sample data leakage into test folds.
    """
    N = len(X_train)
    split_idx = int(0.70 * N)
    X_in_tr, y_in_tr = X_train[:split_idx], y_train[:split_idx]
    X_in_val, y_in_val = X_train[split_idx:], y_train[split_idx:]

    if model_type == "logistic_regression":
        grid = [{"C": 0.01}, {"C": 0.1}, {"C": 1.0}, {"C": 10.0}]
    elif model_type == "svc_rbf":
        grid = [
            {"C": 0.1, "gamma": "scale"},
            {"C": 1.0, "gamma": "scale"},
            {"C": 10.0, "gamma": "scale"},
            {"C": 1.0, "gamma": 0.1}
        ]
    elif model_type == "svc_linear":
        grid = [{"C": 0.1}, {"C": 1.0}, {"C": 10.0}]
    elif model_type == "svc_poly":
        grid = [{"C": 0.1, "degree": 2}, {"C": 1.0, "degree": 2}, {"C": 0.1, "degree": 3}]
    elif model_type == "random_forest":
        grid = [
            {"n_estimators": 50, "max_depth": 3},
            {"n_estimators": 100, "max_depth": 5},
            {"n_estimators": 100, "max_depth": 7}
        ]
    elif model_type == "gradient_boosting":
        grid = [
            {"n_estimators": 50, "learning_rate": 0.02, "max_depth": 2},
            {"n_estimators": 100, "learning_rate": 0.05, "max_depth": 3},
            {"n_estimators": 50, "learning_rate": 0.1, "max_depth": 3}
        ]
    elif model_type == "mlp":
        grid = [
            {"hidden_layer_sizes": [16, 8]},
            {"hidden_layer_sizes": [32, 16]},
            {"hidden_layer_sizes": [16]}
        ]
    elif model_type == "volatility_filter":
        grid = [{"threshold_quantile": 0.50}, {"threshold_quantile": 0.65}, {"threshold_quantile": 0.75}, {"threshold_quantile": 0.85}]
    elif model_type == "majority_class":
        grid = [{}]
    else:
        grid = [{}]

    best_cfg = grid[0]
    best_score = -1e9

    for cfg in grid:
        try:
            m = ClassicalPipelineWrapper(model_type, config=cfg, random_state=random_state)
            m.fit(X_in_tr, y_in_tr)
            probs = m.predict_proba(X_in_val)
            preds = m.predict(X_in_val)
            acc = float(np.mean(preds == y_in_val))
            brier = float(np.mean((probs - y_in_val) ** 2))
            score = acc - 0.5 * brier
            if score > best_score:
                best_score = score
                best_cfg = cfg
        except Exception:
            continue

    # Refit best model on full training fold
    best_model = ClassicalPipelineWrapper(model_type, config=best_cfg, random_state=random_state)
    best_model.fit(X_train, y_train)
    return best_model, best_cfg
