"""
Predictive Performance Metrics for Directional Financial Forecasting.
Calculates Accuracy, ROC-AUC, F1-Score, Precision, Recall, Matthew's Correlation Coefficient (MCC), and Brier Score.
"""
import numpy as np
from sklearn.metrics import (
    accuracy_score,
    roc_auc_score,
    f1_score,
    precision_score,
    recall_score,
    matthews_corrcoef,
    brier_score_loss
)

def compute_classification_metrics(y_true, y_pred, y_prob):
    """
    Computes standard statistical classification metrics.
    """
    acc = float(accuracy_score(y_true, y_pred))
    try:
        auc = float(roc_auc_score(y_true, y_prob))
    except Exception:
        auc = 0.5
    f1 = float(f1_score(y_true, y_pred, zero_division=0))
    prec = float(precision_score(y_true, y_pred, zero_division=0))
    rec = float(recall_score(y_true, y_pred, zero_division=0))
    mcc = float(matthews_corrcoef(y_true, y_pred))
    brier = float(brier_score_loss(y_true, y_prob))

    return {
        "accuracy": acc,
        "auc": auc,
        "f1": f1,
        "precision": prec,
        "recall": rec,
        "mcc": mcc,
        "brier": brier
    }
