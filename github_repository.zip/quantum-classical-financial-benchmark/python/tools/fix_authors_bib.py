import re

def fix_author_string(author_str):
    # Remove leading/trailing braces, whitespace
    author_str = author_str.strip()
    
    # First, handle oxford comma before 'and': ', and ' -> ' and '
    author_str = re.sub(r',\s*and\s+', ' and ', author_str)
    
    # If there are commas separating different authors (e.g. "Last1, I1., Last2, I2. and Last3, I3.")
    # Notice: each author typically has one comma between surname and initials: "Last, I."
    # So if we have multiple authors separated by commas, the pattern is:
    # "Last1, First1, Last2, First2 and Last3, First3"
    
    # Split on ' and ' first
    main_parts = author_str.split(' and ')
    
    cleaned_authors = []
    for part in main_parts:
        part = part.strip()
        # Check if part has multiple authors separated by commas
        # A single author in "Last, First" has 1 comma.
        # If it has more than 1 comma, e.g. "Biamonte, J., Wittek, P., Pancotti, N."
        commas = [m.start() for m in re.finditer(r',', part)]
        if len(commas) > 1:
            # We have multiple authors in this part!
            # Typically alternating: Surname, Given, Surname, Given...
            # Or "Last, F., Last, F."
            # Split by comma followed by whitespace, then recombine in pairs
            subparts = [p.strip() for p in part.split(',') if p.strip()]
            if len(subparts) % 2 == 0:
                # Even number: pair them up!
                for i in range(0, len(subparts), 2):
                    cleaned_authors.append(f"{subparts[i]}, {subparts[i+1]}")
            else:
                # If odd, might be single-word names or complex, fallback
                cleaned_authors.append(part)
        else:
            cleaned_authors.append(part)
            
    # Join with ' and '
    return " and ".join(cleaned_authors)

# Test examples
test1 = "Biamonte, J., Wittek, P., Pancotti, N., Rebentrost, P., Wiebe, N., and Lloyd, S."
print("Test 1:", fix_author_string(test1))

test2 = "Schuld, M., and Killoran, N."
print("Test 2:", fix_author_string(test2))

test3 = "PESARAN, M., and TIMMERMANN, A."
print("Test 3:", fix_author_string(test3))

# Apply to latex/references.bib and references/references_verified.bib
for fpath in ['latex/references.bib', 'references/references_verified.bib']:
    with open(fpath, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        
    out_lines = []
    for line in lines:
        m = re.match(r'^(\s*author\s*=\s*\{)(.*?)(\},?\s*)$', line, flags=re.IGNORECASE)
        if m:
            prefix, auth_str, suffix = m.group(1), m.group(2), m.group(3)
            fixed_auth = fix_author_string(auth_str)
            out_lines.append(f"{prefix}{fixed_auth}{suffix}\n")
        else:
            out_lines.append(line)
            
    with open(fpath, 'w', encoding='utf-8') as f:
        f.writelines(out_lines)
    print(f"Applied author fixes to {fpath}")
