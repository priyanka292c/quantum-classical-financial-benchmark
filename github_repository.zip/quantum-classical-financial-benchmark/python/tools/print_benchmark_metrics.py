import pandas as pd

df = pd.read_csv("python/tables/benchmark_full_results.csv")
cols = ["model", "accuracy", "auc", "f1", "ann_return_1day_delay", "sharpe_1day_delay", "max_drawdown_1day_delay", "turnover", "ann_return_5bps", "sharpe_5bps", "max_drawdown_0lag"]

for idx, r in df[cols].iterrows():
    m = str(r["model"])
    acc = r["accuracy"] * 100
    auc = r["auc"]
    f1 = r["f1"]
    r1 = r["ann_return_1day_delay"] * 100
    sr1 = r["sharpe_1day_delay"]
    dd1 = r["max_drawdown_1day_delay"] * 100
    turn = r["turnover"]
    r0 = r["ann_return_5bps"] * 100
    sr0 = r["sharpe_5bps"]
    dd0 = r["max_drawdown_0lag"] * 100
    print(f"{m:22} | Acc: {acc:5.2f}% | AUC: {auc:6.4f} | F1: {f1:6.4f} | Ret(1d): {r1:6.2f}% | SR(1d): {sr1:6.3f} | DD(1d): {dd1:5.2f}% | Turn: {turn:4.0f} | Ret(0d): {r0:6.2f}% | SR(0d): {sr0:6.3f} | DD(0d): {dd0:5.2f}%")
