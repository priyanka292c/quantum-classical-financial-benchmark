import re

def clean_bib_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Replace HTML entities
    content = content.replace('&amp;', '\\&')
    content = content.replace('&', '\\&')
    # If it was already \\&, replace \\\\& back to \\&
    content = re.sub(r'\\+\\&', r'\\&', content)

    # Remove MathML XML tags like <mml:math ...>...</mml:math>
    content = re.sub(r'<mml:math[^>]*>(.*?)</mml:math>', r'$\1$', content, flags=re.DOTALL)
    content = re.sub(r'<mml:mi[^>]*>(.*?)</mml:mi>', r'\1', content, flags=re.DOTALL)
    content = re.sub(r'<[^>]+>', '', content)

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"Cleaned {filepath}")

clean_bib_file('latex/references.bib')
clean_bib_file('references/references_verified.bib')
