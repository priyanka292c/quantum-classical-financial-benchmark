import re
import os
import glob

# Load all bib keys
with open('latex/references.bib', 'r', encoding='utf-8') as f:
    bib_text = f.read()

bib_keys = set(re.findall(r'@\w+\{([^,]+),', bib_text))
print(f"Total entries in references.bib: {len(bib_keys)}")

# Load all citations in latex sections
section_files = glob.glob('latex/sections/*.tex')
all_tex = ""
for sf in section_files:
    with open(sf, 'r', encoding='utf-8') as f:
        all_tex += f.read() + "\n"

# Match \cite, \citep, \citet, \citealt, etc.
raw_cites = re.findall(r'\\cite[a-z]*\{([^}]+)\}', all_tex)
cited_keys = set()
for rc in raw_cites:
    for k in rc.split(','):
        cited_keys.add(k.strip())

print(f"Total distinct keys cited in sections: {len(cited_keys)}")

missing_in_bib = cited_keys - bib_keys
if missing_in_bib:
    print(f"ERROR: {len(missing_in_bib)} keys cited in LaTeX but missing in .bib: {missing_in_bib}")
else:
    print("SUCCESS: Every cited key exists in references.bib!")

uncited_in_bib = bib_keys - cited_keys
print(f"Uncited keys in .bib ({len(uncited_in_bib)}): {sorted(list(uncited_in_bib))}")
