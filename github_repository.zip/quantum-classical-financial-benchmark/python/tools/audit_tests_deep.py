import pandas as pd
import numpy as np
from scipy import stats

df = pd.read_csv('python/tables/oos_predictions_full.csv')
N = len(df)
y = df['y_true'].values

print(f"Sample size N = {N}")

def compute_newey_west(d, q=7):
    d_mean = np.mean(d)
    e = d - d_mean
    # gamma_0
    gamma_0 = np.sum(e ** 2) / N
    omega = gamma_0
    for j in range(1, q + 1):
        weight = 1.0 - (j / (q + 1.0))
        gamma_j = np.sum(e[j:] * e[:-j]) / N
        omega += 2.0 * weight * gamma_j
    se_hac = np.sqrt(omega / N)
    t_hac = d_mean / se_hac
    p_hac = 2.0 * (1.0 - stats.norm.cdf(np.abs(t_hac)))
    return t_hac, p_hac, se_hac

def run_tests(benchmark_model, competitor_model):
    y_bench = df[f'pred_{benchmark_model}'].values
    y_comp = df[f'pred_{competitor_model}'].values
    
    # Quadratic loss differentials: d_t = (y_t - y_bench)^2 - (y_t - y_comp)^2
    loss_bench = (y - y_bench) ** 2
    loss_comp = (y - y_comp) ** 2
    d = loss_bench - loss_comp
    
    d_mean = np.mean(d)
    d_std = np.std(d, ddof=1)
    
    # Standard Diebold-Mariano
    dm_stat = d_mean / (d_std / np.sqrt(N))
    
    # Harvey, Leybourne, Newbold (1997) finite-sample correction for h=1: sqrt((N-1)/N)
    hln_factor = np.sqrt((N - 1) / N)
    dm_hln = dm_stat * hln_factor
    
    # Two-tailed p-value using Student-t distribution with (N - 1) degrees of freedom
    p_hln = 2.0 * (1.0 - stats.t.cdf(np.abs(dm_hln), df=N - 1))
    
    # HAC with lag q = 7 (Newey-West automatic rule: floor(4 * (1257/100)^(2/9)) = 7)
    q_lag = 7
    t_hac, p_hac, se_hac = compute_newey_west(d, q=q_lag)
    
    return {
        'Benchmark': benchmark_model,
        'Competitor': competitor_model,
        'Mean_Loss_Diff': d_mean,
        'DM_HLN': dm_hln,
        'df': N - 1,
        'p_HLN': p_hln,
        'HAC_Lag': q_lag,
        't_HAC': t_hac,
        'p_HAC': p_hac
    }

comparisons = [
    ('QSVM_ZZ', 'Logistic_Regression'),
    ('QSVM_ZZ', 'SVC_RBF'),
    ('QSVM_ZZ', 'Random_Forest'),
    ('QSVM_ZZ', 'Gradient_Boosting'),
    ('QSVM_ZZ', 'MLP'),
    ('VQC', 'Logistic_Regression'),
    ('VQC', 'Random_Forest'),
    ('VQC', 'QSVM_ZZ')
]

records = [run_tests(bench, comp) for bench, comp in comparisons]
print("\n=== REPRODUCED ECONOMETRIC TEST RESULTS (PURE NUMPY/SCIPY) ===")
for r in records:
    print(f"\n{r['Benchmark']} vs {r['Competitor']}:")
    print(f"  Mean loss diff: {r['Mean_Loss_Diff']:.6f}")
    print(f"  DM_HLN: {r['DM_HLN']:.4f}, df: {r['df']}, p_HLN: {r['p_HLN']:.4f}")
    print(f"  t_HAC (lag={r['HAC_Lag']}): {r['t_HAC']:.4f}, p_HAC: {r['p_HAC']:.4f}")
