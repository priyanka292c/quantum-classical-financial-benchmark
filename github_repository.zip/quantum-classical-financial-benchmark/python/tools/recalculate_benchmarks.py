"""
Recalculate and reconcile all benchmark metrics directly from oos_predictions_full.csv.
Computes:
1. True ROC-AUC for all models (Majority Class = 0.5000, 95% CI [0.500, 0.500])
2. Full economic backtest under Realistic 1-day lag (tau=1)
3. Full economic backtest under Optimistic zero-lag (tau=0)
4. Exports reconciled benchmark_full_results.csv, equity_curves_1day_lag.json, equity_curves_daily.json
5. Generates Table 4 with exact, reconciled metrics.
"""
import os
import json
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, roc_auc_score, f1_score, matthews_corrcoef, brier_score_loss
import sys

sys.path.append(os.path.abspath("python"))
from backtesting.engine import FinancialBacktestEngine
from stats_tests.hypothesis_tests import stationary_bootstrap_ci

df = pd.read_csv("python/tables/oos_predictions_full.csv")
dates = df["date"].values
y_true = df["y_true"].values
r_fwd = df["r_forward"].values
models = [c.replace("pred_", "") for c in df.columns if c.startswith("pred_")]

engine = FinancialBacktestEngine(risk_free_rate=0.02, annualization=252)

# Load existing benchmark results to preserve DM/McNemar test stats and training times
with open("python/tables/benchmark_full_results.csv", "r") as f:
    orig_df = pd.read_csv(f)
orig_meta = orig_df.set_index("model").to_dict(orient="index")

reconciled_rows = []
equity_curves_1d = {}
equity_curves_0d = {}
drawdowns_1d = {}
drawdowns_0d = {}

print("RECALCULATING BENCHMARK METRICS DIRECTLY FROM OOS PREDICTIONS:")
print("=" * 110)

for m in models:
    sig = df[f"pred_{m}"].values
    prob = df[f"prob_{m}"].values
    cost = 0.0 if m == "Buy_and_Hold" else 5.0
    
    # 1. Classification metrics
    acc = float(accuracy_score(y_true, sig))
    f1 = float(f1_score(y_true, sig, zero_division=0))
    mcc = float(matthews_corrcoef(y_true, sig))
    brier = float(brier_score_loss(y_true, prob))
    
    if m in ["Majority_Class", "Buy_and_Hold"]:
        auc = 0.5000
        auc_ci_lower = 0.5000
        auc_ci_upper = 0.5000
    else:
        auc = float(roc_auc_score(y_true, prob))
        auc_ci = stationary_bootstrap_ci(
            lambda yt, pb: float(roc_auc_score(yt, pb)),
            (y_true, prob),
            n_bootstraps=1000
        )
        auc_ci_lower = auc_ci["ci_lower"]
        auc_ci_upper = auc_ci["ci_upper"]
        
    acc_ci = stationary_bootstrap_ci(
        lambda yt, yp: float(np.mean(yt == yp)),
        (y_true, sig),
        n_bootstraps=1000
    )
    acc_ci_lower = acc_ci["ci_lower"]
    acc_ci_upper = acc_ci["ci_upper"]
    
    # 2. Backtesting: Realistic 1-Day Lag (tau = 1)
    res_1d = engine.evaluate_strategy(sig, r_fwd, cost_bps=cost, execution_delay=1)
    m_1d = res_1d["metrics"]
    equity_curves_1d[m] = res_1d["equity_curve"].tolist()
    drawdowns_1d[m] = res_1d["drawdown_series"].tolist()
    
    # 3. Backtesting: Optimistic Zero-Lag (tau = 0)
    res_0d = engine.evaluate_strategy(sig, r_fwd, cost_bps=cost, execution_delay=0)
    m_0d = res_0d["metrics"]
    m_0d_gross = res_0d["metrics_gross"]
    equity_curves_0d[m] = res_0d["equity_curve"].tolist()
    drawdowns_0d[m] = res_0d["drawdown_series"].tolist()
    
    # Preserve metadata from original run
    meta = orig_meta.get(m, {})
    
    row = {
        "model": m,
        "accuracy": acc,
        "acc_ci_lower": acc_ci_lower,
        "acc_ci_upper": acc_ci_upper,
        "auc": auc,
        "auc_ci_lower": auc_ci_lower,
        "auc_ci_upper": auc_ci_upper,
        "f1": f1,
        "mcc": mcc,
        "brier": brier,
        "gross_return": m_0d_gross["cumulative_return"],
        "net_return_5bps": m_0d["cumulative_return"],
        "ann_return_5bps": m_0d["annualized_return"],
        "ann_vol": m_0d["annualized_volatility"],
        "sharpe_5bps": m_0d["sharpe_ratio"],
        "sortino_5bps": m_0d["sortino_ratio"],
        "max_drawdown_0lag": m_0d["max_drawdown"],
        "calmar_0lag": m_0d["calmar_ratio"],
        "turnover": m_0d["total_turnover"],
        "hit_ratio": m_0d["hit_ratio"],
        "ann_return_1day_delay": m_1d["annualized_return"],
        "sharpe_1day_delay": m_1d["sharpe_ratio"],
        "max_drawdown_1day_delay": m_1d["max_drawdown"],
        "calmar_1day_delay": m_1d["calmar_ratio"],
        "dm_stat_vs_lr": meta.get("dm_stat_vs_lr", 0.0),
        "dm_pval_vs_lr": meta.get("dm_pval_vs_lr", 1.0),
        "dm_stat_vs_rf": meta.get("dm_stat_vs_rf", 0.0),
        "dm_pval_vs_rf": meta.get("dm_pval_vs_rf", 1.0),
        "dm_stat_vs_maj": meta.get("dm_stat_vs_maj", 0.0),
        "dm_pval_vs_maj": meta.get("dm_pval_vs_maj", 1.0),
        "mcnemar_pval_vs_lr": meta.get("mcnemar_pval_vs_lr", 1.0),
        "avg_train_sec": meta.get("avg_train_sec", 0.0),
        "avg_inf_ms": meta.get("avg_inf_ms", 0.0),
    }
    # Keep backward-compatible 'max_drawdown' column matching primary convention (1-day delay)
    row["max_drawdown"] = m_1d["max_drawdown"]
    
    reconciled_rows.append(row)
    
    print(f"{m:20s} | Acc: {acc*100:5.2f}% | AUC: {auc:6.4f} [{auc_ci_lower:.3f}, {auc_ci_upper:.3f}] | "
          f"Real AnnRet: {m_1d['annualized_return']*100:+6.2f}% | Real SR: {m_1d['sharpe_ratio']:+6.3f} | "
          f"Real MaxDD: {m_1d['max_drawdown']*100:5.2f}% | Opt SR: {m_0d['sharpe_ratio']:+6.3f} | Opt MaxDD: {m_0d['max_drawdown']*100:5.2f}%")

print("=" * 110)

# Save reconciled benchmark results
res_df = pd.DataFrame(reconciled_rows)
res_df.to_csv("python/tables/benchmark_full_results.csv", index=False)
print("Updated python/tables/benchmark_full_results.csv successfully.")

# Save daily equity curves
with open("python/tables/equity_curves_daily.json", "w") as f:
    json.dump({
        "dates": list(dates),
        "curves": equity_curves_1d, # Primary curves are now 1-day lag!
        "curves_1day_lag": equity_curves_1d,
        "curves_0lag": equity_curves_0d,
        "drawdowns_1day_lag": drawdowns_1d,
        "drawdowns_0lag": drawdowns_0d
    }, f, indent=2)
print("Updated python/tables/equity_curves_daily.json with realistic 1-day lag curves.")
