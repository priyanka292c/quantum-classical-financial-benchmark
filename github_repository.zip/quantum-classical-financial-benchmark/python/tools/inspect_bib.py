import re
with open('latex/references.bib', 'r', encoding='utf-8') as f:
    text = f.read()

entries = re.findall(r'@\w+\{([^,]+),', text)
print(f"Total keys: {len(entries)}")
for i, k in enumerate(entries):
    print(f"{i+1:3d}. {k}")
