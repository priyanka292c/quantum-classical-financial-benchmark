import pandas as pd
import numpy as np
from scipy import stats
from statsmodels.stats.diagnostic import acorr_ljungbox
from statsmodels.tsa.stattools import acf

preds = pd.read_csv('python/tables/oos_predictions_full.csv')
y_true = preds['y_true'].values
T = len(y_true)

models = ['Majority_Class', 'Volatility_Filter', 'Logistic_Regression', 'SVC_Linear', 'SVC_Poly', 'SVC_RBF', 'Random_Forest', 'Gradient_Boosting', 'MLP', 'QSVM_ZZ', 'VQC']

print("================================================================================")
print("DIEBOLD-MARIANO TEST AUDIT: CONTEMPORANEOUS VS HAC LONG-RUN VARIANCE")
print(f"Sample Size: T = {T} days (2020-2024)")
print("================================================================================")

def compute_dm(d, lag=0):
    d_bar = np.mean(d)
    T = len(d)
    gamma0 = np.var(d, ddof=0)
    
    if lag == 0:
        lrv = gamma0
    else:
        lrv = gamma0
        for k in range(1, lag + 1):
            w = 1.0 - k / (lag + 1.0)
            gamma_k = np.mean((d[k:] - d_bar) * (d[:-k] - d_bar))
            lrv += 2.0 * w * gamma_k
            
    if lrv <= 1e-12:
        return 0.0, 1.0, 0.0
        
    hln_factor = np.sqrt((T - 1.0) / float(T))
    dm_stat = (d_bar / np.sqrt(lrv / float(T))) * hln_factor
    pval = 2.0 * (1.0 - stats.t.cdf(abs(dm_stat), df=T - 1))
    return dm_stat, pval, lrv

results = []
for base in ['Logistic_Regression', 'Random_Forest']:
    print(f"\n--- Comparisons against {base} ---")
    for m in models:
        if m == base:
            continue
        d = (y_true != preds[f'pred_{base}']).astype(float) - (y_true != preds[f'pred_{m}']).astype(float)
        if np.var(d) == 0:
            results.append({'model': m, 'base': base, 'dm_raw': 0.0, 'p_raw': 1.0, 'dm_hac': 0.0, 'p_hac': 1.0, 'lb_p': 1.0})
            print(f"{m:20} vs {base:20}: Identical predictions (DM = 0.000, p = 1.000)")
            continue
            
        lb = acorr_ljungbox(d, lags=[5], return_df=True)
        lb_p = lb['lb_pvalue'].iloc[0]
        
        dm_0, p_0, lrv_0 = compute_dm(d, lag=0)
        # Automatic Newey-West lag truncation: q = floor(4 * (T/100)^(2/9)) ~ 7 lags
        q_nw = int(np.floor(4.0 * (T / 100.0) ** (2.0 / 9.0)))
        dm_hac, p_hac, lrv_hac = compute_dm(d, lag=q_nw)
        
        results.append({
            'model': m, 'base': base,
            'dm_raw': dm_0, 'p_raw': p_0,
            'dm_hac': dm_hac, 'p_hac': p_hac,
            'q_nw': q_nw,
            'lb_p': lb_p
        })
        print(f"{m:18} vs {base:18} | Ljung-Box(5) p={lb_p:.4f} | Raw (h=1): DM={dm_0:7.4f}, p={p_0:.4f} | HAC (q={q_nw}): DM={dm_hac:7.4f}, p={p_hac:.4f}")

df_res = pd.DataFrame(results)
print("\nSummary of Quantum comparisons:")
print(df_res[df_res['model'].isin(['QSVM_ZZ', 'VQC'])])
