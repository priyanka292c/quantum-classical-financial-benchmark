"""
Audit Submission Checklist for Risk Journals Submission:
Verifies abstract word count, keywords count, key message lengths,
main text word count, and comprehensive word count.
"""
import os
import re
import glob

def clean_latex(text, strip_tables_figures=True):
    # Strip comments
    txt = re.sub(r'%.*', '', text)
    if strip_tables_figures:
        txt = re.sub(r'\\begin\{(table|figure)\*?\}.*?\\end\{(table|figure)\*?\}', ' ', txt, flags=re.DOTALL)
    # Strip display and inline math
    txt = re.sub(r'\\begin\{equation\*?\}.*?\\end\{equation\*?\}', ' ', txt, flags=re.DOTALL)
    txt = re.sub(r'\\begin\{align\*?\}.*?\\end\{align\*?\}', ' ', txt, flags=re.DOTALL)
    txt = re.sub(r'\$\$.*?\$\$', ' ', txt, flags=re.DOTALL)
    txt = re.sub(r'\$.*?\$', ' ', txt)
    # Strip citations and macros
    txt = re.sub(r'\\cite[a-z]*\{[^}]*\}', ' ', txt)
    txt = re.sub(r'\\[a-zA-Z]+(\[[^\]]*\])?', ' ', txt)
    txt = re.sub(r'[^a-zA-Z0-9\s]', ' ', txt)
    return txt.split()

def audit_journal_requirements():
    print("=" * 80)
    print("SUBMISSION CHECKLIST AUDIT — RISK JOURNALS COMPLIANCE")
    print("=" * 80)
    
    # 1. Frontmatter
    with open('latex/sections/00_frontmatter.tex', 'r', encoding='utf-8') as f:
        fm = f.read()

    abstract_match = re.search(r'\\begin\{abstract\}(.*?)\\end\{abstract\}', fm, re.DOTALL)
    if abstract_match:
        abstract_text = abstract_match.group(1).strip()
        words = clean_latex(abstract_text)
        print(f"1. Abstract Word Count: {len(words)} words (Strict Requirement: 150-200)")
        assert 150 <= len(words) <= 200, f"Abstract length {len(words)} out of bounds!"

    kw_match = re.search(r'\\textbf\{Keywords:\}\s*(.*?)(?=\\\\|\n\n)', fm)
    if kw_match:
        kws = [k.strip() for k in kw_match.group(1).split(';') if k.strip()]
        print(f"2. Keywords Count: {len(kws)} keywords (Strict Requirement: 4-6)")
        for i, kw in enumerate(kws, 1):
            print(f"   [{i}] {kw}")
        assert 4 <= len(kws) <= 6, f"Keywords count {len(kws)} out of bounds!"

    km_items = re.findall(r'\\item\s*(.*?)(?=\\item|\\end\{(?:enumerate|itemize)\})', fm, re.DOTALL)
    print(f"3. Key Messages Bullets: {len(km_items)} items (Strict Requirement: 3-4, each <= 85 chars)")
    assert 3 <= len(km_items) <= 4, f"Key messages count {len(km_items)} out of bounds!"
    for idx, km in enumerate(km_items, 1):
        clean_km = re.sub(r'\\[a-zA-Z]+(\{[^}]*\})?', '', km).strip()
        clean_km = re.sub(r'\s+', ' ', clean_km)
        print(f"   Bullet {idx} [{len(clean_km)} chars <= 85]: \"{clean_km}\"")
        assert len(clean_km) <= 85, f"Bullet {idx} exceeds 85 chars: {len(clean_km)}"

    # 2. Main text word count (Sections 01 to 10)
    main_words = 0
    section_counts = {}
    for i in range(1, 11):
        pattern = f'latex/sections/{i:02d}_*.tex'
        files = glob.glob(pattern)
        for fpath in files:
            with open(fpath, 'r', encoding='utf-8') as f:
                w = clean_latex(f.read())
            sec_name = os.path.basename(fpath)
            section_counts[sec_name] = len(w)
            main_words += len(w)

    print(f"\n4. Main Text Word Count Audit:")
    for sname, cnt in section_counts.items():
        print(f"   {sname:<35}: {cnt:>5} words")
    print(f"   ----------------------------------------")
    print(f"   Total Main Text (Sec 01-10)        : {main_words:>5} words (Guideline: <= 10,000 words)")
    assert main_words <= 10000, f"Main text exceeds 10,000 words: {main_words}"

    # 3. Comprehensive submission word count (Sections 00 to 12)
    total_words = 0
    for fpath in sorted(glob.glob('latex/sections/*.tex')):
        with open(fpath, 'r', encoding='utf-8') as f:
            w = clean_latex(f.read())
        total_words += len(w)

    print(f"   Comprehensive Word Count (Sec 00-12): {total_words:>5} words (Guideline: <= 10,000 words)")
    assert total_words <= 10000, f"Comprehensive word count exceeds 10,000 words: {total_words}"
    print("=" * 80)
    print("ALL JOURNAL FORMAT SPECIFICATIONS FULLY VERIFIED AND COMPLIANT!")
    print("=" * 80)

if __name__ == '__main__':
    audit_journal_requirements()
