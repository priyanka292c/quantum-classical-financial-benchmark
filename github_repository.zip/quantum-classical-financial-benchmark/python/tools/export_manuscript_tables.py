"""
Export Table 4 and Table 9 directly from python/tables/benchmark_full_results.csv
Features Realistic 1-Day Lag (tau=1) as primary economic benchmark and Optimistic 0-Lag (tau=0) as theoretical sensitivity ceiling.
"""
import csv
import math

with open("python/tables/benchmark_full_results.csv", "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    rows = list(reader)

# Table 4: Consolidated Benchmark Table
with open("latex/tables/table04_benchmark_predictive_economic.tex", "w", encoding="utf-8") as f:
    f.write("% Machine-generated table directly from out-of-sample predictions database (zero manual transcription)\n")
    f.write("\\begin{table*}[htbp]\n\\centering\n\\scriptsize\n")
    f.write("\\caption{Consolidated Out-of-Sample Empirical Benchmark Results (2020--2024, $N=1,257$ Trading Days): Predictive Accuracy and Economic Performance Under Primary Realistic 1-Day Execution Latency ($\\tau=1$) versus Optimistic Zero-Latency ($\\tau=0$)}\n")
    f.write("\\label{tab:benchmark_predictive_economic}\n")
    f.write("\\begin{tabular*}{\\textwidth}{l@{\\extracolsep{\\fill}}ccccccccc}\n\\toprule\n")
    f.write("\\textbf{Model Pipeline} & \\textbf{Acc. [95\\% CI]} & \\textbf{AUC [95\\% CI]} & \\textbf{F1} & \\textbf{MCC} & \\textbf{Real. Ann. Ret. ($\\tau=1$)} & \\textbf{Real. Sharpe ($\\tau=1$)} & \\textbf{Real. MaxDD ($\\tau=1$)} & \\textbf{Turnover} & \\textbf{Opt. Sharpe ($\\tau=0$)} \\\\\n\\midrule\n")

    f.write("\\multicolumn{10}{l}{\\textit{Statistical \\& Na\\\"ive Baselines:}} \\\\\n")
    for r in rows:
        if r["model"] in ["Majority_Class", "Buy_and_Hold", "Volatility_Filter"]:
            m_label = r["model"].replace("_", " ")
            ci_acc = f"[{float(r['acc_ci_lower'])*100:.1f}, {float(r['acc_ci_upper'])*100:.1f}]"
            ci_auc = f"[{float(r['auc_ci_lower']):.3f}, {float(r['auc_ci_upper']):.3f}]"
            f.write(f"{m_label} & {float(r['accuracy'])*100:.2f}\\% {ci_acc} & {float(r['auc']):.4f} {ci_auc} & {float(r['f1']):.4f} & {float(r['mcc']):+.4f} & {float(r['ann_return_1day_delay'])*100:+.2f}\\% & {float(r['sharpe_1day_delay']):+.3f} & {float(r['max_drawdown_1day_delay'])*100:.2f}\\% & {int(float(r['turnover']))} & {float(r['sharpe_5bps']):+.3f} \\\\\n")

    f.write("\\midrule\n\\multicolumn{10}{l}{\\textit{Tuned Classical Machine Learning Baselines (Nested Walk-Forward Inner Loop):}} \\\\\n")
    for r in rows:
        if r["model"] in ["Logistic_Regression", "SVC_Linear", "SVC_Poly", "SVC_RBF", "Random_Forest", "Gradient_Boosting", "MLP"]:
            m_label = r["model"].replace("_", " ")
            ci_acc = f"[{float(r['acc_ci_lower'])*100:.1f}, {float(r['acc_ci_upper'])*100:.1f}]"
            ci_auc = f"[{float(r['auc_ci_lower']):.3f}, {float(r['auc_ci_upper']):.3f}]"
            f.write(f"{m_label} & {float(r['accuracy'])*100:.2f}\\% {ci_acc} & {float(r['auc']):.4f} {ci_auc} & {float(r['f1']):.4f} & {float(r['mcc']):+.4f} & {float(r['ann_return_1day_delay'])*100:+.2f}\\% & {float(r['sharpe_1day_delay']):+.3f} & {float(r['max_drawdown_1day_delay'])*100:.2f}\\% & {int(float(r['turnover']))} & {float(r['sharpe_5bps']):+.3f} \\\\\n")

    f.write("\\midrule\n\\multicolumn{10}{l}{\\textit{Quantum Computational Pipelines (Qiskit Statevector Simulation):}} \\\\\n")
    for r in rows:
        if r["model"] in ["QSVM_ZZ", "VQC"]:
            m_label = "QSVM-ZZ ($n=4$)" if r["model"] == "QSVM_ZZ" else "VQC ($n=4, L=2$)"
            ci_acc = f"[{float(r['acc_ci_lower'])*100:.1f}, {float(r['acc_ci_upper'])*100:.1f}]"
            ci_auc = f"[{float(r['auc_ci_lower']):.3f}, {float(r['auc_ci_upper']):.3f}]"
            f.write(f"{m_label} & {float(r['accuracy'])*100:.2f}\\% {ci_acc} & {float(r['auc']):.4f} {ci_auc} & {float(r['f1']):.4f} & {float(r['mcc']):+.4f} & {float(r['ann_return_1day_delay'])*100:+.2f}\\% & {float(r['sharpe_1day_delay']):+.3f} & {float(r['max_drawdown_1day_delay'])*100:.2f}\\% & {int(float(r['turnover']))} & {float(r['sharpe_5bps']):+.3f} \\\\\n")

    f.write("\\bottomrule\n\\end{tabular*}\n")
    f.write("\\par\\vspace{0.8ex}{\\scriptsize \\textit{Note:} All models were tuned strictly within chronological inner training splits with zero test-period leakage. All economic performance metrics incorporate standard institutional execution friction of 5 basis points (0.05\\%) per trade. Primary realistic execution ($\\tau=1$) models institutional trade latency where signals generated at day $t$ close are executed at day $t+1$ close. Optimistic execution ($\\tau=0$) represents an upper-bound sensitivity analysis assuming instantaneous same-day close settlement. Confidence intervals (95\\% CI) are evaluated via 1,000 stationary bootstrap replications. Real.\\ MaxDD represents peak-to-trough equity decline under primary 1-day delayed execution. Turnover denotes total position flips across the 1,257 test days.}\n")
    f.write("\\end{table*}\n")

# Table 9: Execution Timing Robustness Table (Reporting both Sharpe, Return, and MaxDD for tau=1 vs tau=0)
with open("latex/tables/table09_execution_timing_robustness.tex", "w", encoding="utf-8") as f:
    f.write("% Machine-generated execution timing robustness table\n")
    f.write("\\begin{table}[htbp]\n\\centering\n\\small\n")
    f.write("\\caption{Execution Timing Robustness: Primary Realistic 1-Day Delayed Execution vs. Optimistic Zero-Latency Sensitivity ($c = 5$ bps)}\n")
    f.write("\\label{tab:execution_timing_robustness}\n")
    f.write("\\begin{tabular}{lcccccc}\n\\toprule\n")
    f.write("\\textbf{Model Pipeline} & \\textbf{Real. Sharpe ($\\tau=1$)} & \\textbf{Opt. Sharpe ($\\tau=0$)} & \\textbf{Real. Ann. Ret.} & \\textbf{Opt. Ann. Ret.} & \\textbf{Real. MaxDD} & \\textbf{Opt. MaxDD} \\\\\n\\midrule\n")
    for r in rows:
        m_label = r["model"].replace("_", " ")
        if m_label == "QSVM ZZ": m_label = "QSVM-ZZ ($n=4$)"
        elif m_label == "VQC": m_label = "VQC ($n=4, L=2$)"
        f.write(f"{m_label} & {float(r['sharpe_1day_delay']):+.3f} & {float(r['sharpe_5bps']):+.3f} & {float(r['ann_return_1day_delay'])*100:+.2f}\\% & {float(r['ann_return_5bps'])*100:+.2f}\\% & {float(r['max_drawdown_1day_delay'])*100:.2f}\\% & {float(r['max_drawdown_0lag'])*100:.2f}\\% \\\\\n")
    f.write("\\bottomrule\n\\end{tabular}\n")
    f.write("\\par\\vspace{0.8ex}{\\scriptsize \\textit{Note:} Realistic delayed execution ($\\tau=1$) models institutional trade latency where signals generated at day $t$ close are executed at day $t+1$ close. Optimistic zero-latency execution ($\\tau=0$) assumes instantaneous closing auction settlement. High-turnover quantum strategies experience complete performance collapse under realistic operational latency.}\n")
    f.write("\\end{table}\n")

print("Exported Table 4 and Table 9 successfully!")
