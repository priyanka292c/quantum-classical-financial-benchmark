import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score, confusion_matrix, accuracy_score, brier_score_loss

df = pd.read_csv('python/tables/oos_predictions_full.csv')
print(f"Total out-of-sample observations: {len(df)}")
print(f"Date range: {df['date'].min()} to {df['date'].max()}")
print("\nClass Distribution of y_true:")
print(df['y_true'].value_counts())
pos_prop = (df['y_true'] == 1).mean()
print(f"Positive class proportion: {pos_prop:.4%} (N_pos = {(df['y_true']==1).sum()}, N_neg = {(df['y_true']==0).sum()})")

# Check relationship between r_forward and y_true
# Note: In financial prediction, y_true = 1 if r_forward > 0 else 0
correct_sign = ((df['r_forward'] > 0) == (df['y_true'] == 1)).all()
print(f"Ground truth alignment: r_forward > 0 <==> y_true == 1: {correct_sign}")

models = [
    'Majority_Class', 'Volatility_Filter', 'Logistic_Regression',
    'SVC_Linear', 'SVC_Poly', 'SVC_RBF', 'Random_Forest',
    'Gradient_Boosting', 'MLP', 'QSVM_ZZ', 'VQC'
]

results = []

for m in models:
    prob_col = f'prob_{m}'
    pred_col = f'pred_{m}'
    
    y = df['y_true']
    pred = df[pred_col]
    p = df[prob_col]
    
    acc = accuracy_score(y, pred)
    tn, fp, fn, tp = confusion_matrix(y, pred).ravel()
    brier = brier_score_loss(y, p)
    
    # Continuous AUC
    try:
        auc_cont = roc_auc_score(y, p)
    except Exception as e:
        auc_cont = np.nan
        
    # Binary AUC
    try:
        auc_bin = roc_auc_score(y, pred)
    except Exception as e:
        auc_bin = np.nan
        
    p_min = p.min()
    p_max = p.max()
    p_mean = p.mean()
    p_gt_half = (p > 0.5).sum()
    p_le_half = (p <= 0.5).sum()
    
    results.append({
        'Model': m,
        'Acc': acc,
        'TP': tp,
        'FP': fp,
        'TN': tn,
        'FN': fn,
        'AUC_cont': auc_cont,
        'AUC_bin': auc_bin,
        'Brier': brier,
        'P_min': p_min,
        'P_max': p_max,
        'P_gt_0.5': p_gt_half,
        'P_le_0.5': p_le_half
    })

res_df = pd.DataFrame(results)
print("\n=== COMPLETE MODEL AUDIT TABLE ===")
print(res_df.to_string(index=False))

print("\n=== DETAILED ANALYSIS: LOGISTIC REGRESSION & MLP ===")
for m in ['Logistic_Regression', 'MLP']:
    p = df[f'prob_{m}']
    pred = df[f'pred_{m}']
    print(f"\nModel: {m}")
    print(f"Prob min: {p.min():.6f}")
    print(f"Prob 25%: {p.quantile(0.25):.6f}")
    print(f"Prob median: {p.median():.6f}")
    print(f"Prob 75%: {p.quantile(0.75):.6f}")
    print(f"Prob max: {p.max():.6f}")
    print(f"Number of prob <= 0.50: {(p <= 0.5).sum()}")
    print(f"Number of pred == 0: {(pred == 0).sum()}")
    print(f"Number of pred == 1: {(pred == 1).sum()}")
    print(f"ROC-AUC (continuous prob): {roc_auc_score(df['y_true'], p):.4f}")
    print(f"ROC-AUC (binary pred): {roc_auc_score(df['y_true'], pred):.4f}")
    # Manual AUC check: sum of ranks of positive examples
    n_pos = (df['y_true'] == 1).sum()
    n_neg = (df['y_true'] == 0).sum()
    # Mann-Whitney U test statistic
    ranks = p.rank()
    u_stat = ranks[df['y_true'] == 1].sum() - n_pos * (n_pos + 1) / 2
    auc_manual = u_stat / (n_pos * n_neg)
    print(f"Manual Mann-Whitney AUC: {auc_manual:.4f}")
