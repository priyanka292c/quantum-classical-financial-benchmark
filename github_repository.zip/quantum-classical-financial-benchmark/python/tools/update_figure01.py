"""
Updates Figure 1 across all project directories using the user-uploaded image.
Generates .png, .jpg, .pdf, and .svg.
"""
import os
import base64
from PIL import Image

def update_figure01():
    src_path = r'C:\Users\priya\.gemini\antigravity-ide\brain\0d106b5b-100e-4e61-8bd1-4711e300a920\.user_uploaded\media_1791717968067.png'
    if not os.path.exists(src_path):
        raise FileNotFoundError(f"Cannot find source image at {src_path}")

    img = Image.open(src_path)
    width, height = img.size

    with open(src_path, 'rb') as f:
        png_bytes = f.read()

    # Save high-quality JPG
    img_rgb = img.convert('RGB')
    temp_jpg = 'temp_figure01.jpg'
    img_rgb.save(temp_jpg, 'JPEG', quality=98)
    with open(temp_jpg, 'rb') as f:
        jpg_bytes = f.read()
    if os.path.exists(temp_jpg):
        os.remove(temp_jpg)

    # Save PDF
    temp_pdf = 'temp_figure01.pdf'
    img_rgb.save(temp_pdf, 'PDF', resolution=300.0)
    with open(temp_pdf, 'rb') as f:
        pdf_bytes = f.read()
    if os.path.exists(temp_pdf):
        os.remove(temp_pdf)

    # Save SVG wrapper embedding base64 PNG
    b64_png = base64.b64encode(png_bytes).decode('ascii')
    svg_content = f"""<?xml version="1.0" encoding="utf-8" standalone="no"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN"
  "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg xmlns:xlink="http://www.w3.org/1999/xlink" width="{width}px" height="{height}px" viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg" version="1.1">
  <g id="figure_1">
    <image width="{width}" height="{height}" xlink:href="data:image/png;base64,{b64_png}"/>
  </g>
</svg>
"""

    dest_dirs = [
        'figures/figure01',
        'latex/figures',
        'FINAL_SUBMISSION/figures',
        'FINAL_SUBMISSION/Editable_Figures_and_Tables/figures',
        'FINAL_SUBMISSION/source_code/matlab/export_figures',
        'matlab/export_figures',
        'submission/figures',
        'submission/Editable_Figures_and_Tables/figures'
    ]

    for d in dest_dirs:
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, 'figure01.png'), 'wb') as f:
            f.write(png_bytes)
        with open(os.path.join(d, 'figure01.jpg'), 'wb') as f:
            f.write(jpg_bytes)
        with open(os.path.join(d, 'figure01.pdf'), 'wb') as f:
            f.write(pdf_bytes)
        with open(os.path.join(d, 'figure01.svg'), 'w', encoding='utf-8') as f:
            f.write(svg_content)

    print(f"Successfully deployed user-supplied Figure 1 (Dimensions: {width}x{height}) across {len(dest_dirs)} directories!")

if __name__ == '__main__':
    update_figure01()
