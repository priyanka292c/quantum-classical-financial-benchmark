"""
Creates the two required ZIP packages:
1. JCF_Quantum_Classical_Benchmark_Submission.zip
2. JCF_Quantum_Classical_Benchmark_GitHub.zip
Strictly excludes temporary build files, __pycache__, .aux, .log, .pyc, credentials.
"""
import os
import zipfile

def should_exclude(relpath):
    parts = relpath.replace('\\', '/').split('/')
    if any(p.startswith('.') for p in parts if p not in ['.gitignore']):
        return True
    if '__pycache__' in parts:
        return True
    if any(p.startswith('.venv') or p.startswith('venv') for p in parts):
        return True
    if any(p in ['scratch', 'node_modules', 'export_figures'] for p in parts):
        return True
    ext = os.path.splitext(relpath)[1].lower()
    if ext in ['.pyc', '.pyo', '.pyd', '.aux', '.log', '.fls', '.fdb_latexmk', '.synctex.gz', '.out', '.toc', '.bbl', '.blg', '.asv']:
        return True
    if ext == '.zip':
        return True
    if relpath.replace('\\', '/').endswith('generate_docx_submission.py'):
        return True
    return False

import shutil
import hashlib

def get_sha256(filepath):
    h = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while chunk := f.read(8192):
            h.update(chunk)
    return h.hexdigest()

def make_reproducibility_package_zip():
    zip_path = "reproducibility_package.zip"
    include_dirs = ["data", "python", "matlab"]
    include_files = [
        "README.md", "LICENSE", "CITATION.cff", "requirements.txt", "environment.yml"
    ]
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        # Include top-level files
        for f in include_files:
            if os.path.exists(f):
                zf.write(f, os.path.join("reproducibility_package", f))
                
        if os.path.exists("FINAL_SUBMISSION/references_verified.bib"):
            zf.write("FINAL_SUBMISSION/references_verified.bib", "reproducibility_package/references_verified.bib")
        elif os.path.exists("references_verified.bib"):
            zf.write("references_verified.bib", "reproducibility_package/references_verified.bib")
            
        # Add convenient root reproduction script
        if os.path.exists("python/tools/reproduce_computational_tests.py"):
            zf.write("python/tools/reproduce_computational_tests.py", "reproducibility_package/reproduce_all_results.py")

        for d in include_dirs:
            if os.path.exists(d):
                for root, dirs, files in os.walk(d):
                    for file in files:
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, ".")
                        if not should_exclude(rel_path):
                            arcname = os.path.join("reproducibility_package", rel_path)
                            zf.write(full_path, arcname)

    # Sync to FINAL_SUBMISSION and submission directories
    shutil.copy2(zip_path, "FINAL_SUBMISSION/reproducibility_package.zip")
    shutil.copy2(zip_path, "submission/reproducibility_package.zip")
    
    sha = get_sha256(zip_path)
    print(f"Created {zip_path} (Size: {os.path.getsize(zip_path)/1024/1024:.2f} MB, SHA-256: {sha})")
    return sha

def make_submission_zip():
    zip_path = "JCF_Quantum_Classical_Benchmark_Submission.zip"
    source_dir = "FINAL_SUBMISSION"
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(source_dir):
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, source_dir)
                if not should_exclude(rel_path):
                    # Write inside archive
                    arcname = os.path.join("JCF_Quantum_Classical_Benchmark_Submission", rel_path)
                    zf.write(full_path, arcname)
                    
    print(f"Created {zip_path} (Size: {os.path.getsize(zip_path)/1024/1024:.2f} MB)")

def make_github_zip():
    zip_path = "JCF_Quantum_Classical_Benchmark_GitHub.zip"
    
    include_dirs = [
        "data", "python", "matlab", "latex", 
        "quality_control", "authors", "journal_requirements", "references", "research_gap"
    ]
    include_files = [
        "README.md", "LICENSE", "CITATION.cff", ".gitignore", 
        "requirements.txt", "environment.yml", "config.yaml"
    ]
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for f in include_files:
            if os.path.exists(f):
                zf.write(f, os.path.join("quantum-classical-financial-benchmark", f))
                
        # Include convenient root reproduction script
        if os.path.exists("python/tools/reproduce_computational_tests.py"):
            zf.write("python/tools/reproduce_computational_tests.py", "quantum-classical-financial-benchmark/reproduce_all_results.py")

        for d in include_dirs:
            if os.path.exists(d):
                for root, dirs, files in os.walk(d):
                    for file in files:
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, ".")
                        if not should_exclude(rel_path):
                            arcname = os.path.join("quantum-classical-financial-benchmark", rel_path)
                            zf.write(full_path, arcname)
                            
    shutil.copy2(zip_path, "github_repository.zip")
    size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    print(f"Created {zip_path} and github_repository.zip (Size: {size_mb:.2f} MB, strictly <= 25MB: {size_mb <= 25.0})")

if __name__ == "__main__":
    make_reproducibility_package_zip()
    make_submission_zip()
    make_github_zip()

