"""
Quantum Computational Pipelines for Financial Time-Series Forecasting.
Implements:
1. Quantum Support Vector Classifier (QSVM) using Havlíček et al. (2019) ZZ-FeatureMap.
2. Variational Quantum Classifier (VQC) with parameterized RealAmplitudes ansatz and classical optimizer.
Tracks exact quantum metrics: Qubit count, circuit depth, 2-qubit CNOT count, parameter count, and simulation runtime.
"""
import time
import math
import numpy as np
from scipy.optimize import minimize
from scipy.linalg import solve
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

class QuantumKernelPipeline:
    def __init__(self, n_qubits=4, reps=2, entanglement="linear", C=1.0, random_state=42):
        self.n_qubits = n_qubits
        self.reps = reps
        self.entanglement = entanglement
        self.C = C
        self.random_state = random_state
        self.alpha = None
        self.train_time = 0.0
        self.inference_time_per_sample_ms = 0.0
        self.circuit_depth = 0
        self.cnot_count = 0
        self.n_parameters = 0
        self.X_train_statevectors = None
        self._analyze_circuit()

    def _build_feature_map(self, x):
        """
        Constructs Havlíček et al. (2019) ZZ-Feature Map circuit for a single sample x.
        """
        qc = QuantumCircuit(self.n_qubits)
        for _ in range(self.reps):
            # Hadamards
            for q in range(self.n_qubits):
                qc.h(q)
            # Rz phase rotations
            for q in range(self.n_qubits):
                qc.rz(2.0 * x[q], q)
            # Two-qubit ZZ interactions
            if self.entanglement == "linear":
                pairs = [(i, i + 1) for i in range(self.n_qubits - 1)]
            else:
                pairs = [(i, j) for i in range(self.n_qubits) for j in range(i + 1, self.n_qubits)]

            for q1, q2 in pairs:
                qc.cx(q1, q2)
                phi_val = 2.0 * (math.pi - x[q1]) * (math.pi - x[q2])
                qc.rz(phi_val, q2)
                qc.cx(q1, q2)
        return qc

    def _analyze_circuit(self):
        sample_x = np.ones(self.n_qubits) * (math.pi / 2.0)
        qc = self._build_feature_map(sample_x)
        self.circuit_depth = qc.depth()
        # Count CNOTs
        ops = qc.count_ops()
        self.cnot_count = ops.get("cx", 0)
        self.n_parameters = self.n_qubits

    def _compute_statevectors(self, X):
        """
        Vectorized computation of quantum statevectors across samples.
        Returns complex matrix of shape [N, 2^n].
        """
        N = len(X)
        dim = 2 ** self.n_qubits
        statevectors = np.zeros((N, dim), dtype=np.complex128)
        for i in range(N):
            qc = self._build_feature_map(X[i])
            sv = Statevector.from_instruction(qc)
            statevectors[i] = sv.data
        return statevectors

    def fit(self, X_train, y_train):
        t0 = time.perf_counter()
        # Compute training quantum statevectors
        self.X_train_statevectors = self._compute_statevectors(X_train)
        N = len(X_train)
        
        # Exact quantum fidelity Gram matrix: K_ij = |<psi_i | psi_j>|^2
        S = np.dot(self.X_train_statevectors, self.X_train_statevectors.conj().T)
        K_train = np.abs(S) ** 2.0
        np.fill_diagonal(K_train, 1.0)
        
        # Solve dual regularized problem: (K + lambda I) alpha = y_tilde where y_tilde in {-1, +1}
        y_tilde = np.where(y_train == 1, 1.0, -1.0)
        reg = 1.0 / (self.C * float(N))
        K_reg = K_train + reg * np.eye(N)
        self.alpha = solve(K_reg, y_tilde, assume_a="pos")
        
        self.train_time = time.perf_counter() - t0
        self.n_parameters = N
        return self

    def predict_proba(self, X_test):
        X_test_sv = self._compute_statevectors(X_test)
        S_test = np.dot(X_test_sv, self.X_train_statevectors.conj().T)
        K_test = np.abs(S_test) ** 2.0
        f_scores = np.dot(K_test, self.alpha)
        return 1.0 / (1.0 + np.exp(-np.clip(f_scores, -30.0, 30.0)))

    def predict(self, X_test):
        t0 = time.perf_counter()
        probs = self.predict_proba(X_test)
        preds = (probs >= 0.5).astype(np.int64)
        elapsed = time.perf_counter() - t0
        self.inference_time_per_sample_ms = (elapsed / max(1, len(X_test))) * 1000.0
        return preds


class VariationalQuantumClassifierPipeline:
    def __init__(self, n_qubits=4, reps=2, max_iter=80, random_state=42):
        self.n_qubits = n_qubits
        self.reps = reps
        self.max_iter = max_iter
        self.random_state = random_state
        
        # Parameters count for RealAmplitudes ansatz: n_qubits * (reps + 1)
        self.n_ansatz_params = self.n_qubits * (self.reps + 1)
        self.theta = None
        self.train_time = 0.0
        self.inference_time_per_sample_ms = 0.0
        
        self.circuit_depth = 0
        self.cnot_count = 0
        self.n_parameters = self.n_ansatz_params
        self._analyze_circuit()

    def _analyze_circuit(self):
        sample_x = np.ones(self.n_qubits) * (math.pi / 2.0)
        sample_theta = np.zeros(self.n_ansatz_params)
        qc = self._build_full_circuit(sample_x, sample_theta)
        self.circuit_depth = qc.depth()
        self.cnot_count = qc.count_ops().get("cx", 0)

    def _build_full_circuit(self, x, theta):
        qc = QuantumCircuit(self.n_qubits)
        # 1. Feature Map (H + Rz + CNOT ZZ)
        for q in range(self.n_qubits):
            qc.h(q)
            qc.rz(2.0 * x[q], q)
        for i in range(self.n_qubits - 1):
            qc.cx(i, i + 1)
            qc.rz(2.0 * (math.pi - x[i]) * (math.pi - x[i + 1]), i + 1)
            qc.cx(i, i + 1)

        # 2. RealAmplitudes Ansatz (Ry + CNOT layers)
        param_idx = 0
        for r in range(self.reps):
            for q in range(self.n_qubits):
                qc.ry(theta[param_idx], q)
                param_idx += 1
            for q in range(self.n_qubits - 1):
                qc.cx(q, q + 1)
        # Final rotation layer
        for q in range(self.n_qubits):
            qc.ry(theta[param_idx], q)
            param_idx += 1

        return qc

    def _predict_single_sample(self, x, theta):
        qc = self._build_full_circuit(x, theta)
        sv = Statevector.from_instruction(qc)
        # Measure Pauli Z on qubit 0
        probs = sv.probabilities()
        exp_z = 0.0
        for state_idx, prob in enumerate(probs):
            bit_0 = state_idx & 1  # LSB
            sign = 1.0 if bit_0 == 0 else -1.0
            exp_z += sign * prob
        p1 = (1.0 + exp_z) / 2.0
        return np.clip(p1, 1e-6, 1.0 - 1e-6)

    def _predict_batch_prob(self, X, theta):
        return np.array([self._predict_single_sample(X[i], theta) for i in range(len(X))])

    def fit(self, X_train, y_train):
        t0 = time.perf_counter()
        np.random.seed(self.random_state)
        init_theta = np.random.uniform(-0.5, 0.5, size=self.n_ansatz_params)

        # Subsample for VQC training efficiency if training set is large (e.g. 150 points for fast convergence)
        if len(X_train) > 150:
            indices = np.linspace(0, len(X_train) - 1, 150, dtype=int)
            X_sub = X_train[indices]
            y_sub = y_train[indices]
        else:
            X_sub = X_train
            y_sub = y_train

        def loss_fn(theta):
            probs = self._predict_batch_prob(X_sub, theta)
            bce = -np.mean(y_sub * np.log(probs) + (1.0 - y_sub) * np.log(1.0 - probs))
            reg = 0.01 * np.sum(theta ** 2)
            return bce + reg

        res = minimize(loss_fn, init_theta, method="COBYLA", options={"maxiter": self.max_iter, "rhobeg": 0.5})
        self.theta = res.x
        self.train_time = time.perf_counter() - t0
        return self

    def predict_proba(self, X_test):
        return self._predict_batch_prob(X_test, self.theta)

    def predict(self, X_test):
        t0 = time.perf_counter()
        probs = self.predict_proba(X_test)
        preds = (probs >= 0.5).astype(np.int64)
        elapsed = time.perf_counter() - t0
        self.inference_time_per_sample_ms = (elapsed / max(1, len(X_test))) * 1000.0
        return preds
