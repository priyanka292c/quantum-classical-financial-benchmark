"""
Econometric and Statistical Hypothesis Testing for Financial Forecasting Benchmark.
Implements:
1. Diebold-Mariano test with Harvey-Leybourne-Newbold (1997) finite-sample correction.
2. McNemar's paired contingency test with Edwards continuity correction.
3. Stationary block bootstrap (Politis & Romano 1994) for 95% confidence intervals.
4. Wilcoxon signed-rank test.
"""
import math
import numpy as np
from scipy import stats

def diebold_mariano_test(y_true, y_pred1, y_pred2, loss_type="zero_one", h=1):
    """
    Computes the Diebold-Mariano (1995) test with Harvey-Leybourne-Newbold (1997) correction.
    loss_type: 'zero_one' (0-1 loss) or 'squared' (brier loss).
    A positive DM statistic indicates Model 2 has lower loss than Model 1 (Model 2 is superior).
    """
    y_true = np.asarray(y_true)
    y_pred1 = np.asarray(y_pred1)
    y_pred2 = np.asarray(y_pred2)
    T = len(y_true)

    if loss_type == "zero_one":
        loss1 = (y_true != y_pred1).astype(np.float64)
        loss2 = (y_true != y_pred2).astype(np.float64)
    elif loss_type == "squared":
        loss1 = (y_true - y_pred1) ** 2.0
        loss2 = (y_true - y_pred2) ** 2.0
    else:
        raise ValueError(f"Unknown loss_type: {loss_type}")

    # Loss differential: d_t = loss1 - loss2
    d = loss1 - loss2
    d_bar = np.mean(d)

    # Autocovariance up to lag h - 1 (for 1-step ahead h=1, lag=0)
    gamma0 = np.var(d, ddof=0)
    long_run_var = gamma0
    for k in range(1, h):
        gamma_k = np.mean((d[k:] - d_bar) * (d[:-k] - d_bar))
        weight = 1.0 - (k / float(h))
        long_run_var += 2.0 * weight * gamma_k

    if long_run_var <= 1e-12:
        return {"dm_stat": 0.0, "p_value": 1.0, "mean_differential": float(d_bar)}

    dm_stat = d_bar / math.sqrt(long_run_var / float(T))

    # Harvey-Leybourne-Newbold (1997) adjustment factor
    hln_factor = math.sqrt((T + 1.0 - 2.0 * h + (h * (h - 1.0)) / float(T)) / float(T))
    dm_hln = dm_stat * hln_factor

    # Two-sided p-value from Student's t distribution with T-1 d.o.f.
    p_val = 2.0 * (1.0 - stats.t.cdf(abs(dm_hln), df=T - 1))

    return {
        "dm_stat": float(dm_hln),
        "p_value": float(p_val),
        "mean_differential": float(d_bar)
    }


def mcnemar_paired_test(y_true, y_pred1, y_pred2):
    """
    Computes McNemar's test for paired classification predictions with continuity correction.
    """
    y_true = np.asarray(y_true)
    y_pred1 = np.asarray(y_pred1)
    y_pred2 = np.asarray(y_pred2)

    correct1 = (y_pred1 == y_true)
    correct2 = (y_pred2 == y_true)

    # b: Model 1 correct, Model 2 incorrect
    b = int(np.sum(correct1 & ~correct2))
    # c: Model 1 incorrect, Model 2 correct
    c = int(np.sum(~correct1 & correct2))

    if b + c == 0:
        return {"chi2_stat": 0.0, "p_value": 1.0, "table": [[0, 0], [0, 0]]}

    # Chi-square with Edwards continuity correction
    chi2_stat = ((abs(b - c) - 1.0) ** 2.0) / float(b + c)
    p_val = float(1.0 - stats.chi2.cdf(chi2_stat, df=1))

    return {
        "chi2_stat": float(chi2_stat),
        "p_value": float(p_val),
        "b_model1_only": b,
        "c_model2_only": c
    }


def stationary_bootstrap_ci(metric_fn, data_tuple, n_bootstraps=1000, p_geom=0.1, alpha=0.05, seed=42):
    """
    Stationary block bootstrap (Politis & Romano 1994) for time-series confidence intervals.
    p_geom: probability parameter for geometric block length (expected block length = 1/p_geom).
    """
    rng = np.random.RandomState(seed)
    N = len(data_tuple[0])
    boot_stats = []

    for _ in range(n_bootstraps):
        indices = []
        cur_idx = rng.randint(0, N)
        while len(indices) < N:
            indices.append(cur_idx)
            if rng.rand() < p_geom:
                cur_idx = rng.randint(0, N)
            else:
                cur_idx = (cur_idx + 1) % N

        idx_arr = np.array(indices[:N])
        sampled_data = tuple(arr[idx_arr] for arr in data_tuple)
        val = metric_fn(*sampled_data)
        if not math.isnan(val):
            boot_stats.append(val)

    if not boot_stats:
        return {"ci_lower": np.nan, "ci_upper": np.nan, "std_err": np.nan}

    boot_stats = np.array(boot_stats)
    lower = float(np.percentile(boot_stats, 100.0 * (alpha / 2.0)))
    upper = float(np.percentile(boot_stats, 100.0 * (1.0 - alpha / 2.0)))
    se = float(np.std(boot_stats))

    return {
        "ci_lower": lower,
        "ci_upper": upper,
        "std_err": se
    }


def wilcoxon_test(returns1, returns2):
    """
    Wilcoxon signed-rank test on paired strategy return series.
    """
    diff = np.asarray(returns1) - np.asarray(returns2)
    # Filter exact zeros
    diff_nonzero = diff[diff != 0]
    if len(diff_nonzero) < 10:
        return {"stat": 0.0, "p_value": 1.0}
    stat, p_val = stats.wilcoxon(diff_nonzero)
    return {"stat": float(stat), "p_value": float(p_val)}
