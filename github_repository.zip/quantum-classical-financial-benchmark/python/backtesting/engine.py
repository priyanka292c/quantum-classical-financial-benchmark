"""
Financial Backtesting Engine with Parametric Transaction Costs and Risk Analysis.
Simulates long-short and long-flat directional strategies with execution friction.
Calculates Cumulative Return, Annualized Sharpe, Sortino, Calmar, Maximum Drawdown, and Turnover.
"""
import math
import numpy as np

class FinancialBacktestEngine:
    def __init__(self, risk_free_rate=0.02, annualization=252):
        self.rf = risk_free_rate
        self.ann_factor = annualization

    def evaluate_strategy(self, signals, forward_returns, cost_bps=5.0, mode="long_short", execution_delay=0):
        """
        Executes backtest for a single prediction series.
        signals: array of binary predictions (1 = Up, 0 = Down)
        forward_returns: array of realized asset returns r_{t+1}
        cost_bps: round-trip transaction cost in basis points (e.g. 5 bps = 0.0005)
        mode: 'long_short' (w in {-1, +1}) or 'long_flat' (w in {0, +1})
        execution_delay: 0 for close-to-close benchmark, 1 for realistic 1-day execution lag
        """
        signals = np.asarray(signals)
        r_fwd = np.asarray(forward_returns)
        T = len(signals)

        if mode == "long_short":
            raw_weights = np.where(signals == 1, 1.0, -1.0)
        elif mode == "long_flat":
            raw_weights = np.where(signals == 1, 1.0, 0.0)
        else:
            raise ValueError(f"Unknown backtest mode: {mode}")

        if execution_delay > 0:
            weights = np.zeros(T)
            weights[execution_delay:] = raw_weights[:-execution_delay]
            weights[:execution_delay] = 0.0  # Cash prior to first delayed execution
        else:
            weights = raw_weights

        # Compute turnover: delta_w = |w_t - w_{t-1}|
        delta_w = np.zeros(T)
        delta_w[0] = abs(weights[0])
        delta_w[1:] = np.abs(weights[1:] - weights[:-1])
        total_turnover = float(np.sum(delta_w))
        mean_turnover = float(np.mean(delta_w))

        cost_decimal = cost_bps / 10000.0
        frictions = delta_w * cost_decimal

        # Daily strategy returns
        gross_returns = weights * r_fwd
        net_returns = gross_returns - frictions

        # Performance analytics
        metrics_gross = self._calculate_series_metrics(gross_returns)
        metrics_net = self._calculate_series_metrics(net_returns)

        # Equity curves
        equity_curve_net = np.cumprod(1.0 + net_returns)
        equity_curve_gross = np.cumprod(1.0 + gross_returns)

        # Peak and drawdown
        running_max = np.maximum.accumulate(equity_curve_net)
        drawdown_series = (equity_curve_net - running_max) / running_max
        max_drawdown = float(np.min(drawdown_series))

        metrics_net["max_drawdown"] = abs(max_drawdown)
        metrics_net["calmar_ratio"] = (metrics_net["annualized_return"] / abs(max_drawdown)) if abs(max_drawdown) > 1e-4 else 0.0
        metrics_net["total_turnover"] = total_turnover
        metrics_net["mean_turnover"] = mean_turnover

        return {
            "net_returns": net_returns,
            "gross_returns": gross_returns,
            "equity_curve": equity_curve_net,
            "drawdown_series": drawdown_series,
            "metrics": metrics_net,
            "metrics_gross": metrics_gross
        }

    def _calculate_series_metrics(self, daily_returns):
        T = len(daily_returns)
        if T == 0:
            return {}

        cum_ret = float(np.prod(1.0 + daily_returns) - 1.0)
        # Annualized return
        ann_ret = float((1.0 + cum_ret) ** (self.ann_factor / float(T)) - 1.0) if cum_ret > -1.0 else -1.0
        
        # Volatility
        daily_vol = float(np.std(daily_returns, ddof=1)) if T > 1 else 0.0
        ann_vol = daily_vol * math.sqrt(self.ann_factor)

        # Sharpe ratio
        daily_rf = (1.0 + self.rf) ** (1.0 / self.ann_factor) - 1.0
        excess_daily = daily_returns - daily_rf
        sharpe = (float(np.mean(excess_daily)) / daily_vol * math.sqrt(self.ann_factor)) if daily_vol > 1e-6 else 0.0

        # Downside volatility for Sortino
        neg_returns = daily_returns[daily_returns < 0]
        downside_std = float(np.std(neg_returns, ddof=1)) * math.sqrt(self.ann_factor) if len(neg_returns) > 1 else 1e-6
        sortino = (ann_ret - self.rf) / downside_std if downside_std > 1e-6 else 0.0

        # Hit ratio
        active_days = daily_returns[daily_returns != 0]
        hit_ratio = float(np.sum(active_days > 0) / len(active_days)) if len(active_days) > 0 else 0.0

        return {
            "cumulative_return": cum_ret,
            "annualized_return": ann_ret,
            "annualized_volatility": ann_vol,
            "sharpe_ratio": sharpe,
            "sortino_ratio": sortino,
            "hit_ratio": hit_ratio
        }

    def evaluate_cost_grid(self, signals, forward_returns, cost_grid=[0, 5, 10, 20], mode="long_short"):
        """
        Runs sensitivity sweep across transaction cost grid.
        """
        results = {}
        for c in cost_grid:
            res = self.evaluate_strategy(signals, forward_returns, cost_bps=c, mode=mode)
            results[c] = res["metrics"]
        return results
